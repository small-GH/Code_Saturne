#define real_type double
typedef struct{
	int i,j;
	int data;
	}triple;

typedef struct{
	triple *data;
	int rws,cls,num;
	}TSMatrix;

typedef struct{
	int i,j;
	int data;
	}triple;
