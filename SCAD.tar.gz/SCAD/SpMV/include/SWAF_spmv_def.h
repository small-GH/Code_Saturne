/**
 * write by hexiang on 2020-9-12
 * define some useful parameters and structures for spmv
 */

#ifndef _DEFINE_H_
#define _DEFINE_H_

#define max_size_MPE 15
#define size_MPE  30  // 1GB
#define MAX_BUFFER  256

#define blk_y_size  12 // blk_y_size = 1 << 12
#define blk_x_size  9 // blk_x_size = 1 << 10
#define max_l_nnz  11 // max local nnz in slave = 1 << 12


typedef double T_data ;
typedef int T_idx ;

typedef struct SLAVE_DATA
{
  int n_blks;
  int n_rows;
  int n_cols;
  int nnz;
  double *x;
  double *y;
  double *data; // data of none zeros
  //int *locate; // location of none zeros
  long *locate; // location of none zeros
  int *blkncy; // offset of none zeros in block
  int **nnz_mid_blk;
  int *n_mid_blk;
  //int **mid_blk_x_bp;

} _spmv_data_t;

typedef struct PARAMETERS_PREPROCESS
{
	int n_blocks;
	int min_block_row_size;
	int max_block_row_size;
	int merge_min_stride;
	int merge_tol_stride;
	int merge_min_len_x;
} Para;

/**
 * Structure of Posision of none zeros
 */
typedef struct Position
{
	unsigned short rowid;
	unsigned short colid;
} Pos;

/*
 * Basic unit for DMA of vector x
 */
typedef struct UNIT
{
	//int start_x;
	//int len_x;
	unsigned short start_x;
	unsigned short len_x;
} Unit;

/*
 */
typedef struct TILE
{
	int start_x; // start id of vector x
	int len_x; // length of x
	int nnz; // number of none zeros in tile
	int n_units; // number of units
	Unit *units; // data of units
} Tile;

/*
 * One block conduct many rows in matrix
 */
typedef struct BLOCK
{
	int start_row; // start row id
	int n_rows; // number of rows in block
	int start_nnz; // start number of none zeros
	int nnz; // number of none zeros in block
	int n_tiles; // number of tiles
	Tile* tiles;
} Block;

/*
 * Data structure for spmv in slave
 */
typedef struct DATA_SPMV
{
	int block_row_size;
	int block_col_size;
	int n_blocks; // number of blocks
	Block* blocks; // data of blocks
	T_data *x; // vector x
	T_data *y; // vector y
	//T_idx *rowid;
	//T_idx *colid;
	Pos *pos;
	T_data *data; // data in sparse matrix
} Data_spmv;

#endif
