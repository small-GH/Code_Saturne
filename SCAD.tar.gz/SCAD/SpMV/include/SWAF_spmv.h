/**
 * write by hexiang on 2020-9-22
 * interface of spmv
 */
#ifndef _SPMV_H_
#define _SPMV_H_

#include "SWAF_spmv_def.h"

/* slave data structure used for spmv in slave */
typedef _spmv_data_t spmv_data_t;

/* struct used for face_cel_p */
typedef int l_num2_t[2];

/**
 * init spmv of slave
 * n_rows : # of rows of the sparse matrix
 * n_cols : # of cols of the sparse matrix
 * nnz : # of none zeors of the sparse matrix
 * face_cel_p : map of the face and the cell
 * data : data of the none zeros in sparse matrix
 * _data : data used in spmv in slave
 */
void SWAF_spmv_init(int n_rows, int n_cols, int nnz, l_num2_t *face_cel_p, double *data, spmv_data_t *_data);

/**
 * add by hexiang on 2020-9-12
 * used for init sparse matrix with coo format
 * n_rows : # of rows of the sparse matrix
 * n_cols : # of cols of the sparse matrix
 * nnz : # of none zeors of the sparse matrix
 * rows : index of y direction none zeros of the sparse matrix
 * cols : index of x direction none zeros of the sparse matrix
 * data : data of the none zeros in sparse matrix
 * _data : data used in spmv in slave
 */
void SWAF_spmv_init_coo_d(int n_rows, int n_cols, int nnz, T_idx *rows, T_idx *cols, T_data *data, spmv_data_t *_data);

/**
 * add by guoheng on 2021-11-19
 * used for init sparse matrix with coo format
 * n_rows : number of rows
 * n_cols : number of columns
 * nnz : number of none zeros
 * rows : row index for none zeros
 * cols : col index for none zeros
 * data : data for none zeros
 * D_SPMV : data in slave
 * _para : parameters for performance tuning
 * x : vector x
 * y : vector y
 */
void SWAF_spmv_perf_tuning(int n_rows, int n_cols, int nnz, T_idx *rows, T_idx *cols, T_data *data, Data_spmv *D_SPMV, Para *para, T_data *x, T_data *y);

/**
 * Free data in struct Data_spmv
 * D_SPMV : data in slave
 */
void SWAF_free_Data_spmv(Data_spmv *D_SPMV);

/**
 * add by guoheng on 2021-11-19
 * used for init sparse matrix with coo format
 * n : number of rows
 * value : data in matrix
 * colind : column index of matrix
 * rbegin : row begin in matrix
 * _data : data used in spmv in slave
 */
void SWAF_spmv_init_coo_block(int n_rows, int n_cols, int nnz, T_idx *rows, T_idx *cols, T_data *data, Data_spmv *D_SPMV, Para *para);

/**
 * SpMV in host with block matrix format
 * D_SPMV : structure of matrix
 * x : vector x
 * y : vector y
 */
void SWAF_spmv_block_host(Data_spmv *D_SPMV, T_data *x, T_data *y);

/**
 * SpMV in slave with block matrix format
 * D_SPMV : structure of matrix
 * x : vector x
 * y : vector y
 */
void SWAF_spmv_block_slave(Data_spmv *D_SPMV, T_data *x, T_data *y);

/**
 * add by guoheng on 2019-11-22
 * used for init sparse matrix with csr format
 * nnz : number of rows
 * value : data in matrix
 * colind : column index of matrix
 * rbegin : row begin in matrix
 * _data : data used in spmv in slave
 */
void SWAF_spmv_init_csr_d(int nnz, double *value, int *colind, int *rbegin, spmv_data_t *_data);

/**
 * spmv in slave
 * _data : data used in spmv in slave
 * x : input vector
 * y : input and output vector
 */
void SWAF_spmv(spmv_data_t *_data, double *x, double *y);

/**
 * free memory
 * _data : data used in spmv in slave
 */
void SWAF_spmv_finish(spmv_data_t *_data);


/**
 * add by hexiang on 2020-9-12
 * used for sparse matrix multi vector with coo format
 * nnz : # of none zeors of the sparse matrix
 * rows : index of y direction none zeros of the sparse matrix
 * cols : index of x direction none zeros of the sparse matrix
 * data : data of the none zeros in sparse matrix
 *    x : vector data used in spmv 
 *    y : result of computation
 */
void SWAF_spmv_coo_master_i(int nnz, int *rows, int *cols, int *data, int *x, int *y);
void SWAF_spmv_coo_master_f(int nnz, int *rows, int *cols, float *data, float *x, float *y);
void SWAF_spmv_coo_master_d(int nnz, int *rows, int *cols, double *data, double *x, double *y);

/**
 * add by hexiang on 2020-9-12
 * used for sparse matrix multi vector with csr format
 * n_rows : # of rows  
 * rows_off : offset of first none zeros of each rows of sparse matrix
 * cols : index of x direction none zeros of the sparse matrix
 * data : data of the none zeros in sparse matrix
 *    x : vector data used in spmv 
 *    y : result of computation
 */
void SWAF_spmv_csr_master_i(int n_rows, int *rows_off, int *cols, int *data, int *x, int *y);
void SWAF_spmv_csr_master_f(int n_rows, int *rows_off, int *cols, float *data, float *x, float *y);
void SWAF_spmv_csr_master_d(int n_rows, int *rows_off, int *cols, double *data, double *x, double *y);

/**
 * add by hexiang on 2020-9-12
 * used for read mtx file
 * data : data of the none zeros in sparse matrix
 * rows : index of y direction none zeros of the sparse matrix
 * cols : index of x direction none zeros of the sparse matrix
 * nnz : # of none zeors of the sparse matrix
 * n_rows : # of rows
 * n_cols : # of cols
 * fname : input file name that to be read
 */
int read_MTX(T_data **data, T_idx **rows, T_idx **cols, int *nnz, int *n_rows, int *n_cols, char *fname);

/**
 * add by hexiang on 2020-9-23
 * used for write mtx file
 * data : data of the none zeros in sparse matrix
 * rows : index of y direction none zeros of the sparse matrix
 * cols : index of x direction none zeros of the sparse matrix
 * nnz : # of none zeors of the sparse matrix
 * file_name : file name that to be read
 * file_name_wr : directory of file name and output writed filename
 ****************************************************************** wr_name : writed file name
 */
//int write_MTX(T_data *data,T_idx *rows, T_idx *cols, int nnz, char *file_name,char file_name_wr[MAX_BUFFER],char **wr_name);
int write_MTX(T_data *data,T_idx *rows, T_idx *cols, int nnz, char *file_name,char file_name_wr[MAX_BUFFER]);

/**
 * add by hexiang on 2020-9-23
 * used to convert coo to csr that row/col-index from "0"/"1"
 * nnz : # of none zeors of the sparse matrix
 * n_rows : # of y direction none zeros of the sparse matrix
 * rows : index of Y direction none zeros of the sparse matrix
 * rows_off : offset of first none zeros of each row 
 * cols1 : index of none zeros 
void SWAF_spmv_o2r_d_0idx(int nnz,int n_rows,T_idx *rows,T_idx **rows_off);
void SWAF_spmv_o2r_d_1idx(int nnz,int n_rows,T_idx *rows,T_idx **rows_off);
 */
void SWAF_spmv_o2r_d(int nnz,int n_rows,T_idx *rows,T_idx **rows_off);


/**
 * add by hexiang on 2020-9-23
 * used to convert csr to coo that row/col-index from "0"/"1"
 * nnz : # of none zeors of the sparse matrix
 * n_rows : # of y direction none zeros of the sparse matrix
 * n_cols : # of x direction none zeros of the sparse matrix
 * rows_off : offset of first none zeros of each row 
 * cols : index of x direction none zeros of the sparse matrix
 * rows : index of Y direction none zeros of the sparse matrix
void SWAF_spmv_r2o_d_0idx(int *nnz,int n_rows,int *n_cols,T_idx *rows_off,T_idx *cols,T_idx **rows);
void SWAF_spmv_r2o_d_1idx(int *nnz,int n_rows,int *n_cols,T_idx *rows_off,T_idx *cols,T_idx **rows);
 */
void SWAF_spmv_r2o_d(int *nnz,int n_rows,int *n_cols,T_idx *rows_off,T_idx *cols,T_idx **rows);

#endif

