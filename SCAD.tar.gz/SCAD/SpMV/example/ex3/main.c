/**
 * write by hexiang on 2020-9-27
 * test performance of spmv with new method used in coo data
 */
#include <stdio.h>
#include <math.h>
#include <string.h>
#include<crts.h>

#include "SWAF_spmv.h"

void sigfunc(int sig)
{
  printf("kasile\n");
  while(1);
}

unsigned long real_size;

#ifdef get_time
unsigned long st, ed;
unsigned long slv_time, master_time,init_time;
#endif

int main(int argc, char *argv[])
{
  signal(11, sigfunc);
  CRTS_init();

	char *file_name,*dtype;
	char file_name_wr[MAX_BUFFER] = "../../CheckFiles/checkread_";
  FILE* fp;
	char match[MAX_BUFFER] = "%./";

	int type_size = -1,real_type_size=-1,point_length = -1; 
	int i,j,ierr ;

	T_data *data;
	T_idx *rows,*cols,*rows_off,*pre_cols;
	char *wr_name;
	int n_rows,n_cols,nnz;
	
  if(argc==0) 
	{
		printf("please input filename !!!!! \n");
		return 0 ;
	}
	else
		file_name = argv[1];

	ierr = read_MTX(&data,&rows,&pre_cols,&nnz,&n_rows,&n_cols,file_name);
	printf("nnz = %d, n_rows = %d,n_cols = %d\n",nnz,n_rows,n_cols);

  cols = (T_idx*)malloc(nnz*sizeof(T_idx));
  double *y = (double*)malloc(n_rows*sizeof(double));
  double *x = (double*)malloc(n_cols*sizeof(double));
  for(i=0;i<nnz;i++)
	{
		cols[i] = rows[i];
		rows[i] = pre_cols[i];
	}
	//printf("after pre_int\n");

        for(i=0; i<n_rows; i++)
          y[i] = 0.0;

        for(i=0; i<n_cols; i++){
          x[i] = 1.2344324 * i;
//					printf("x[%d]=%lf\n",i,x[i]);
				}

	//printf("after init_result\n");

	for(i=0;i<nnz;i++)
	{
    rows[i] = rows[i]-1;
    cols[i] = cols[i]-1;
	}

/* *used for debug
	for(i=0;i<30;i++)
	{
		printf("%d r-%d,c_%d\n",i,rows[i],cols[i]);
	}
*/
    _spmv_data_t *_data = (spmv_data_t*)malloc(sizeof(spmv_data_t));

#ifdef get_time
    st = CRTS_time_cycle();
#endif
    
    //SWAF_spmv_o2r_d_0idx(nnz,n_rows,rows,&rows_off);
    SWAF_spmv_o2r_d(nnz,n_rows,rows,&rows_off);

/* *used for debug
	for(i=0;i<4;i++)
	{
		for(j=rows_off[i];j<rows_off[i+1];j++)
		{
		  printf("after o2r %d rows,r_off_s-%d,r_off_e_%d\n",i,rows_off[i],rows_off[i+1]);
		}
	}
	return 0;
*/

    SWAF_spmv_init_csr_d(n_rows, data, cols, rows_off, _data);
    //  printf("after o2r , nnz|rows_off[%d]=%d,%d\n",n_rows,nnz,rows_off[n_rows]);
		 
#ifdef get_time
    ed = CRTS_time_cycle();
		//init_time = ed -st;
    printf("time used of spmv_init is %ld\n", ed - st);
    st = CRTS_time_cycle();
#endif
		SWAF_spmv(_data, x, y);
#ifdef get_time
    ed = CRTS_time_cycle();
    slv_time = ed - st;
    printf("time used of spmv is %ld\n", ed - st);

#endif

    // begin check res
    double *y_res = (double*)malloc(n_rows * sizeof(double));

    for(i=0; i<n_rows; i++)
      y_res[i] = 0.;
    int ii, jj;
		//主核验证
#ifdef get_time
    st = CRTS_time_cycle();
#endif

   SWAF_spmv_csr_master_d(n_rows, rows_off, cols, data, x, y_res);

#ifdef get_time
    ed = CRTS_time_cycle();
    master_time = ed - st;
    printf("time used of maser-spmv is %ld\n", ed - st);
#endif

    int correct = 1;
    for(i=0; i<n_rows; i++){
      if(y[i] != y_res[i])
      {
        correct = 0;
        break;
      }}
    if(correct)
    {
      printf("SPMV result correct!\n");
#ifdef get_time
      //printf("time in slave : %ld, time in master : %ld, speedup : %lf\n", slv_time, master_time, 1.0 * master_time / (slv_time+init_time));
      printf("time in slave : %ld, time in master : %ld, speedup : %lf\n", slv_time, master_time, 1.0 * master_time / slv_time);
#endif
    }
    else
    {
      FILE *fp_res = fopen("y_slv", "w");
      double res = 0.;
      for(i=0; i<n_rows; i++)
      {
        res += y[i];
        if(y[i] != y_res[i])
          fprintf(fp_res, "y[%d]=%.15lf, y_res[%d]=%.15lf\n", i, y[i], i, y_res[i]);
      }
      fclose(fp_res);
      printf("sum of y is %lf \n", res);
    }
    // end check res
		
  SWAF_spmv_finish(_data);
  free(data);
  free(rows);
  free(cols);
  free(pre_cols);
  free(y);
  free(x);
	free(y_res);

 }

