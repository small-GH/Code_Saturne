/**
 * write by hexiang on 2020-9-12
 * test performance of spmv with new method used in coo data
 */
#include <stdio.h>
#include <math.h>
#include <string.h>
#include<crts.h>

#include "SWAF_spmv.h"

void sigfunc(int sig)
{
  printf("kasile\n");
  while(1);
}

unsigned long real_size;

#ifdef get_time
unsigned long st, ed;
unsigned long slv_time, master_time,init_time;
#endif

void get_perf_spmv_block(Data_spmv *D_SPMV, unsigned long t, int n_rows, int n_cols, int nnz)
{
	long data_size = 0;
	int i, j, k;
	int m, n;
	int n_blocks = D_SPMV->n_blocks;
	Block *blocks = D_SPMV->blocks;
	Tile *tiles = NULL;
	Unit *units = NULL;
	int n_units = 0;
	long data_size_x = 0; // data size of x
	long data_size_y = 0; // data size of y
	long data_size_nz = 0; // data size of none zeros
	long data_size_blocks = 0; // data size of blocks
	long data_size_tiles = 0; // data size of tiles
	long data_size_units = 0; // data size of units
	data_size += n_blocks * sizeof(Block); // Block
	data_size_blocks += n_blocks * sizeof(Block);
	// Data analysis for every slave core
	long core_data_size[64];
	long core_flops[64];
	int num_little_x = 0;
	long data_size_little_x = 0;
	//memset(core_data_size, 0, 64 * sizeof(long));
	//memset(core_flops, 0, 64 * sizeof(long));
	for(i=0; i<64; i++)
	{
		core_data_size[i] = 0;
		core_flops[i] = 0;
	}
	for(i=0; i<n_blocks; i++)
	{
		tiles = blocks[i].tiles;
		int n_tiles = blocks[i].n_tiles;
		if(n_tiles == 0)
			continue;
		data_size += n_tiles * sizeof(Tile); // Tile
		data_size_tiles += n_tiles * sizeof(Tile);
		core_data_size[i%64] += n_tiles * sizeof(Tile);
		int n_rows = blocks[i].n_rows;
		data_size += n_rows * sizeof(T_data); // y
		data_size_y += n_rows * sizeof(T_data);
		core_data_size[i%64] += n_rows * sizeof(T_data);
		for(j=0; j<n_tiles; j++)
		{
			int nnz = tiles[j].nnz;
			n_units = tiles[j].n_units;
			units = tiles[j].units;
			data_size += n_units * sizeof(Unit); // Unit
			data_size_units += n_units * sizeof(Unit);
			core_data_size[i%64] += n_units * sizeof(Unit);
			for(m=0; m<n_units; m++)
			{
				data_size += units[m].len_x * sizeof(T_data); // x
				data_size_x += units[m].len_x * sizeof(T_data);
				core_data_size[i%64] += units[m].len_x * sizeof(T_data);
				if(units[m].len_x < 32) // little x
				{
					num_little_x ++;
					data_size_little_x += units[m].len_x * sizeof(T_data);
				}
			}
			//int len_x = tiles[j].len_x;
			//data_size += len_x *sizeof(T_data); // x
			data_size += nnz * (sizeof(T_data) + (2 * sizeof(unsigned short))); // data and idx
			data_size_nz += nnz * (sizeof(T_data) + (2 * sizeof(unsigned short)));
			core_data_size[i%64] += nnz * (sizeof(T_data) + (2 * sizeof(unsigned short)));
			core_flops[i%64] += nnz * 2;
		}
	}
	long ideal_data_size = 0;
	ideal_data_size += nnz * (sizeof(T_data) + (2 * sizeof(T_idx))); // data and idx
	ideal_data_size += n_rows * sizeof(T_data); // x
	ideal_data_size += n_cols * sizeof(T_data); // x
	printf("=============================Performance!================================\n");
	printf("Data size of ideal spmv is %ld Byte\n", ideal_data_size);
	printf("Data size of block spmv is %ld Byte\n", data_size);
	printf("Data size of x is %ld Byte\n", data_size_x);
	printf("Number of little x is %d\n", num_little_x);
	printf("Data size of little x is %ld Byte\n", data_size_little_x);
	printf("Data size of y is %ld Byte\n", data_size_y);
	printf("Data size of nz is %ld Byte\n", data_size_nz);
	printf("Data size of blocks is %ld Byte, sizeof Block is %d\n", data_size_blocks, sizeof(Block));
	printf("Data size of tiles is %ld Byte, size of Tile is %d\n", data_size_tiles, sizeof(Tile));
	printf("Data size of units is %ld Byte, size of Unit is %d\n", data_size_units, sizeof(Unit));
	double bw = 2.15 * data_size / t;
	double perf = 2.15 * nnz * 2 / t;
	printf("Bandwidth of block spmv is %lf GB/s\n, Performance of block spmv is %lf Gflops\n", bw, perf);
	printf("=============================Performance!================================\n");
	printf("=============================Data analysis================================\n");
	printf("Data size in slave core :\n");
	for(i=0; i<8; i++)
	{
		for(j=0; j<8; j++)
			printf("%ld\t", core_data_size[i*8+j]);
		printf("\n");
	}
	printf("Flops in slave core :\n");
	for(i=0; i<8; i++)
	{
		for(j=0; j<8; j++)
			printf("%ld\t", core_flops[i*8+j]);
		printf("\n");
	}
	printf("=============================Data analysis end================================\n");
}

int main(int argc, char *argv[])
{
  signal(11, sigfunc);
  CRTS_init();

	char *file_name,*dtype;
	char file_name_wr[MAX_BUFFER] = "../../CheckFiles/checkread_";
  FILE* fp;
	char match[MAX_BUFFER] = "%./";

	int type_size = -1,real_type_size=-1,point_length = -1; 
	int i,ierr ;

	T_data *data;
	T_idx *rows,*cols,*rows_off;
	char *wr_name;
	int n_rows,n_cols,nnz;
	
  if(argc==0) 
	{
		printf("please input filename !!!!! \n");
		return 0 ;
	}
	else
		file_name = argv[1];

	ierr = read_MTX(&data,&rows,&cols,&nnz,&n_rows,&n_cols,file_name);
	printf("nnz = %d, n_rows = %d,n_cols = %d\n",nnz,n_rows,n_cols);

  double *y = (double*)malloc(n_rows*sizeof(double));
  double *x = (double*)malloc(n_cols*sizeof(double));
        for(i=0; i<n_rows; i++)
          y[i] = 0.0;

        for(i=0; i<n_cols; i++)
          x[i] = 1.2344324 * i;

	// matrix size is less than size of MPE

#ifdef CHECKREAD
	//ierr = write_MTX(data,rows,cols,nnz,file_name,file_name_wr,&wr_name);
	//ierr = write_MTX(data,rows,cols,nnz,file_name,file_name_wr);
  //printf("wr file is %s\n",file_name_wr);
#endif	
	for(i=0;i<nnz;i++)
	{
    rows[i] = rows[i]-1;
    cols[i] = cols[i]-1;
	}
	/*
    _spmv_data_t *_data = (spmv_data_t*)malloc(sizeof(spmv_data_t));

#ifdef get_time
    st = CRTS_time_cycle();
#endif
    SWAF_spmv_init_coo_d(n_rows, n_cols, nnz, rows, cols, data, _data);
#ifdef get_time
    ed = CRTS_time_cycle();
		//init_time = ed -st;
    printf("time used of spmv_init is %ld\n", ed - st);
    st = CRTS_time_cycle();
#endif
		SWAF_spmv(_data, x, y);
#ifdef get_time
    ed = CRTS_time_cycle();
    slv_time = ed - st;
    printf("time used of spmv is %ld\n", ed - st);

    //double bw;
    //unsigned long data_size = 0;
    //data_size += _data->nnz * 8; // data
    //data_size += _data->nnz * 4; // locate
    //data_size += cols * 8; // x
    //data_size += rows * 8; // y
    //bw = 2.1 * data_size / (ed - st);
    //printf("bandwidth is %lf\n", bw);
#endif
		*/

	// Add by guoheng at 2021-11-20
	Para *para = (Para*)malloc(sizeof(Para));
	Data_spmv *D_SPMV = (Data_spmv*)malloc(sizeof(Data_spmv));
	SWAF_spmv_perf_tuning(n_rows, n_cols, nnz, rows, cols, data, D_SPMV, para, x, y);
	SWAF_spmv_init_coo_block(n_rows, n_cols, nnz, rows, cols, data, D_SPMV, para);
#ifdef get_time
    st = CRTS_time_cycle();
#endif
	//SWAF_spmv_block_host(D_SPMV, x, y);
	SWAF_spmv_block_slave(D_SPMV, x, y);
#ifdef get_time
    ed = CRTS_time_cycle();
    slv_time = ed - st;
    printf("time used of spmv is %ld\n", ed - st);
		double perf = 1.0 * nnz * 2 / (slv_time/2.15);
		printf("performance of SpMV is %lf Gflops\n", perf);
		get_perf_spmv_block(D_SPMV, slv_time, n_rows, n_cols, nnz);
#endif

    // begin check res
    double *y_res = (double*)malloc(n_rows * sizeof(double));

    for(i=0; i<n_rows; i++)
      y_res[i] = 0.;
    int ii, jj;
		//主核验证
#ifdef get_time
    st = CRTS_time_cycle();
#endif

   SWAF_spmv_coo_master_d(nnz, rows, cols, data, x, y_res);

#ifdef get_time
    ed = CRTS_time_cycle();
    master_time = ed - st;
#endif

    int correct = 1;
    for(i=0; i<n_rows; i++)
      if(y[i] != y_res[i])
      {
				printf("Error i=%d, y[%d]=%lf, y_res[%d]=%lf\n", i, i, y[i], i, y_res[i]);
        correct = 0;
        break;
      }
    if(correct)
    {
      printf("SPMV result correct!\n");
#ifdef get_time
      //printf("time in slave : %ld, time in master : %ld, speedup : %lf\n", slv_time, master_time, 1.0 * master_time / (slv_time+init_time));
      printf("time in slave : %ld, time in master : %ld, speedup : %lf\n", slv_time, master_time, 1.0 * master_time / slv_time);
#endif
    }
    else
    {
      FILE *fp_res = fopen("y_slv", "w");
      double res = 0.;
      for(i=0; i<n_rows; i++)
      {
        res += y[i];
        if(y[i] != y_res[i])
          fprintf(fp_res, "y[%d]=%.15lf, y_res[%d]=%.15lf\n", i, y[i], i, y_res[i]);
      }
      fclose(fp_res);
      printf("sum of y is %lf \n", res);
    }
    // end check res
		
  //SWAF_spmv_finish(_data);
  free(data);
  free(rows);
  free(cols);
  free(y);
  free(x);
  free(y_res);

 }

