/**
 * write by hexiang on 2020-9-12
 * test for sparse format convering
 */
#include <stdio.h>
#include <math.h>
#include <string.h>
#include<crts.h>

#include "SWAF_spmv.h"

void sigfunc(int sig)
{
  printf("kasile\n");
  while(1);
}

unsigned long real_size;

#ifdef get_time
unsigned long st, ed;
unsigned long slv_time, master_time,init_time;
#endif

int main(int argc, char *argv[])
{
  signal(11, sigfunc);

	T_data *data;
	T_idx *rows,*cols,*rows_off;

	int n_rows,n_cols,nnz;
	int i,j,k;
	int zero = 0.0;

	n_rows = 12 ;
	n_cols = 10 ;
	nnz = 12 ; 
	
	rows= (T_idx*)malloc(nnz*sizeof(T_idx));
	cols= (T_idx*)malloc(nnz*sizeof(T_idx));
	data = (T_data*)malloc(nnz*sizeof(T_data));
	T_data** data_coo = (T_data**)malloc(n_rows*sizeof(T_data*));
	for(i=0;i<n_rows;i++)
	{
		data_coo[i] = (T_data*)malloc(n_cols*sizeof(T_data));
	}
	for(i=0;i<n_rows;i++)
	for(j=0;j<n_cols;j++)
	{
	  data_coo[i][j] = 0.0;
	  //printf("%lf ",data_coo[i][j]);
	}

	for(i=0;i<nnz;i++)
	{
		rows[i] = i;
		cols[i] = (n_cols >  i) ? (i):(i-n_cols);
		data[i] = 0.5*(i+1);
    printf("rows-%d,cols-%d,data[%d]=%lf\n",rows[i],cols[i],i,data[i]);
	}


  for(j=0;j<n_rows;j++)
  	for(k=0;k<n_cols;k++)
	     for(i=0;i<nnz;i++)
			 if((j)==rows[i]&&(k)==cols[i]) data_coo[j][k]=data[i];
/* used for debug
  for(j=0;j<n_rows;j++){
  	for(k=0;k<n_cols;k++)
		{
			printf("%lf ",data_coo[j][k]);
		}
		printf("\n");
	}
*/

  //SWAF_spmv_o2r_d_0idx(nnz,n_rows,rows,&rows_off);
  SWAF_spmv_o2r_d(nnz,n_rows,rows,&rows_off);

  printf("after o2r nnz=%d,n_rows=%d,n_cols=%d\n",nnz,n_rows,n_cols);

/* used for debug
  for(i=0;i<n_rows+1;i++ )
	  printf("%d ",rows_off[i]);

	printf("\n");
*/

  // after convert, print matrix
  for(j=0;j<n_rows;j++)
  	for(k=0;k<n_cols;k++)
	     for(i=0;i<nnz;i++)
			 if(j==rows[i]&&k==cols[i]) data_coo[j][k]=data[i];

  for(j=0;j<n_rows;j++)
	{
  	for(k=0;k<n_cols;k++)
		{
			printf("%lf ",data_coo[j][k]);
		}
		printf("\n");
	}
  
	int nnz1,n_rows1,n_cols1;
	T_idx *rows1;

  n_rows1 = n_rows;
  //SWAF_spmv_r2o_d_0idx(&nnz1,n_rows1,&n_cols1,rows_off,cols,&rows1);
  SWAF_spmv_r2o_d(&nnz1,n_rows1,&n_cols1,rows_off,cols,&rows1);

  // after convert, print matrix
  printf("after r2o nnz=%d,n_rows=%d,n_cols=%d\n",nnz1,n_rows1,n_cols1);
	for(i=0;i<n_rows1;i++)
	for(j=0;j<n_cols1;j++)
	{
	  data_coo[i][j] = 0.0;
	  //printf("%lf ",data_coo[i][j]);
	}
  for(j=0;j<n_rows1;j++)
  	for(k=0;k<n_cols1;k++)
	     for(i=0;i<nnz1;i++)
			 if(j==rows1[i]&&k==cols[i]) data_coo[j][k]=data[i];

  for(j=0;j<n_rows;j++)
	{
  	for(k=0;k<n_cols;k++)
		{
			printf("%lf ",data_coo[j][k]);
		}
		printf("\n");
	}

  free(rows);
  free(cols);
	for(i=0;i<n_rows;i++)
	{
		free(data_coo[i]);
	}
	free (data_coo);
  free(data);

}

