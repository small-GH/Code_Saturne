#include <stdlib.h>
#include <stdio.h>
#include <crts.h>
#include <spmv.h>

int main()
{
	unsigned long st, ed;
	unsigned long time_master, time_slave;
	st = CRTS_time_cycle();
	SWAF_spmv_coo_master_d(n_rows, n_cols, nnz, rows, cols, data, x, y);
	ed = CRTS_time_cycle();
	time_master = ed - st;

	spmv_data_t *_data = (spmv_data_t*)malloc(sizeof(spmv_data_t));
	SWAF_spmv_init_coo_d(n_rows, n_cols, nnz, rows, cols, data, _data);
	st = CRTS_time_cycle();
	SWAF_spmv(_data, x, y);
	ed = CRTS_time_cycle();
	time_slave = ed - st;
	SWAF_spmv_finish(_data);

	return 0;
}
