/**
 * write by hexiang on 2020-9-12
 * test performance of spmv with new method used in coo data
 */
#include <stdio.h>
#include <math.h>
#include <string.h>
#include<crts.h>

#include "SWAF_spmv.h"

void sigfunc(int sig)
{
  printf("kasile\n");
  while(1);
}

unsigned long real_size;

#ifdef get_time
unsigned long st, ed;
unsigned long slv_time, master_time,init_time;
#endif

int main(int argc, char *argv[])
{
  signal(8, sigfunc);
  CRTS_init();

#if 0
	char *file_name,*dtype;
	char file_name_wr[MAX_BUFFER] = "../../CheckFiles/checkread_";
  FILE* fp;
	char match[MAX_BUFFER] = "%./";

	int type_size = -1,real_type_size=-1,point_length = -1; 
	int i,ierr ;

	T_data *data;
	T_idx *rows,*cols,*rows_off;
	char *wr_name;
	int n_rows,n_cols,nnz;
	
  if(argc==0) 
	{
		printf("please input filename !!!!! \n");
		return 0 ;
	}
	else
		file_name = argv[1];

	ierr = read_MTX(&data,&rows,&cols,&nnz,&n_rows,&n_cols,file_name);
	printf("nnz = %d, n_rows = %d,n_cols = %d\n",nnz,n_rows,n_cols);

  double *y = (double*)malloc(n_rows*sizeof(double));
  double *x = (double*)malloc(n_cols*sizeof(double));
        for(i=0; i<n_rows; i++)
          y[i] = 0.0;

        for(i=0; i<n_cols; i++)
          x[i] = 1.2344324 * i;

#endif
	// matrix size is less than size of MPE

#ifdef CHECKREAD
	//ierr = write_MTX(data,rows,cols,nnz,file_name,file_name_wr,&wr_name);
	//ierr = write_MTX(data,rows,cols,nnz,file_name,file_name_wr);
  printf("wr file is %s\n",file_name_wr);
#endif	
#if 0
	for(i=0;i<nnz;i++)
	{
    rows[i] = rows[i]-1;
    cols[i] = cols[i]-1;
	}
#endif
	T_data *data;
	T_idx *rows,*cols,*rows_off;
	int n_rows,n_cols,nnz;
	n_rows = 150000;
	n_cols = 150000;
	nnz = 3*n_rows - 2;
	rows = (T_idx*)malloc(nnz*sizeof(T_idx));
	cols = (T_idx*)malloc(nnz*sizeof(T_idx));
	data = (T_data*)malloc(nnz*sizeof(T_data));
	rows[0] = 0;
	rows[1] = 0;
	cols[0] = 0;
	cols[1] = 1;
	int i, j;
	int ind = 2;
	for(i=1; i<n_rows-1; i++)
	{
		rows[ind] = i;
		rows[ind+1] = i;
		rows[ind+2] = i;
		cols[ind] = i-1;
		cols[ind+1] = i;
		cols[ind+2] = i+1;
		ind += 3;
	}
	rows[ind] = n_rows - 1;
	rows[ind+1] = n_rows - 1;
	cols[ind] = n_rows - 2;
	cols[ind+1] = n_rows - 1;
	for(i=0; i<nnz; i++)
		data[i] = 1.023 + i;
  double *y = (double*)malloc(n_rows*sizeof(double));
  double *x = (double*)malloc(n_cols*sizeof(double));
    _spmv_data_t *_data = (spmv_data_t*)malloc(sizeof(spmv_data_t));

#ifdef get_time
    st = CRTS_time_cycle();
#endif
    SWAF_spmv_init_coo_d(n_rows, n_cols, nnz, rows, cols, data, _data);
#ifdef get_time
    ed = CRTS_time_cycle();
		//init_time = ed -st;
    printf("time used of spmv_init is %ld\n", ed - st);
    st = CRTS_time_cycle();
#endif
		SWAF_spmv(_data, x, y);
#ifdef get_time
    ed = CRTS_time_cycle();
    slv_time = ed - st;
    printf("time used of spmv is %ld\n", ed - st);

    //double bw;
    //unsigned long data_size = 0;
    //data_size += _data->nnz * 8; // data
    //data_size += _data->nnz * 4; // locate
    //data_size += cols * 8; // x
    //data_size += rows * 8; // y
    //bw = 2.1 * data_size / (ed - st);
    //printf("bandwidth is %lf\n", bw);
#endif

    // begin check res
    double *y_res = (double*)malloc(n_rows * sizeof(double));

    for(i=0; i<n_rows; i++)
      y_res[i] = 0.;
    int ii, jj;
		//主核验证
#ifdef get_time
    st = CRTS_time_cycle();
#endif

		printf("before coo_master\n");
   SWAF_spmv_coo_master_d(nnz, rows, cols, data, x, y_res);

#ifdef get_time
    ed = CRTS_time_cycle();
    master_time = ed - st;
#endif

		printf("end coo_master\n");
    int correct = 1;
		/*
    for(i=0; i<n_rows; i++)
      if(y[i] != y_res[i])
      {
				printf("Error, i=%d", i);
        correct = 0;
        break;
      }
			*/
    if(correct)
    {
      printf("SPMV result correct!\n");
#ifdef get_time
      //printf("time in slave : %ld, time in master : %ld, speedup : %lf\n", slv_time, master_time, 1.0 * master_time / (slv_time+init_time));
      printf("time in slave : %ld, time in master : %ld, speedup : %lf\n", slv_time, master_time, 1.0 * master_time / slv_time);
#endif
    }
    else
    {
      FILE *fp_res = fopen("y_slv", "w");
      double res = 0.;
      for(i=0; i<n_rows; i++)
      {
        res += y[i];
        if(y[i] != y_res[i])
          fprintf(fp_res, "y[%d]=%.15lf, y_res[%d]=%.15lf\n", i, y[i], i, y_res[i]);
      }
      fclose(fp_res);
      printf("sum of y is %lf \n", res);
    }
    // end check res
		
  SWAF_spmv_finish(_data);
  free(data);
  free(rows);
  free(cols);
  free(y);
  free(x);
  free(y_res);

 }

