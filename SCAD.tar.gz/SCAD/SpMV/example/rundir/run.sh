#bsub -I -b -pr -q q_ss_all -n 1 -cgsp 64 -host_stack 1024 -share_size 4096 ./read_file
#bsub -I -b -q q_test_2jicang -n 1 -cgsp 64 -host_stack 1024 -share_size 14000 -cache_size 0 ../bin/exam_read.exe $1
#bsub -I -b -q q_test_2jicang -n 1 -cgsp 64 -host_stack 1024 -share_size 14000 -cache_size 0 ../bin/$0 $1
#bsub -I -b -q q_debug_yyz -n 1 -cgsp 64 -host_stack 1024 -share_size 14000 -cache_size 0 ../bin/$0 $1
bsub -I -b -q q_sw_expr -n 1 -cgsp 64 -host_stack 1024 -share_size 14000 -cache_size 0 ../bin/$1 $2
