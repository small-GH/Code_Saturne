/**
 * write by guoheng on 2019-8-13
 * spmv function in slave
 */
#include <crts.h>
#include "SWAF_spmv_def.h"

// 8
// 64  
// 512   
// 1024 (2^10)
// 4096 ( 2^12 = 1<<12 ) = 4KB 
// 8*4096 (2^15) a= 32KB

//#define blk_y_size 12 // blk_y_size_t = 1 << 12
//#define blk_x_size 9 // blk_x_size_t = 1 << 9
//#define max_l_nnz 11 // max local nnz in slave = 1 << 11
//define x_data_size_t  (1 << x_data_size) // 2^14 = 16*4096
#define blk_y_size_t (1<<blk_y_size)
#define blk_x_size_t (1<<blk_x_size)
#define max_l_nnz_t (1<<max_l_nnz)
#define x_data_size 14
//#define x_data_size_t1  10
#define x_data_size_t  (1<<x_data_size) 

__thread_local double *ldm_x;
__thread_local double *x_data_addr[16];

/* //hexiang
void calculate(_spmv_data_t *_data)
{
  ldm_x = (double*)ldm_malloc(blk_x_size_t*sizeof(double));
  int volatile r_rply;
  int i, j, k, m, n, p;
  for(i=0; i<16; i++)
    CRTS_rma_bcast_coll(x_data_addr+i, &ldm_x, sizeof(double*), i+48);
  double ldm_y[blk_y_size_t];
  int start_y = _MYID << blk_y_size; // _MYID * 4096 here
  int len_y;
  int n_rows = _data->n_rows;
  double *y = _data->y;
  double *data = _data->data;
  int *locate = _data->locate;
  int *blkncy = _data->blkncy;
  int **nnz_mid_blk = _data->nnz_mid_blk;
  int *n_mid_blk = _data->n_mid_blk;
  int l_n_mid_blk; // local number of middle blocks
  int blk_id = _MYID; // current block id
  int ldm_nnz_mid_blk[32]; // number of none zeros in every middle block
  int start_nnz;
  double ldm_data[2][max_l_nnz_t]; // double buffer
  int ldm_locate[2][max_l_nnz_t]; // double buffer
  int volatile dma_rply;
  int ind_x;
  int ind_y;
  int x_addr_id;
  int x_id_off;
  int x_id;
  int curr_x_id;
  int n_data_x = x_data_size - blk_x_size;
  int start_x;
  // used for debug
  while(start_y < n_rows)
  {
    len_y = (start_y + blk_y_size_t > n_rows) ? (n_rows - start_y) : blk_y_size_t;
    // init ldm_y
    for(i=0; i<len_y; i++)
      ldm_y[i] = 0.;
    //CRTS_dma_get(ldm_y, y+start_y, len_y*sizeof(double));
    // get none zeros
    l_n_mid_blk = n_mid_blk[blk_id];
    CRTS_dma_get(ldm_nnz_mid_blk, nnz_mid_blk[blk_id], l_n_mid_blk*sizeof(int));
    start_nnz = blkncy[blk_id]; // get data from host memory
    CRTS_dma_get(ldm_data[0], data+start_nnz, ldm_nnz_mid_blk[0]*sizeof(double));
    CRTS_dma_get(ldm_locate[0], locate+start_nnz, ldm_nnz_mid_blk[0]*sizeof(int));
    start_nnz += ldm_nnz_mid_blk[0];
    curr_x_id = -1;
    for(i=1; i<l_n_mid_blk; i++)
    {
      dma_rply = 0;
      CRTS_dma_iget(ldm_data[i%2], data+start_nnz, ldm_nnz_mid_blk[i]*sizeof(double), &dma_rply);
      CRTS_dma_iget(ldm_locate[i%2], locate+start_nnz, ldm_nnz_mid_blk[i]*sizeof(int), &dma_rply);
      // calculate
      k = (i-1)%2; // current data
      for(j=0; j<ldm_nnz_mid_blk[i-1]; j++)
      {
        ind_x = ldm_locate[k][j] >> blk_y_size;
        ind_y = ldm_locate[k][j] - (ind_x << blk_y_size);
        x_id = ind_x >> blk_x_size;
        if(x_id == curr_x_id) // calculate
        {
          ldm_y[ind_y] += ldm_x[ind_x - (x_id<<blk_x_size)] * ldm_data[k][j];
        }
        else // rma get data
        {
          x_addr_id = ind_x >> x_data_size;
          x_id_off = x_id - (x_addr_id << n_data_x);
          CRTS_rma_get(ldm_x, blk_x_size_t*sizeof(double), x_addr_id+48, x_data_addr[x_addr_id]+(x_id_off<<blk_x_size), &r_rply);
          curr_x_id = x_id;
          ldm_y[ind_y] += ldm_x[ind_x - (x_id<<blk_x_size)] * ldm_data[k][j];
        }
      }
      start_nnz += ldm_nnz_mid_blk[i];
      CRTS_dma_wait_value(&dma_rply, 2);
    }
    // calculate
    k = (i-1)%2;
    for(j=0; j<ldm_nnz_mid_blk[i-1]; j++)
    {
      ind_x = ldm_locate[k][j] >> blk_y_size;
      ind_y = ldm_locate[k][j] - (ind_x << blk_y_size);
      x_id = ind_x >> blk_x_size;
      if(x_id == curr_x_id) // calculate
      {
        ldm_y[ind_y] += ldm_x[ind_x - (x_id<<blk_x_size)] * ldm_data[k][j];
      }
      else // rma get data
      {
        x_addr_id = ind_x >> x_data_size;
        x_id_off = x_id - (x_addr_id << n_data_x);
        CRTS_rma_get(ldm_x, blk_x_size_t*sizeof(double), x_addr_id+48, x_data_addr[x_addr_id]+(x_id_off<<blk_x_size), &r_rply);
        curr_x_id = x_id;
        ldm_y[ind_y] += ldm_x[ind_x - (x_id<<blk_x_size)] * ldm_data[k][j];
      }
    }
    // put y
    CRTS_dma_put(y+start_y, ldm_y, len_y*sizeof(double));
    start_y += blk_y_size_t * 48;
    blk_id += 48;
  }
  CRTS_ssync_array();
  ldm_free(ldm_x, blk_x_size_t*sizeof(double));
}

void x_data(_spmv_data_t *_data)
{
  int ldm_size = get_allocatable_size();
  //double ldm_x[x_data_size_t];
  ldm_x = (double*)ldm_malloc(x_data_size_t*sizeof(double));
  int volatile r_rply;
  int i;
  int n_cols = _data->n_cols;
  double *x = _data->x;
  int start_x = (_MYID - 48) << x_data_size; // (_MYID - 48) * 16384
  int len_x;
  if(start_x < n_cols)
  {
    len_x = (start_x + x_data_size_t > n_cols) ? (n_cols - start_x) : x_data_size_t;
    CRTS_dma_get(ldm_x, x+start_x, len_x*sizeof(double));
  }
  //double **addr = (double**)ldm_malloc(sizeof(double*));
  double *addr[1];
  addr[0] = ldm_x;
  for(i=0; i<16; i++)
    CRTS_rma_bcast_coll(x_data_addr+i, addr, sizeof(double*), i+48);
  ldm_free(addr, sizeof(double*));
  CRTS_ssync_array();
  ldm_free(ldm_x, x_data_size_t*sizeof(double));
}
void spmv_slv(_spmv_data_t *_data)
{
  if(_ROW < 6)
    calculate(_data);
  else
    x_data(_data);
}
*/ //hexiang

/**
 * calculate y = A.x with x data from core 48-64
 * _data : spmv data
 */
// x_data_size_t = 2^14 = 4096
void calcu_new(_spmv_data_t *_data)
{
  ldm_x = (double*)ldm_malloc(blk_x_size_t*sizeof(double));  // 2^9=512
  int n_rows = _data->n_rows;
  int n_cols = _data->n_cols;
  int n_blks = _data->n_blks;
  int *blkncy = _data->blkncy;
  double *y = _data->y;
  double *data = _data->data;
  //int *locate = _data->locate;
  long *locate = _data->locate;
  int iter_y = (n_blks + 47) / 48;//大块有几个48=1
  int len_x_once = x_data_size_t << 4; // 16 data cores  //2的18次方=262144列数的上限？ 2^14*16
	// len_x_once = 16384*16=262144
  int iter_x = (n_cols + len_x_once - 1) >> (x_data_size + 4);//=1  x_data_size = 14
  //int iter_x = (n_cols + len_x_once - 1) / len_x_once;//=1  x_data_size = 14
  int i, j, k, m, n, p;
  // get address of ldm_x from core 48-63
  for(i=0; i<16; i++)
    CRTS_rma_bcast_coll(x_data_addr+i, &ldm_x, sizeof(double*), 48+i);  
		// CRTS_rma_bcast_coll(void *dst, void *src, int len, int root)
		// x_data_addr[0]~x_data_addr[15] -> addr of core 48 ~ core 63

  int nnz_ind;
  int y_id = _MYID; // block id
  int start_y=0; // start rows of this block
  int start_nz=0, end_nz=0;
  int ldm_blkncy[2];
  double ldm_y[blk_y_size_t]; //4096
  double ldm_data[max_l_nnz_t]; // 2^11 = 2048
  //int ldm_locate[max_l_nnz_t]; // 2^11 = 2048
  long ldm_locate[max_l_nnz_t]; // 2^11 = 2048
  int len_nz; // number of none zeros in this small block for calculation
  int curr_ind_nz; // current index of none zeros in this small block for calculation
  int ind_x, ind_y; // index of x and index of y of this none zero
  int len_y=0;
  int big_blk_x; // big block x id, ind_x / 16384
  int curr_small_blk_x;
  int small_blk_x;
  int small_blk_off; // used in rma
  int volatile rma_rply;
  int outofbound = 0;
	//printf("iter_y-x=%d,%d\n",iter_y,iter_x);
  for(i=0; i<iter_y; i++)
  {
    // index of none zeros in this block
#ifdef debug_s		
if(_MYID==0)	{
	printf("=====iter_y|x=%d|%d,%d cal=%d iter_y,%d of %d x-blks\n",iter_y,iter_x,_MYID,i,y_id,n_blks);//9 1 1
	}
//		printf("%d cal=%d %d %d\n",_MYID,n_blks,iter_x,iter_y);//9 1 1
#endif		
    if(y_id < n_blks)   //每个线程做一大行
    {
      CRTS_dma_get(ldm_blkncy, blkncy+y_id, 2*sizeof(int));//得到每个大块的起始非零元位置与终止非零元位置
      start_nz = ldm_blkncy[0];
      end_nz = ldm_blkncy[1];

	//if(_MYID==0 && i==3)printf("start_nz=%d,end_nz=%d\n",start_nz,end_nz);

      // init len_y
      start_y = y_id << blk_y_size;//y_id*4096   48*4096=196608行号的上限  //得到每个线程起始行位置
      len_y = (start_y + blk_y_size_t > n_rows) ? (n_rows - start_y) : blk_y_size_t;//最大等于4096

#ifdef debug_s		
		//printf("%d cal---=%d %d %d %d %d\n",_MYID,y_id,start_y,len_y,start_nz,end_nz);
#endif		
      for(m=0; m<len_y; m++)
        ldm_y[m] = 0.;
    }

    // init nnz_ind
    nnz_ind = start_nz;//全局的
    curr_ind_nz = 0;//每个中块内局部的索引
		//printf("iter_x=%d\n",iter_x);
    for(j=0; j<iter_x; j++)
    {

			// printf("%d jbegin=%d\n",_MYID,j);
      // get x in core 48-64
      outofbound = 0;
      curr_small_blk_x = -1;
      CRTS_ssync_array();
#ifdef debug_s		
if(_MYID==0)	printf("*** %d cal=%d iter_x of %d iter_x-loop,i=%d\n",_MYID,j,iter_x,i);//9 1 1
		//printf("%d cal-first-syn--=%d %d %d %d\n",_MYID,start_y,len_y,start_nz,end_nz);
#endif		
      // calculate y = A.x
      while(nnz_ind < end_nz)
      {
        if(curr_ind_nz == 0) // get none zeros
        {
          len_nz = (nnz_ind + max_l_nnz_t > end_nz) ? (end_nz - nnz_ind) : max_l_nnz_t;//=2048
          CRTS_dma_get(ldm_data, data+nnz_ind, len_nz*sizeof(double));
          //CRTS_dma_get(ldm_locate, locate+nnz_ind, len_nz*sizeof(int));
          CRTS_dma_get(ldm_locate, locate+nnz_ind, len_nz*sizeof(long));
        }
#ifdef debug_s		
	  if(_MYID==0){
    printf("333 -- %d %d \n",curr_ind_nz,nnz_ind);
			for(int ttt=0;ttt<len_nz;ttt++){
    printf("444--%d %lf %d \n",ttt,ldm_data[ttt],ldm_locate[ttt]);
		  }
		}
#endif		
        // calculate
        while(curr_ind_nz < len_nz)
        {
          ind_x = ldm_locate[curr_ind_nz] >> blk_y_size;//位于该大块的第几列 ldm_locate/2^12(4096) //是不是原始矩阵中的列号？

#ifdef debug_s		
					if(_MYID==0&&i==3){
						printf("ldm_locate[%d]=%lf\n",curr_ind_nz,ldm_locate[curr_ind_nz]);
						}
#endif		

          big_blk_x = ind_x >> x_data_size;//位于第几个2的14次方里面 ind_x/2^14

          if(big_blk_x >= ((j+1)<<4)) // out of x bound, need new x block//列号不能超过262144 (2^14*16) 
						//当iter_x =1 时，big_blk_x 要小于16,判断矩阵的列数有多少，如果大于2^14*16，就提示报错，退出
          { 
            outofbound = 1;
            break;
          }
          else
          {
            small_blk_x = ind_x >> blk_x_size;//位于大块中的第几个小块，按照512划分,计算出非零元元素在一大行中的列数，即原始矩阵中的列数
            ind_y = ldm_locate[curr_ind_nz] - (ind_x << blk_y_size);//非零元所在的行号,在一行大块中的行号

#ifdef debug_s 
           if(y_id==1&&i==0&&j==0)
					 {
						 printf("s_debug %d-%d-%d-%d\n",curr_ind_nz,ind_x,ind_y,small_blk_x);
						 }
#endif
            if(curr_small_blk_x == small_blk_x)//判断是否是一个小块
            {
#ifdef debug_s 
           if(y_id==1&&ind_y==901) printf("ldm_y0:%d-%d-%d-%d-%d,%lf-%lf-%lf\n",curr_ind_nz,ind_y,ind_x,small_blk_x,ind_x - (small_blk_x << blk_x_size),ldm_data[curr_ind_nz],ldm_x[ind_x - (small_blk_x << blk_x_size)],ldm_y[ind_y]);
           //if(y_id==1&&ind_y==901) printf("ldm_y0:%d-%d,%lf-%lf-%lf\n",blk_x_size,blk_x_size_t,ldm_data[curr_ind_nz],ldm_x[ind_x - (small_blk_x << blk_x_size)],ldm_y[ind_y]);
#endif					 
              ldm_y[ind_y] += ldm_data[curr_ind_nz] * ldm_x[ind_x - (small_blk_x << blk_x_size)];
            }
            else // need rma
            {
#ifdef debug_s		
		//printf("%d 333333=%d %d \n",_MYID,small_blk_x,big_blk_x);
		//printf("%d ind_x=%d \n",_MYID,ind_x);
#endif		
              small_blk_off = small_blk_x - (big_blk_x << (x_data_size - blk_x_size)); // x_data_size=14 blk_x_size=9  ?????????
#ifdef debug_s		
		//printf("%d cal-blk_off2=%d\n",_MYID,small_blk_off);
#endif		
              big_blk_x -= (j<<4); // id of the remote core is big_blk_x + 48
              CRTS_rma_get(ldm_x, blk_x_size_t*sizeof(double), big_blk_x+48, x_data_addr[big_blk_x] + (small_blk_off<<blk_x_size), &rma_rply);//一次取一个小块所需x向量段(512个)

              /*
							if(y_id==1)
							{
								printf("rma0:%d-%d-%d-%d\n",curr_ind_nz,ind_y,ind_x,small_blk_x);
								printf("rma:%d-%d-%d\n",blk_x_size_t,big_blk_x+48,small_blk_off);
								for(int jj=0;jj<blk_x_size_t;j++)
									printf("rma-ldm:ldm_x[%d]=%lf\n",jj,ldm_x[jj]);
							}
              */
              ldm_y[ind_y] += ldm_data[curr_ind_nz] * ldm_x[ind_x - (small_blk_x << blk_x_size)]; //
              curr_small_blk_x = small_blk_x;
            }

#ifdef debug_s		
	  if(_MYID==0){
    printf("555 -- %d %d %d\n",curr_ind_nz,nnz_ind,outofbound);
		}
#endif		
            curr_ind_nz ++;
            nnz_ind ++;
          }

#ifdef debug_s		
if(_MYID==0){if(i==3){
	printf("%d 000000=%d %d %d %d \n",_MYID,curr_ind_nz,len_nz,nnz_ind,end_nz);
	printf("%d 111111=%d %d %d %d %d \n",_MYID,ind_x,x_data_size_t,big_blk_x,j,outofbound);}
	     }
#endif		
        }
        if(curr_ind_nz == len_nz) // end this small block
          curr_ind_nz = 0; // next small block need to be get from host memory
        if(outofbound) // out of x bound, need new x block
				{
					//printf("%d sparse matrix cols must be less than 30720*16!!!\n",_MYID);
          break;
				}
      }
      CRTS_ssync_array(); // wait for x data
    }
    if(y_id < n_blks) // put y
    {
      CRTS_dma_put(y+start_y, ldm_y, len_y*sizeof(double));
    }
    y_id += 48; // 48 calculate cores
  }
  ldm_free(ldm_x, blk_x_size_t*sizeof(double));
}

/**
 * store x data for spmv in slave
 * _data : spmv data
 */
// x_data_size_t = 2^14 = 4096
void x_data_new(_spmv_data_t *_data)
{
  ldm_x = (double*)ldm_malloc(x_data_size_t*sizeof(double)); //2^14
  int n_rows = _data->n_rows;
  int n_cols = _data->n_cols;
  int n_blks = _data->n_blks;
  int iter_y = (n_blks + 47) / 48; //y direction block numbers //按照大块行分的迭代次数
  int len_x_once = x_data_size_t << 4; // 2^14*16
  int iter_x = (n_cols + len_x_once - 1) >> (x_data_size + 4); //x direction iterations ,include 16 data cores
  //int iter_x = (n_cols + len_x_once - 1) / len_x_once; //x direction iterations ,include 16 data cores
  int i, j, k, m, n, p;
  // bcast address of ldm_x to core 0-47
  double *addr[1];
  addr[0] = ldm_x;
  for(i=0; i<16; i++)
    CRTS_rma_bcast_coll(x_data_addr+i, addr, sizeof(double*), 48+i); 
		// CRTS_rma_bcast_coll(void *dst, void *src, int len, int root) 
		// x_data_addr[0]~x_data_addr[15] -> addr of core 48 ~ core 63
  int start_x;
  int len_x;
  double *x = _data->x;
  for(i=0; i<iter_y; i++)
  {
    start_x = (_MYID - 48) << x_data_size; //x_data_size = 14
#ifdef debug_s		
//		printf("%d strat_x=%d %d %d %d\n",_MYID,start_x,n_cols,iter_x,iter_y);
#endif		
    for(j=0; j<iter_x; j++)
    {
      if(start_x < n_cols)
      {
#ifdef debug_s		
	//	printf("%d strat_x----=%d %d %d %d\n",_MYID,start_x,n_cols,iter_x,iter_y,len_x);
#endif		
        //len_x = (start_x + x_data_size_t > n_cols) ? (n_cols - start_x) : x_data_size_t; //every core get none zero number
        len_x = (start_x + x_data_size_t > n_cols) ? (n_cols - start_x+1) : x_data_size_t; //every core get none zero number
        CRTS_dma_get(ldm_x, x+start_x, len_x*sizeof(double));
      }
#ifdef debug_s		
//		printf("%d strat_x+++=%d %d %d %d\n",_MYID,start_x,n_cols,iter_x,iter_y,len_x);
#endif		
      CRTS_ssync_array(); // wait for calculation
      CRTS_ssync_array();
      start_x += len_x_once;
    }
#ifdef debug_s		
		if(_MYID==50)
		{
			 printf("len_x=%d-%d-%d\n",len_x,start_x,n_cols);
       for(int tt=0;tt<len_x;tt++)
				 printf("ldm_x[%d]=%lf\n",tt,ldm_x[tt]);
		}
#endif		
  }
  ldm_free(ldm_x, x_data_size_t*sizeof(double));
}

void spmv_slv_new(_spmv_data_t *_data)
{
	//printf("_MYID=%d,x_data_size_t=%d \n",_MYID,x_data_size_t);
  if(_ROW < 6) //前6行从核进行计算
    calcu_new(_data);
  else         //后2行从核干什么,存储X向量？
    x_data_new(_data);
}

void spmv_block(Data_spmv *D_SPMV)
{
	//int block_row_size = 1024;
	//int block_col_size = 1024;
	//int block_row_size = 1024;
	//int block_col_size = 1024;
	int block_row_size = D_SPMV->block_row_size;
	int block_col_size = D_SPMV->block_col_size;
	T_data ldm_y[block_row_size];
	T_data ldm_x[block_col_size];
	int n_blocks = D_SPMV->n_blocks;
	Block* blocks = D_SPMV->blocks;
	T_data *x = D_SPMV->x;
	T_data *y = D_SPMV->y;
	//T_idx *rowid = D_SPMV->rowid;
	//T_idx *colid = D_SPMV->colid;
	Pos *pos = D_SPMV->pos;
	T_data *data = D_SPMV->data;
	int blk_data_size = 512;
	T_data ldm_data[blk_data_size];
	Pos ldm_pos[blk_data_size];
	int curr_nz = 0;
	int ldm_data_ind = 0;
	int data_len = 0;
	int end_blk_nz = 0;
	int i, j, k;
	Tile *tiles = NULL;
	Unit *units = NULL;
	int n_units = -1;
	int start_x, len_x, ind=0;
	int start_row, n_rows, n_tiles;
	int rid, cid;
	int m, n;
	int real_start_x;
	int unit_start_x;
	Unit unit;
	for(i=_MYID; i<n_blocks; i+=64)
	{
		n_tiles = blocks[i].n_tiles;
		if(n_tiles == 0)
			continue;
		for(j=0; j<block_row_size; j++)
			ldm_y[j] = 0.0;
		tiles = blocks[i].tiles;
		ind = blocks[i].start_nnz;
		curr_nz = ind;
		end_blk_nz = curr_nz + blocks[i].nnz;
		start_row = blocks[i].start_row;
		n_rows = blocks[i].n_rows;
		for(j=0; j<n_tiles; j++)
		{
			n_units = tiles[j].n_units;
			units = tiles[j].units;
			start_x = tiles[j].start_x;
			for(m=0; m<n_units; m++)
			{
				/* old code
				unit_start_x = units[m].start_x;
				len_x = units[m].len_x;
				*/
				/* Compress */
				unit = units[m];
				unit_start_x = unit.start_x;
				len_x = unit.len_x;
				/* End change */
				real_start_x = start_x + unit_start_x;
				CRTS_dma_get(ldm_x+unit_start_x, x+real_start_x, len_x*sizeof(T_data));
			}
			//start_x = tiles[j].start_x;
			//len_x = tiles[j].len_x;
			//CRTS_dma_get(ldm_x, x+start_x, len_x * sizeof(T_data));
			/* Old code */
			/*
			for(k=0; k<tiles[j].nnz; k++)
			{
				//rid = rowid[ind];
				//cid = colid[ind];
				rid = pos[ind].rowid;
				cid = pos[ind].colid;
				ldm_y[rid] += ldm_x[cid] * data[ind];
				ind ++;
			}
			*/
			/* New code with DMA */
			int nnz = tiles[j].nnz;
			int niter = nnz / blk_data_size;
			int remind = nnz - (niter * blk_data_size);
			for(k=0; k<niter; k++)
			{
				CRTS_dma_get(ldm_data, data+ind, blk_data_size * sizeof(T_data));
				CRTS_dma_get(ldm_pos, pos+ind, blk_data_size * sizeof(Pos));
				for(n=0; n<blk_data_size; n++)
				{
					rid = ldm_pos[n].rowid;
					cid = ldm_pos[n].colid;
					ldm_y[rid] += ldm_x[cid] * ldm_data[n];
				}
				ind += blk_data_size;
			}
			if(remind > 0)
			{
				CRTS_dma_get(ldm_data, data+ind, remind * sizeof(T_data));
				CRTS_dma_get(ldm_pos, pos+ind, remind * sizeof(Pos));
				for(n=0; n<remind; n++)
				{
					rid = ldm_pos[n].rowid;
					cid = ldm_pos[n].colid;
					ldm_y[rid] += ldm_x[cid] * ldm_data[n];
				}
				ind += remind;
			}
		}
		CRTS_dma_put(y+start_row, ldm_y, n_rows * sizeof(T_data));
	}
}
