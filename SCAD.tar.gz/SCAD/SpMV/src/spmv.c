/**
 * write by guoheng on 2019-8-12
 * spmv functions interface
 */
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <crts.h>
#include "SWAF_spmv.h"

/* slave function for spmv */
extern SLAVE_FUN(spmv_slv)(void *_data);
extern SLAVE_FUN(spmv_slv_new)(void *_data);
extern SLAVE_FUN(spmv_slv_new_int)(void *_data);
extern SLAVE_FUN(spmv_block)(Data_spmv *D_SPMV);

#if 0
/**
 * init spmv of slave
 * n_rows : # of rows of the sparse matrix
 * n_cols : # of cols of the sparse matrix
 * nnz : # of none zeors of the sparse matrix
 * face_cel_p : map of the face and the cell
 * data : data of the none zeros in sparse matrix
 * _data : data used in spmv in slave
 */
void spmv_init(int n_rows, int n_cols, int nnz, l_num2_t *face_cel_p, double *data, spmv_data_t *_data)
{
  _data->n_rows = n_rows;
  _data->n_cols = n_cols;
  _data->nnz = nnz;
  int n_blks = (n_rows + (1<<blk_y_size) - 1) >> blk_y_size; // # of y blocks
  _data->n_blks = n_blks;
  int n_blk_x = (n_cols + (1<<blk_x_size) - 1) >> blk_x_size; // # of x blocks
  int **nnz_small_blk;
  nnz_small_blk = (int**)malloc(n_blks*sizeof(int*)); // # of none zeros in small_blk(blk_y * blk_x)
  int i, j, k;
  for(i=0; i<n_blks; i++)
    nnz_small_blk[i] = (int*)malloc(n_blk_x*sizeof(int));
  for(i=0; i<n_blks; i++)
    for(j=0; j<n_blk_x; j++)
      nnz_small_blk[i][j] = 0;
  int blk_id = -1;
  int x_id = -1;
  int ii, jj;
  int real_nnz = 0; // real # of none zeros
  for(i=0; i<nnz; i++)
  {
    ii = face_cel_p[i][0];
    jj = face_cel_p[i][1];
    if(ii < n_rows)
    {
      real_nnz ++;
      blk_id = ii >> blk_y_size;
      x_id = jj >> blk_x_size;
      nnz_small_blk[blk_id][x_id] ++;
    }
    if(jj < n_rows)
    {
      real_nnz ++;
      blk_id = jj >> blk_y_size;
      x_id = ii >> blk_x_size;
      nnz_small_blk[blk_id][x_id] ++;
    }
  }
  _data->nnz = real_nnz;
  printf("real_nnz = %d\n", real_nnz);
  // check nnz_small_blk
  for(i=0; i<n_blks; i++)
  {
    for(j=0; j<n_blk_x; j++)
      printf("%d ", nnz_small_blk[i][j]);
    printf("\n");
  }
  // sort with nnz_small_blk
  double *tmp_data = (double*)malloc(real_nnz*sizeof(double));
  int *ind_x = (int*)malloc(real_nnz * sizeof(int));
  int *ind_y = (int*)malloc(real_nnz * sizeof(int));
  int *nnz_small_blkncy = (int*)malloc(((n_blks*n_blk_x)+1)*sizeof(int));
  int index_tmp = 1;
  nnz_small_blkncy[0] = 0;
  for(i=0; i<n_blks; i++)
    for(j=0; j<n_blk_x; j++)
    {
      nnz_small_blkncy[index_tmp] = nnz_small_blk[i][j] + nnz_small_blkncy[index_tmp-1];
      index_tmp ++;
    }
  int *ind_small_blk = (int*)malloc(n_blks*n_blk_x*sizeof(int));
  for(i=0; i<n_blks*n_blk_x; i++)
    ind_small_blk[i] = 0;
  int index_x_tmp = 0;
  for(i=0; i<nnz; i++)
  {
    ii = face_cel_p[i][0];
    jj = face_cel_p[i][1];
    if(ii < n_rows)
    {
      blk_id = ii >> blk_y_size;
      x_id = jj >> blk_x_size;
      index_x_tmp = blk_id * n_blk_x + x_id;
      index_tmp = nnz_small_blkncy[index_x_tmp] + ind_small_blk[index_x_tmp]; // start + offset
      tmp_data[index_tmp] = data[2*i];
      ind_x[index_tmp] = jj;
      ind_y[index_tmp] = ii;
      ind_small_blk[index_x_tmp] ++;
    }
    if(jj < n_rows)
    {
      blk_id = jj >> blk_y_size;
      x_id = ii >> blk_x_size;
      index_x_tmp = blk_id * n_blk_x + x_id;
      index_tmp = nnz_small_blkncy[index_x_tmp] + ind_small_blk[index_x_tmp]; // start + offset
      tmp_data[index_tmp] = data[2*i+1];
      ind_x[index_tmp] = ii;
      ind_y[index_tmp] = jj;
      ind_small_blk[index_x_tmp] ++;
    }
  }
  int max_l_nnz_t = 1 << max_l_nnz;
  // set middle blocks
  int *n_mid_blk = (int*)malloc(n_blks*sizeof(int));
  int **nnz_mid_blk = (int**)malloc(n_blks*sizeof(int*));
  for(i=0; i<n_blks; i++)
    nnz_mid_blk[i] = (int*)malloc(n_blk_x*sizeof(int));
  for(i=0; i<n_blks; i++)
    for(j=0; j<n_blk_x; j++)
      nnz_mid_blk[i][j] = 0;
  //int **mid_blk_x_bp = (int**)malloc(n_blks*sizeof(int));
  /*
  for(i=0; i<n_blks; i++)
    mid_blk_x_bp[i] = (int*)malloc((n_blk_x+1)*sizeof(int)); // x break point in middle blocks
  for(i=0; i<n_blks; i++)
    mid_blk_x_bp[i][0] = 0;
    */
  int ind_mid_blk = 0;
  int tmp_nnz = 0;
  for(i=0; i<n_blks; i++)
  {
    ind_mid_blk = 0;
    tmp_nnz = nnz_small_blk[i][0];
    //mid_blk_x_bp[i][ind_mid_blk] = 0;
    for(j=1; j<n_blk_x; j++)
    {
      if(tmp_nnz > max_l_nnz_t)
      {
        printf("Error, nnz of one small block is more than max_l_nnz_t, in blk_y %d blk_x %d\n", i, j);
        exit(0);
      }
      else
      {
        if(tmp_nnz + nnz_small_blk[i][j] > max_l_nnz_t)
				nd_mid_blk; // number of middle blocks in every big block y
				376     //mid_blk_x_bp[i][ind_mid_blk] = j;
				377   }
				378   // check nnz_mid_blk in host
				379  /*
				/ind_small_blk                                                                  
				427     tmp_nnz = 0;
				428     for(j=0; j<n_mid_blk[i]; j++)
				429     {
				430       tmp_nnz += nnz_mid_blk[i][j];
				431     }
				432     blkncy[i+1] = blkncy[i] + tmp_nnz;//存每个大块之前所有大块非零元个数
				433   }
				434   _data->data = tmp_data;
				435   _data->locate = locate;
				436   _data->blkncy = blkncy;
				437   _data->nnz_mid_blk = nnz_mid_blk;
				438   _data->n_mid_blk = n_mid_blk;
				439   //_data->mid_blk_x_bp = mid_blk_x_bp;
				440   // free
				441   for(i=0; i<n_blks; i++)
				442     free(nnz_small_blk[i]);
				443   free(nnz_small_blk);
				444   free(nnz_small_blkncy);
				445   free(ind_small_blk);
				446   //free(n_big_blk);
				447   free(ind_x);
				448   free(ind_y);
				449   /* // free in spmv_finish
				450   for(i=0; i<n_blks; i++)
				451     free(mid_blk_x_bp[i]);
				452   free(mid_blk_x_bp);
				453   */
				454 }
				455 
				456 
				457 /**
				458  * add by guoheng on 2019-11-22
				459  * used {
          nnz_mid_blk[i][ind_mid_blk] = tmp_nnz;
     //     mid_blk_x_bp[i][ind_mid_blk] = j;
          tmp_nnz = nnz_small_blk[i][j];
        }
        else
          tmp_nnz += nnz_small_blk[i][j];
      }
    }
    // deal with j = n_blk_x
    nnz_mid_blk[i][ind_mid_blk] = tmp_nnz;
    ind_mid_blk ++;
    n_mid_blk[i] = ind_mid_blk; // number of middle blocks in every big block y
    //mid_blk_x_bp[i][ind_mid_blk] = j;
  }
  // check nnz_mid_blk in host
  /*
  for(i=0; i<n_blks; i++)
  {
    for(j=0; j<n_mid_blk[i]; j++)
      printf("%d ", nnz_mid_blk[i][j]);
    printf("\n");
  }
  printf("===================\n");
  printf("address: %p, %p\n", nnz_mid_blk, nnz_mid_blk[0]);
  */
  // end check
  // set locate
  long *locate = (long*)malloc(real_nnz*sizeof(long));
  for(i=0; i<real_nnz; i++)
  {
    blk_id = ind_y[i] >> blk_y_size;
    locate[i] = ((long)ind_x[i]<<(long)blk_y_size) + (long)(ind_y[i] - (blk_id << blk_y_size));
  }
  // set blkncy
  int *blkncy = (int*)malloc((n_blks+1)*sizeof(int));
  blkncy[0] = 0;
  for(i=0; i<n_blks; i++)
  {
    tmp_nnz = 0;
    for(j=0; j<n_mid_blk[i]; j++)
    {
      tmp_nnz += nnz_mid_blk[i][j];
    }
    blkncy[i+1] = blkncy[i] + tmp_nnz;
  }
  _data->data = tmp_data;
  _data->locate = locate;
  _data->blkncy = blkncy;
  _data->nnz_mid_blk = nnz_mid_blk;
  _data->n_mid_blk = n_mid_blk;
  //_data->mid_blk_x_bp = mid_blk_x_bp;
  // free
  for(i=0; i<n_blks; i++)
    free(nnz_small_blk[i]);
  free(nnz_small_blk);
  //free(n_big_blk);
  free(ind_x);
  free(ind_y);
  /* // free in spmv_finish
  for(i=0; i<n_blks; i++)
    free(mid_blk_x_bp[i]);
  free(mid_blk_x_bp);
  */
}
#endif

/**
 * init spmv of slave
 * n_rows : # of rows of the sparse matrix
 * n_cols : # of cols of the sparse matrix
 * nnz : # of none zeors of the sparse matrix
 * face_cel_p : map of the face and the cell
 * data : data of the none zeros in sparse matrix
 *         values is initalized in main funciton
 * _data : data used in spmv in slave
 */
void SWAF_spmv_init(int n_rows, int n_cols, int nnz, l_num2_t *face_cel_p, double *data, spmv_data_t *_data)
{
  _data->n_rows = n_rows;
  _data->n_cols = n_cols;
  _data->nnz = nnz;
  int n_blks = (n_rows + (1<<blk_y_size) - 1) >> blk_y_size; // # of y blocks
	_data->n_blks = n_blks;            // n_rows+(4096-1)/4096,按照4096划分行？

  int n_blk_x = (n_cols + (1<<blk_x_size) - 1) >> blk_x_size; // # of x blocks
	//n_cols+(512-1)/512,按照512划分列？
	
  int **nnz_small_blk;
//printf("n_blks======%d,%d\n",n_blks,n_blk_x);
  nnz_small_blk = (int**)malloc(n_blks*sizeof(int*)); // # of none zeros in every small_blk(blk_y * blk_x), size is number of n_blks*n_blk_x
  int i, j, k;
  for(i=0; i<n_blks; i++)
    nnz_small_blk[i] = (int*)malloc(n_blk_x*sizeof(int));
  for(i=0; i<n_blks; i++)
    for(j=0; j<n_blk_x; j++)
      nnz_small_blk[i][j] = 0;
  int blk_id = -1;
  int x_id = -1;
  int ii, jj;
  int real_nnz = 0; // real # of none zeros
	//printf("ii,jj====%d,%d,%d\n",face_cel_p[0][0],face_cel_p[0][1],n_rows);
	//printf("blk_id,x_id====%d,%d,%d,%d\n",ii >> 12,jj >> 9,jj >> 12,ii >> 9);
  for(i=0; i<nnz; i++)
  {
    ii = face_cel_p[i][0];
    jj = face_cel_p[i][1];
    if(ii < n_rows)
    {
      real_nnz ++;
      blk_id = ii >> blk_y_size; // ii/4092
      x_id = jj >> blk_x_size;   // jj/512
      nnz_small_blk[blk_id][x_id] ++;//存每个小块有多少非零元
    }
    if(jj < n_rows)//jj不应该对应n_cols吗？H----判断两次，因为是对称矩阵
    {
      real_nnz ++;
      blk_id = jj >> blk_y_size;
      x_id = ii >> blk_x_size;
      nnz_small_blk[blk_id][x_id] ++;
    }
  }
  _data->nnz = real_nnz;
  printf("real_nnz = %d,%d\n", real_nnz,n_rows);
  // check nnz_small_blk
  /*
  for(i=0; i<n_blks; i++)
  {
    for(j=0; j<n_blk_x; j++)
      printf("%d ", nnz_small_blk[i][j]);
    printf("\n");
  }
  */
  // sort with nnz_small_blk
  double *tmp_data = (double*)malloc(real_nnz*sizeof(double));
  int *ind_x = (int*)malloc(real_nnz * sizeof(int));
  int *ind_y = (int*)malloc(real_nnz * sizeof(int));
  int *nnz_small_blkncy = (int*)malloc(((n_blks*n_blk_x)+1)*sizeof(int));
  int index_tmp = 1;
  nnz_small_blkncy[0] = 0;
  for(i=0; i<n_blks; i++)
    for(j=0; j<n_blk_x; j++)
    {
      nnz_small_blkncy[index_tmp] = nnz_small_blk[i][j] + nnz_small_blkncy[index_tmp-1];//存每个小块起始位置，该小块之前的小块的非零元总数,
      index_tmp ++;
    }
  int *ind_small_blk = (int*)malloc(n_blks*n_blk_x*sizeof(int));
  for(i=0; i<n_blks*n_blk_x; i++)
    ind_small_blk[i] = 0;
  int index_x_tmp = 0;
  for(i=0; i<nnz; i++)
  {
    ii = face_cel_p[i][0];
    jj = face_cel_p[i][1];
    if(ii < n_rows)
    {
      blk_id = ii >> blk_y_size; //该非零元所属的小块的行号
      x_id = jj >> blk_x_size;  //该非零元所属的小块的列号
      index_x_tmp = blk_id * n_blk_x + x_id;//该非零元所属的小块号
      index_tmp = nnz_small_blkncy[index_x_tmp] + ind_small_blk[index_x_tmp]; // start + offset该非零元在该小块的局部位置+该非零元所属的小块之前的小块非零元总数
      tmp_data[index_tmp] = data[2*i];//将非零元数据存入tmp_data
      ind_x[index_tmp] = jj;//反存该非零元在大矩阵的列号
      ind_y[index_tmp] = ii;//反存该非零元在大矩阵的行号
      ind_small_blk[index_x_tmp] ++;//代表所属小块的第几个非零元
    }
    if(jj < n_rows)
    {
      blk_id = jj >> blk_y_size;
      x_id = ii >> blk_x_size;
      index_x_tmp = blk_id * n_blk_x + x_id;
      index_tmp = nnz_small_blkncy[index_x_tmp] + ind_small_blk[index_x_tmp]; // start + offset
      tmp_data[index_tmp] = data[2*i+1];
      ind_x[index_tmp] = ii;
      ind_y[index_tmp] = jj;
      ind_small_blk[index_x_tmp] ++;
    }
  }
  int max_l_nnz_t = 1 << max_l_nnz;
  // set middle blocks
  int *n_mid_blk = (int*)malloc(n_blks*sizeof(int));
  int **nnz_mid_blk = (int**)malloc(n_blks*sizeof(int*));
  for(i=0; i<n_blks; i++)
    nnz_mid_blk[i] = (int*)malloc(n_blk_x*sizeof(int));
  for(i=0; i<n_blks; i++)
    for(j=0; j<n_blk_x; j++)
      nnz_mid_blk[i][j] = 0;
  /*
  int **mid_blk_x_bp = (int**)malloc(n_blks*sizeof(int));
  for(i=0; i<n_blks; i++)
    mid_blk_x_bp[i] = (int*)malloc((n_blk_x+1)*sizeof(int)); // x break point in middle blocks
  for(i=0; i<n_blks; i++)
    mid_blk_x_bp[i][0] = 0;
    */
  int ind_mid_blk = 0;
  int tmp_nnz = 0;
  for(i=0; i<n_blks; i++)
  {
    ind_mid_blk = 0;
    tmp_nnz = nnz_small_blk[i][0];
//printf("tmp_nnz====%d,%d,%d\n",tmp_nnz,max_l_nnz_t,i);
   // mid_blk_x_bp[i][ind_mid_blk] = 0;
    for(j=1; j<n_blk_x; j++)
    {
      if(tmp_nnz > max_l_nnz_t)//判断第一列块的非零元数是否大于2048=2^11,大于的话退出，否则一直加
      {
        printf("Error, nnz of one small block is more than max_l_nnz_t, in blk_y %d blk_x %d\n", i, j);
        exit(0);
      }
      else
      {
        if(tmp_nnz + nnz_small_blk[i][j] > max_l_nnz_t)
        {
          nnz_mid_blk[i][ind_mid_blk] = tmp_nnz;
          ind_mid_blk ++;
    //      mid_blk_x_bp[i][ind_mid_blk] = j;
          tmp_nnz = nnz_small_blk[i][j];
        }
        else//每非零元个数和小于2048，几个小块组成中间块
          tmp_nnz += nnz_small_blk[i][j];
      }
    }
    // deal with j = n_blk_x
    nnz_mid_blk[i][ind_mid_blk] = tmp_nnz;
    ind_mid_blk ++;
    n_mid_blk[i] = ind_mid_blk; // number of middle blocks in every big block y
    //mid_blk_x_bp[i][ind_mid_blk] = j;
  }
  // check nnz_mid_blk in host
 /*
  for(i=0; i<n_blks; i++)
  {
    for(j=0; j<n_mid_blk[i]; j++)
      printf("%d ", nnz_mid_blk[i][j]);
    printf("\n");
  }
  printf("===================\n");
  printf("address: %p, %p\n", nnz_mid_blk, nnz_mid_blk[0]);
  */
  // end check
  // set locate
  long *locate = (long*)malloc(real_nnz*sizeof(long));
  for(i=0; i<real_nnz; i++)
  {
    blk_id = ind_y[i] >> blk_y_size;//判断该非零元属于第几个大块行号 (ind_y[i]/4096)
    locate[i] = ((long)ind_x[i]<<(long)blk_y_size) + (long)(ind_y[i] - (blk_id << blk_y_size));//感觉像大块内按列轮的顺序,非零元在大块行里面的排序
		//ind_x[i]*4096 + (ind_y[i]-(blk_id*4096)) = cols*4096 + (rows-(blk_id*4096))
  }
	//printf("locate=====%d,%d,%d,%d\n",locate[0],locate[1],locate[2],locate[3]);
	//printf("111locate=====%d,%d,%d,%d,%d,%d,%d,%d\n",ind_y[0],ind_x[0],ind_y[1],ind_x[1],ind_y[2],ind_x[2],ind_y[3],ind_x[3]);
	//locate=====1085440,265,356353,4183
	//111locate=====0,265,265,0,1,87,87,1
  // debug
  int num_get_data = 0;
  /*
  for(i=0; i<n_blk_x; i++)
  {
    if(nnz_small_blk[0][i] != 0)
    {
      printf("%d ", nnz_small_blk[0][i]);
      num_get_data ++;
    }
  }
  printf("in host, num_get_data=%d\n", num_get_data);
  */
  /*
  for(i=0; i<n_blks; i++)
  {
    for(j=0; j<n_blk_x; j++)
      printf("%d ", nnz_small_blk[i][j]);
    printf("\n");
  }
  */
  // end debug
  // set blkncy
  int *blkncy = (int*)malloc((n_blks+1)*sizeof(int));
  blkncy[0] = 0;
  for(i=0; i<n_blks; i++)
  {
    tmp_nnz = 0;
    for(j=0; j<n_mid_blk[i]; j++)
    {
      tmp_nnz += nnz_mid_blk[i][j];
    }
    blkncy[i+1] = blkncy[i] + tmp_nnz;//存每个大块之前所有大块非零元个数
  }
  _data->data = tmp_data;
  _data->locate = locate;
  _data->blkncy = blkncy;
  _data->nnz_mid_blk = nnz_mid_blk;
  _data->n_mid_blk = n_mid_blk;
  //_data->mid_blk_x_bp = mid_blk_x_bp;
  // free
  for(i=0; i<n_blks; i++)
    free(nnz_small_blk[i]);
  free(nnz_small_blk);
  free(nnz_small_blkncy);
  free(ind_small_blk);
  //free(n_big_blk);
  free(ind_x);
  free(ind_y);
  /* // free in spmv_finish
  for(i=0; i<n_blks; i++)
    free(mid_blk_x_bp[i]);
  free(mid_blk_x_bp);
  */
}

/**
 * add by hexiang on 2020-9-12
 * used for init sparse matrix with coo format
 * n_rows : # of rows of the sparse matrix
 * n_cols : # of cols of the sparse matrix
 * nnz : # of none zeors of the sparse matrix
 * rows : index of y direction none zeros of the sparse matrix
 * cols : index of x direction none zeros of the sparse matrix
 * data : data of the none zeros in sparse matrix
 *         values is initalized in main funciton
 * _data : data used in spmv in slave
 */
void SWAF_spmv_init_coo_d(int n_rows, int n_cols, int nnz, T_idx *rows, T_idx *cols, T_data *data, spmv_data_t *_data)
{
  _data->n_rows = n_rows;
  _data->n_cols = n_cols;
  _data->nnz = nnz;
  int n_blks = (n_rows + (1<<blk_y_size) - 1) >> blk_y_size; // # of y blocks
	_data->n_blks = n_blks;            // n_rows+(4096-1)/4096,按照4096划分行？

  int n_blk_x = (n_cols + (1<<blk_x_size) - 1) >> blk_x_size; // # of x blocks
	//n_cols+(512-1)/512,按照512划分列？
	
  int **nnz_small_blk;
//printf("n_blks======%d,%d\n",n_blks,n_blk_x);
  nnz_small_blk = (int**)malloc(n_blks*sizeof(int*)); // # of none zeros in every small_blk(blk_y * blk_x), size is number of n_blks*n_blk_x
  int i, j, k;
  for(i=0; i<n_blks; i++)
    nnz_small_blk[i] = (int*)malloc(n_blk_x*sizeof(int));
  for(i=0; i<n_blks; i++)
    for(j=0; j<n_blk_x; j++)
      nnz_small_blk[i][j] = 0;
  int blk_id = -1;
  int x_id = -1;
  int ii, jj;
  int real_nnz = nnz; // real # of none zeros
	//printf("ii,jj====%d,%d,%d\n",face_cel_p[0][0],face_cel_p[0][1],n_rows);
	//printf("blk_id,x_id====%d,%d,%d,%d\n",ii >> 12,jj >> 9,jj >> 12,ii >> 9);
	//printf("loc fo rows %p\n",rows);
	//for(i=0;i<10;i++){
	//	printf("coo_d,%d %d %d %lf \n",i,rows[i],cols[i],data[i]);
	//	}
	
  for(i=0; i<real_nnz; i++)
  {
    ii = rows[i];
    jj = cols[i];
    blk_id = ii >> blk_y_size; // ii/4092
    x_id = jj >> blk_x_size;   // jj/512
    nnz_small_blk[blk_id][x_id] ++;//存每个小块有多少非零元

		//if(blk_id==0 && x_id==0){printf("%d %d data[%d] = %lf\n",ii,jj,i,data[i]);}
  }
  _data->nnz = real_nnz;
  //printf("real_nnz = %d,%d\n", real_nnz,n_rows);
  // check nnz_small_blk
	
	//printf("n_rows=%d,n_cols=%d,n_blks=%d,n_blk_x=%d\n",n_rows,n_cols,n_blks,n_blk_x);

  /*
  for(i=0; i<n_blks; i++)
  {
    for(j=0; j<n_blk_x; j++)
     if(nnz_small_blk[i][j]!=0) printf("nnz_small_blk[%d][%d]=%d \n", i,j,nnz_small_blk[i][j]);
    printf("\n");
  }
	return 0;
  */
  // sort with nnz_small_blk
  double *tmp_data = (double*)malloc(real_nnz*sizeof(double));
  int *ind_x = (int*)malloc(real_nnz * sizeof(int));
  int *ind_y = (int*)malloc(real_nnz * sizeof(int));
  int *nnz_small_blkncy = (int*)malloc(((n_blks*n_blk_x)+1)*sizeof(int));
  int index_tmp = 1;
  nnz_small_blkncy[0] = 0;
	
	//printf("n_blks=%d,n_blk_x=%d\n",n_blks,n_blk_x);

  for(i=0; i<n_blks; i++){
    for(j=0; j<n_blk_x; j++)
    {
      nnz_small_blkncy[index_tmp] = nnz_small_blk[i][j] + nnz_small_blkncy[index_tmp-1];//存每个小块起始位置，该小块之前的小块的非零元总数,
      index_tmp ++;
    }
		//printf("nnz_small_blkncy[%d]=%d|%d\n",i*n_blk_x+j,nnz_small_blkncy[i*n_blk_x+j],index_tmp);
	}

	//	printf("nnz_small_blkncy=%d\n",nnz_small_blkncy[index_tmp-1]);
  int *ind_small_blk = (int*)malloc(n_blks*n_blk_x*sizeof(int));
  for(i=0; i<n_blks*n_blk_x; i++)
    ind_small_blk[i] = 0;
  int index_x_tmp = 0;
  for(i=0; i<real_nnz; i++)
  {
    ii = rows[i];
    jj = cols[i];
    blk_id = ii >> blk_y_size; //该非零元所属的小块的行号
    x_id = jj >> blk_x_size;  //该非零元所属的小块的列号
    index_x_tmp = blk_id * n_blk_x + x_id;//该非零元所属的小块号
    index_tmp = nnz_small_blkncy[index_x_tmp] + ind_small_blk[index_x_tmp]; // start + offset该非零元在该小块的局部位置+该非零元所属的小块之前的小块非零元总数
    tmp_data[index_tmp] = data[i];//将非零元数据存入tmp_data
    ind_x[index_tmp] = jj;//反存该非零元在大矩阵的列号
    ind_y[index_tmp] = ii;//反存该非零元在大矩阵的行号
    ind_small_blk[index_x_tmp] ++;//代表所属小块的第几个非零元

	//	printf("coo %d original`s index is r-%d,c-%d,new data index is %d\n",i,ii,jj,index_tmp);
//		printf("coo ind_x|ind_y[%d]=%d|%d\n",i,ind_x[index_tmp],ind_y[index_tmp]);
  }
  int max_l_nnz_t = 1 << max_l_nnz;
	
  // set middle blocks
  int tmp_nnz = 0;
  int *n_mid_blk = (int*)malloc(n_blks*sizeof(int));
  int **nnz_mid_blk = (int**)malloc(n_blks*sizeof(int*));
  for(i=0; i<n_blks; i++)
    nnz_mid_blk[i] = (int*)malloc(n_blk_x*sizeof(int));
  for(i=0; i<n_blks; i++)
    for(j=0; j<n_blk_x; j++)
      nnz_mid_blk[i][j] = 0;
  /*
  int **mid_blk_x_bp = (int**)malloc(n_blks*sizeof(int));
  for(i=0; i<n_blks; i++)
    mid_blk_x_bp[i] = (int*)malloc((n_blk_x+1)*sizeof(int)); // x break point in middle blocks
  for(i=0; i<n_blks; i++)
    mid_blk_x_bp[i][0] = 0;
    */
  int ind_mid_blk = 0;
//hexiang   for(i=0; i<n_blks; i++)
//hexiang   {
//hexiang     ind_mid_blk = 0;
//hexiang     tmp_nnz = nnz_small_blk[i][0];
//hexiang //printf("tmp_nnz====%d,%d,%d\n",tmp_nnz,max_l_nnz_t,i);
//hexiang    // mid_blk_x_bp[i][ind_mid_blk] = 0;
//hexiang     for(j=1; j<n_blk_x; j++)
//hexiang     {
//hexiang       if(tmp_nnz > max_l_nnz_t)//判断第一列块的非零元数是否大于2048=2^11,大于的话退出，否则一直加
//hexiang       {
//hexiang         printf("Error, nnz of one small block is more than max_l_nnz_t, in blk_y %d blk_x %d\n", i, j);
//hexiang         exit(0);
//hexiang       }
//hexiang       else
//hexiang       {
//hexiang         if(tmp_nnz + nnz_small_blk[i][j] > max_l_nnz_t)
//hexiang         {
//hexiang           nnz_mid_blk[i][ind_mid_blk] = tmp_nnz;
//hexiang           ind_mid_blk ++;
//hexiang     //      mid_blk_x_bp[i][ind_mid_blk] = j;
//hexiang           tmp_nnz = nnz_small_blk[i][j];
//hexiang         }
//hexiang         else//每非零元个数和小于2048，几个小块组成中间块
//hexiang           tmp_nnz += nnz_small_blk[i][j];
//hexiang       }
//hexiang     }
//hexiang     // deal with j = n_blk_x
//hexiang     nnz_mid_blk[i][ind_mid_blk] = tmp_nnz;
//hexiang     ind_mid_blk ++;
//hexiang     n_mid_blk[i] = ind_mid_blk; // number of middle blocks in every big block y
//hexiang     //mid_blk_x_bp[i][ind_mid_blk] = j;
//hexiang   }
 	
  // check nnz_mid_blk in host
 /*
  for(i=0; i<n_blks; i++)
  {
    for(j=0; j<n_blk_x; j++){
      printf("coo nnz_small_blk[%d][%d]=%d ", i,j,nnz_small_blk[i][j]);}
    printf("\n");
  }
  printf("===================\n");
  printf("address: %p, %p\n", nnz_mid_blk, nnz_mid_blk[0]);
  */
  // end check
  // set locate
   //int *locate = (int*)malloc(real_nnz*sizeof(int));
   long *locate = (long*)malloc(real_nnz*sizeof(long));
  for(i=0; i<real_nnz; i++)
  {
    blk_id = (ind_y[i]) >> blk_y_size;//判断该非零元属于第几个大块行号 (ind_y[i]/4096)
    locate[i] = ((long)(ind_x[i])<<(long)blk_y_size) + (long)(ind_y[i] - (blk_id << blk_y_size));//感觉像大块内按列轮的顺序,非零元在大块行里面的排序
    //printf("coo locate[%d]=%ld\n",i,locate[i]);
			//3752337 reorder index is r-540673,c-540525
			//if (i== 3752337) printf("%d reorder index is r-%d,c-%d,new locate index is %ld\n",i,ind_y[i],ind_x[i],locate[i]);
		//ind_x[i]*4096 + (ind_y[i]-(blk_id*4096)) = cols*4096 + (rows-(blk_id*4096))
  }
	//printf("locate=====%d,%d,%d,%d\n",locate[0],locate[1],locate[2],locate[3]);
	//printf("111locate=====%d,%d,%d,%d,%d,%d,%d,%d\n",ind_y[0],ind_x[0],ind_y[1],ind_x[1],ind_y[2],ind_x[2],ind_y[3],ind_x[3]);
	//locate=====1085440,265,356353,4183
	//111locate=====0,265,265,0,1,87,87,1
  // debug
  int num_get_data = 0;
  /*
  for(i=0; i<n_blk_x; i++)
  {
    if(nnz_small_blk[0][i] != 0)
    {
      printf("%d ", nnz_small_blk[0][i]);
      num_get_data ++;
    }
  }
  printf("in host, num_get_data=%d\n", num_get_data);
  */
  /*
  for(i=0; i<n_blks; i++)
  {
    for(j=0; j<n_blk_x; j++)
      printf("%d ", nnz_small_blk[i][j]);
    printf("\n");
  }
  */
  // end debug
  // set blkncy
  int *blkncy = (int*)malloc((n_blks+1)*sizeof(int));
  blkncy[0] = 0;
  for(i=0; i<n_blks; i++)
  {
    tmp_nnz = 0;
    for(j=0; j<n_blk_x; j++)
    {
      tmp_nnz += nnz_small_blk[i][j];
    }
    blkncy[i+1] = blkncy[i] + tmp_nnz;
    //printf("coo blkncy[%d]=%d\n",i+1,blkncy[i+1]);

  }
  _data->data = tmp_data;
  _data->locate = locate;
  _data->blkncy = blkncy;
  _data->nnz_mid_blk = nnz_mid_blk;
  _data->n_mid_blk = n_mid_blk;
  //_data->mid_blk_x_bp = mid_blk_x_bp;
  // free

  for(i=0; i<n_blks; i++)
    free(nnz_small_blk[i]);
  free(nnz_small_blk);
  free(nnz_small_blkncy);
  free(ind_small_blk);
  //free(n_big_blk);
  free(ind_x);
  free(ind_y);
  /* // free in spmv_finish
  for(i=0; i<n_blks; i++)
    free(mid_blk_x_bp[i]);
  free(mid_blk_x_bp);
  */
}

/**
 * add by guoheng on 2021-11-19
 * used for init sparse matrix with coo format
 * n_rows : number of rows
 * n_cols : number of columns
 * nnz : number of none zeros
 * rows : row index for none zeros
 * cols : col index for none zeros
 * data : data for none zeros
 * D_SPMV : data in slave
 * _para : parameters for performance tuning
 * x : vector x
 * y : vector y
 */
void SWAF_spmv_perf_tuning(int n_rows, int n_cols, int nnz, T_idx *rows, T_idx *cols, T_data *data, Data_spmv *D_SPMV, Para *para, T_data *x, T_data *y)
{
	// Init parameters
	para->n_blocks = 64;
	para->min_block_row_size = 32;
	para->max_block_row_size = 16384;
	para->merge_min_stride = 8;
	para->merge_tol_stride = 16;
	para->merge_min_len_x = 32;
	double perf = 0.0;
	double max_perf = 0.0;
	int block_row_size = 0;
	unsigned long t0, t1;
	int ideal_n_blocks = 64;
	while(1)
	{
		block_row_size = (n_rows + para->n_blocks) / para->n_blocks;
		if(block_row_size < para->min_block_row_size)
		{
			block_row_size = para->min_block_row_size;
			break;
		}
		if(block_row_size > para->max_block_row_size)
		{
			para->n_blocks += 64;
			continue;
		}
		SWAF_spmv_init_coo_block(n_rows, n_cols, nnz, rows, cols, data, D_SPMV, para);
		t0 = CRTS_time_cycle();
		SWAF_spmv_block_slave(D_SPMV, x, y);
		t1 = CRTS_time_cycle();
		perf = nnz * 2.15 / (t1 - t0);
		printf("n_blocks=%d, block_row_size=%d, perf=%lf, max_perf=%lf\n", para->n_blocks, block_row_size, perf, max_perf);
		if(max_perf < perf)
		{
			max_perf = perf;
			ideal_n_blocks = para->n_blocks;
		}
		//para->n_blocks += 64;
		para->n_blocks *= 2;
		SWAF_free_Data_spmv(D_SPMV);
	}
	para->n_blocks = ideal_n_blocks;
}

void SWAF_free_Data_spmv(Data_spmv *D_SPMV)
{
	int i, j, k;
	int n_blocks = D_SPMV->n_blocks;
	int n_tiles;
	int n_units;
	if(n_blocks == 0)
		return;
	Block *blocks = D_SPMV->blocks;
	Tile *tiles;
	for(i=0; i<n_blocks; i++)
	{
		n_tiles = blocks[i].n_tiles;
		if(n_tiles == 0)
			continue;
		tiles = blocks[i].tiles;
		for(j=0; j<n_tiles; j++)
		{
			free(tiles[j].units);
		}
		free(tiles);
	}
	free(blocks);
	free(D_SPMV->pos);
	free(D_SPMV->data);
}

/**
 * add by guoheng on 2021-11-19
 * used for init sparse matrix with coo format
 * n : number of rows
 * value : data in matrix
 * colind : column index of matrix
 * rbegin : row begin in matrix
 * _data : data used in spmv in slave
 */
void SWAF_spmv_init_coo_block(int n_rows, int n_cols, int nnz, T_idx *rows, T_idx *cols, T_data *data, Data_spmv *D_SPMV, Para *para)
{
	int block_row_size = 1024; // block size of rows
	int block_col_size = 1024; // block size of columns
	//int merge_min_stride = 8; // merge parameter : if stride between two unit is less than it, merge
	//int merge_tol_stride = 16; // merge parameter : if one of len_x is less than min_len_x and stride is less than tol, merge
	//int merge_min_len_x = 32; // merge parameter : if one of len_x is less than min_len_x and stride is less than tol, merge
	int merge_min_stride = para->merge_min_stride;
	int merge_tol_stride = para->merge_tol_stride;
	int merge_min_len_x = para->merge_min_len_x;
	// Calculate block_row_size for load balance
	/*
	int max_block_row_size = 8192;
	int ideal_num_blocks = 64;
	int min_block_row_size = 32;
	if(n_rows < ideal_num_blocks * min_block_row_size)
		block_row_size = min_block_row_size;
	else
	{
		while(1)
		{
			block_row_size = (n_rows + ideal_num_blocks) / ideal_num_blocks;
			if(block_row_size >= min_block_row_size && block_row_size <= max_block_row_size)
				break;
			ideal_num_blocks *= 2;
		}
	}
	*/
	block_row_size = (n_rows + para->n_blocks) / (para->n_blocks);
	// ====================================================================
	// Init Blocks
	// ====================================================================
	int n_blocks = n_rows / block_row_size;
	int remind_rows = n_rows - (n_blocks * block_row_size);
	if(remind_rows > 0)
		n_blocks ++;
	Block *blocks = (Block*)malloc(n_blocks * sizeof(Block));
	int i, j, k;
	for(i=0; i<n_blocks-1; i++)
	{
		blocks[i].start_row = i * block_row_size;
		blocks[i].n_rows = block_row_size;
	}
	blocks[i].start_row = i * block_row_size;
	if(remind_rows > 0)
		blocks[i].n_rows = remind_rows;
	else
		blocks[i].n_rows = block_row_size;
	for(i=0; i<n_blocks; i++)
		blocks[i].n_tiles = 0;
	// ====================================================================
	// Init Tiles
	// ====================================================================
	int block_id = -1; // current block id
	int tile_id = -1; // current tile id
	int n_tiles = 0; // number of tiles in block
	int start_nnz = 0; // start nnz for block
	int ideal_n_tiles = n_cols / block_col_size;
	int remind_cols = n_cols - (ideal_n_tiles * block_col_size);
	if(remind_cols > 0)
		ideal_n_tiles ++;
	int *nnz_ideal_tiles = (int*)malloc(ideal_n_tiles * sizeof(int));
	int *min_x_ideal_tiles = (int*)malloc(ideal_n_tiles * sizeof(int));
	int *max_x_ideal_tiles = (int*)malloc(ideal_n_tiles * sizeof(int));
	int *nnz_o2n = (int*)malloc(nnz * sizeof(int)); // old id to new id of nnz
	int *nfill_ideal_tiles = (int*)malloc(ideal_n_tiles * sizeof(int));
	int *start_nz_ideal_tiles = (int*)malloc((ideal_n_tiles+1)*sizeof(int));
	int newid = -1; // new nz id
	int cbid = -1; // column block id
	for(i=0; i<nnz; i++)
	{
		while(rows[i] / block_row_size > block_id)
		{
			block_id ++;
			for(j=0; j<ideal_n_tiles; j++)
			{
				nnz_ideal_tiles[j] = 0;
				min_x_ideal_tiles[j] = n_cols;
				max_x_ideal_tiles[j] = -1;
			}
		}
		tile_id = cols[i] / block_col_size;
		nnz_ideal_tiles[tile_id] ++;
		if(min_x_ideal_tiles[tile_id] > cols[i])
			min_x_ideal_tiles[tile_id] = cols[i];
		if(max_x_ideal_tiles[tile_id] < cols[i])
			max_x_ideal_tiles[tile_id] = cols[i];
		if((i + 1 == nnz) || ((i + 1 < nnz) && (rows[i+1] / block_row_size > block_id))) // end of current block
		{
			// map of nz
			start_nz_ideal_tiles[0] = 0;
			for(j=0; j<ideal_n_tiles; j++)
				start_nz_ideal_tiles[j+1] = start_nz_ideal_tiles[j] + nnz_ideal_tiles[j];
			for(j=0; j<ideal_n_tiles; j++)
				nfill_ideal_tiles[j] = 0;
			for(j=start_nnz; j<i+1; j++) // nnz in this block
			{
				cbid = cols[j] / block_col_size;
				newid = start_nnz + start_nz_ideal_tiles[cbid] + nfill_ideal_tiles[cbid];
				nnz_o2n[j] = newid;
				nfill_ideal_tiles[cbid] ++;
			}
			// fill in block
			n_tiles = 0;
			for(j=0; j<ideal_n_tiles; j++)
			{
				if(nnz_ideal_tiles[j] > 0)
					n_tiles ++;
			}
			Tile *tiles = (Tile*)malloc(n_tiles * sizeof(Tile));
			n_tiles = 0;
			for(j=0; j<ideal_n_tiles; j++)
			{
				if(nnz_ideal_tiles[j] > 0)
				{
					tiles[n_tiles].start_x = min_x_ideal_tiles[j];
					tiles[n_tiles].len_x = max_x_ideal_tiles[j] - min_x_ideal_tiles[j] + 1;
					tiles[n_tiles].nnz = nnz_ideal_tiles[j];
					n_tiles ++;
				}
			}
			blocks[block_id].n_tiles = n_tiles;
			blocks[block_id].tiles = tiles;
			blocks[block_id].start_nnz = start_nnz;
			start_nnz = i + 1;
		}
	}
	// ====================================================================
	// Matrix data preprocessing
	// ====================================================================
	T_idx *rowid = (T_idx*)malloc(nnz * sizeof(T_idx));
	T_idx *colid = (T_idx*)malloc(nnz * sizeof(T_idx));
	T_data *newdata = (T_data*)malloc(nnz * sizeof(T_data));
	for(i=0; i<nnz; i++)
	{
		newid = nnz_o2n[i];
#ifdef DEBUG
		if(newid < 0 || newid >= nnz)
		{
			printf("Error newid in init block, i=%d, newid=%d\n");
			exit(0);
		}
#endif
		rowid[newid] = rows[i];
		colid[newid] = cols[i];
		newdata[newid] = data[i];
	}
	// Deal with location in slave
	int current_nnz = 0;
	for(i=0; i<n_blocks; i++)
	{
		current_nnz = blocks[i].start_nnz;
		for(j=0; j<blocks[i].n_tiles; j++)
		{
			int start_x = blocks[i].tiles[j].start_x;
			for(k=0; k<blocks[i].tiles[j].nnz; k++)
			{
				rowid[current_nnz] = rowid[current_nnz] - (i * block_row_size);
				colid[current_nnz] = colid[current_nnz] - start_x;
#ifdef DEBUG
				if(rowid[current_nnz] >= block_row_size || rowid[current_nnz] < 0)
					printf("i=%d, j=%d, nnz=%d, current_nnz = %d, rowid=%d, colid=%d\n", i, j, blocks[i].tiles[j].nnz, current_nnz, rowid[current_nnz], colid[current_nnz]);
				if(colid[current_nnz] >= block_col_size || colid[current_nnz] < 0)
					printf("i=%d, j=%d, nnz=%d, current_nnz = %d, rowid=%d, colid=%d\n", i, j, blocks[i].tiles[j].nnz, current_nnz, rowid[current_nnz], colid[current_nnz]);
#endif
				current_nnz ++;
			}
	  }
	}
	Pos *pos = (Pos*)malloc(nnz * sizeof(Pos));
	for(i=0; i<nnz; i++)
	{
		pos[i].rowid = rowid[i];
		pos[i].colid = colid[i];
	}
	// ====================================================================
	// Init Unit, remove useless x in tile
	// ====================================================================
	int n_units;
	int *nnz_col = (int*)malloc(block_col_size * sizeof(int)); // # of none zeros in one column of Tile
	int *unit_start_x = (int*)malloc(block_col_size * sizeof(int));
	int *unit_end_x = (int*)malloc(block_col_size * sizeof(int));
	int *unit_merge_tag = (int*)malloc(block_col_size * sizeof(int));
	int unit_ind = 0;
	int m, n; // loop variables
	int ind = 0; // index of current number of none zeros
	int start_x = 0; // start_x in tile
	for(i=0; i<n_blocks; i++)
	{
		for(j=0; j<blocks[i].n_tiles; j++)
		{
			// Count # of none zeros in every column of one Tile
			for(m=0; m<block_col_size; m++)
				nnz_col[m] = 0;
			for(k=0; k<blocks[i].tiles[j].nnz; k++)
			{
				nnz_col[colid[ind]] ++;
				ind ++;
			}
			n_units = 0;
			m = 0;
			while(m < block_col_size)
			{
				while(m < block_col_size && nnz_col[m] == 0)
					m++;
				if(m < block_col_size) // find start_x in unit
				{
					unit_start_x[n_units] = m;
					n_units ++;
				}
				m ++;
				while(m < block_col_size && nnz_col[m] > 0)
					m ++;
				if(m <= block_col_size) // find end_x in unit
					unit_end_x[n_units - 1] = m - 1;
				m ++;
			}
			// Merge some unit in Tile for optimalization of DMA
			// Merge1
			for(m=0; m<n_units; m++)
				unit_merge_tag[m] = 1;
			for(m=0; m<n_units-1; m++)
				if(unit_start_x[m+1] - unit_end_x[m] < merge_min_stride) // merge
					unit_merge_tag[m+1] = 0;
			unit_ind = 1; // unit_start_x[0] = unit_start_x[0]
			m = 1;
			while(m < n_units)
			{
				while(m < n_units && unit_merge_tag[m] == 0)
					m++;
				unit_end_x[unit_ind-1] = unit_end_x[m-1];
				if(m < n_units)
				{
					unit_start_x[unit_ind] = unit_start_x[m];
					unit_end_x[unit_ind] = unit_end_x[m];
					unit_ind ++;
					m ++;
				}
			}
			n_units = unit_ind;
			// Merge2
			for(m=0; m<n_units; m++)
				unit_merge_tag[m] = 1;
			for(m=0; m<n_units; m++)
			{
				if(unit_merge_tag[m] != 0 && unit_end_x[m] - unit_start_x[m] < merge_min_len_x)
				{
					if(m > 0 && unit_start_x[m] - unit_end_x[m-1] < merge_tol_stride) // merge
						unit_merge_tag[m] = 0;
					if(m < n_units-1 && unit_start_x[m+1] - unit_end_x[m] < merge_tol_stride) // merge
						unit_merge_tag[m+1] = 0;
				}
			}
			unit_ind = 1; // unit_start_x[0] = unit_start_x[0]
			m = 1;
			while(m < n_units)
			{
				while(m < n_units && unit_merge_tag[m] == 0)
					m++;
				unit_end_x[unit_ind-1] = unit_end_x[m-1];
				if(m < n_units)
				{
					unit_start_x[unit_ind] = unit_start_x[m];
					unit_end_x[unit_ind] = unit_end_x[m];
					unit_ind ++;
					m ++;
				}
			}
			n_units = unit_ind;
			// Todo : Update index in Tile
			// Set units in Tile
			Unit *units = (Unit*)malloc(n_units * sizeof(Unit));
			for(m=0; m<n_units; m++)
			{
				units[m].start_x = unit_start_x[m];
				units[m].len_x = unit_end_x[m] - unit_start_x[m] + 1;
#ifdef DEBUG
				if(units[m].start_x < 0 || units[m].start_x > block_col_size)
					printf("Error! m=%d, start_x=%d, end_x=%d\n", m, units[m].start_x, unit_end_x[m]);
				if(units[m].len_x < 0 || units[m].len_x > block_col_size || unit_end_x[m] >= block_col_size)
					printf("Error! m=%d, start_x=%d, end_x=%d\n", m, units[m].start_x, unit_end_x[m]);
#endif
			}
			blocks[i].tiles[j].n_units = n_units;
			blocks[i].tiles[j].units = units;
		}
	}
	/* 2021-12-8 */
	/* Add nnz in block */
	for(i=0; i<n_blocks - 1; i++)
		blocks[i].nnz = blocks[i+1].start_nnz - blocks[i].start_nnz;
	blocks[n_blocks-1].nnz = nnz - blocks[n_blocks-1].start_nnz;
	/* End change */
	// ====================================================================
	// Init D_SPMV
	// ====================================================================
	D_SPMV->block_row_size = block_row_size;
	D_SPMV->block_col_size = block_col_size;
	D_SPMV->n_blocks = n_blocks;
	D_SPMV->blocks = blocks;
	//D_SPMV->rowid = rowid;
	//D_SPMV->colid = colid;
	D_SPMV->pos = pos;
	D_SPMV->data = newdata;
	// Free useless data
	free(nnz_ideal_tiles);
	free(min_x_ideal_tiles);
	free(max_x_ideal_tiles);
	free(nnz_o2n);
	free(nfill_ideal_tiles);
	free(start_nz_ideal_tiles);
	free(nnz_col);
	free(unit_start_x);
	free(unit_end_x);
	free(unit_merge_tag);
}

/**
 * SpMV in host with block matrix format
 * D_SPMV : structure of matrix
 * x : vector x
 * y : vector y, init to be 0 for use
 */
void SWAF_spmv_block_host(Data_spmv *D_SPMV, T_data *x, T_data *y)
{
	int i, j, k;
	Block *blocks = D_SPMV->blocks;
	//T_idx *rowid = D_SPMV->rowid;
	//T_idx *colid = D_SPMV->colid;
	Pos *pos = D_SPMV->pos;
	T_data *data = D_SPMV->data;
	Tile *tiles = NULL;
	int rid = -1; // row id
	int cid = -1; // col id
	int start_row = -1; // start row id
	int start_nnz = -1; // start nnz
	int ind = 0; // nnz index
	for(i=0; i<D_SPMV->n_blocks; i++)
	{
		tiles = blocks[i].tiles;
		start_row = blocks[i].start_row;
		start_nnz = blocks[i].start_nnz;
		ind = start_nnz;
		for(j=0; j<blocks[i].n_tiles; j++)
		{
			for(k=0; k<tiles[j].nnz; k++)
			{
				//rid = rowid[ind] + start_row;
				//cid = colid[ind] + tiles[j].start_x;
				rid = pos[ind].rowid + start_row;
				cid = pos[ind].colid + tiles[j].start_x;
#ifdef DEBUG
				if(rid == 897)
					printf("In host, column id is %d\n", cid);
#endif
				y[rid] += x[cid] * data[ind];
				ind ++;
			}
		}
	}
}

/**
 * SpMV in slave with block matrix format
 * D_SPMV : structure of matrix
 * x : vector x
 * y : vector y
 */
void SWAF_spmv_block_slave(Data_spmv *D_SPMV, T_data *x, T_data *y)
{
	D_SPMV->x = x;
	D_SPMV->y = y;
	athread_spawn(spmv_block, D_SPMV);
	athread_join();
}

/**
 * add by guoheng on 2019-11-22
 * used for init sparse matrix with csr format
 * n : number of rows
 * value : data in matrix
 * colind : column index of matrix
 * rbegin : row begin in matrix
 * _data : data used in spmv in slave
 */
void SWAF_spmv_init_csr_d(int n, double *value, int *colind, int *rbegin, spmv_data_t *_data)
{
	// get n_cols
	int n_rows = n;
	int n_cols = -1;
	int i, j, k;
	for(i=0; i<n_rows; i++)
		for(j=rbegin[i]; j<rbegin[i+1]; j++) // note : rbegin[0] = 0!!!!!
		{
			if(n_cols < colind[j])
				n_cols = colind[j];
				//printf("");
				}
  _data->n_rows = n_rows;
  _data->n_cols = n_cols;
  _data->nnz = rbegin[n_rows];
  int n_blks = (n_rows + (1<<blk_y_size) - 1) >> blk_y_size; // # of y blocks
  _data->n_blks = n_blks;
  int n_blk_x = (n_cols + (1<<blk_x_size) - 1) >> blk_x_size; // # of x blocks
  int **nnz_small_blk;
  nnz_small_blk = (int**)malloc(n_blks*sizeof(int*)); // # of none zeros in small_blk(blk_y * blk_x)
  for(i=0; i<n_blks; i++)
    nnz_small_blk[i] = (int*)malloc(n_blk_x*sizeof(int));
  for(i=0; i<n_blks; i++)
    for(j=0; j<n_blk_x; j++)
      nnz_small_blk[i][j] = 0;
  int blk_id = -1;
  int x_id = -1;
  int ii, jj;
  int real_nnz = rbegin[n_rows]; // real # of none zeros
	//printf("csr 0---%d,%d,%d,%d,%d\n",_data->n_rows,_data->n_cols,_data->nnz,_data->n_blks,real_nnz);

	for(i=0; i<n_rows; i++)
		for(j=rbegin[i]; j<rbegin[i+1]; j++)
		{
			blk_id = i >> blk_y_size;
			x_id = colind[j] >> blk_x_size;
			nnz_small_blk[blk_id][x_id] ++;
		}
  _data->nnz = real_nnz;
  //printf("real_nnz = %d\n", real_nnz);
  // check nnz_small_blk
  /*
  for(i=0; i<n_blks; i++)
  {
    for(j=0; j<n_blk_x; j++){
      printf("csr nnz_small_blk[%d][%d]=%d ", i,j,nnz_small_blk[i][j]);}
    printf("\n");
  }
  */
  // sort with nnz_small_blk
  double *tmp_data = (double*)malloc(real_nnz*sizeof(double));
  int *ind_x = (int*)malloc(real_nnz * sizeof(int));
  int *ind_y = (int*)malloc(real_nnz * sizeof(int));
  int *nnz_small_blkncy = (int*)malloc(((n_blks*n_blk_x)+1)*sizeof(int));
  int index_tmp = 1;
  nnz_small_blkncy[0] = 0;
  for(i=0; i<n_blks; i++)
    for(j=0; j<n_blk_x; j++)
    {
      nnz_small_blkncy[index_tmp] = nnz_small_blk[i][j] + nnz_small_blkncy[index_tmp-1];
      index_tmp ++;
    }
  int *ind_small_blk = (int*)malloc(n_blks*n_blk_x*sizeof(int));
  for(i=0; i<n_blks*n_blk_x; i++)
    ind_small_blk[i] = 0;
  int index_x_tmp = 0;
	for(i=0; i<n_rows; i++)
		//printf("csr 2--rbegin[%d]=%d|%d\n",i,rbegin[i],rbegin[i+1]);
		for(j=rbegin[i]; j<rbegin[i+1]; j++)
		{
			blk_id = i >> blk_y_size;
			x_id = colind[j] >> blk_x_size;
      index_x_tmp = blk_id * n_blk_x + x_id;
      index_tmp = nnz_small_blkncy[index_x_tmp] + ind_small_blk[index_x_tmp]; // start + offset
      tmp_data[index_tmp] = value[j];
      ind_x[index_tmp] = colind[j];
      ind_y[index_tmp] = i;
      ind_small_blk[index_x_tmp] ++;
		  //printf("csr %d original`s index is r-%d,c-%d,new data index is %d|%lf\n",j,i,colind[j],index_tmp,value[j]);
		//  printf("csr %d original`s index is r-%d,c-%d,new data index is %d|%d\n",j,i+1,colind[j],index_x_tmp, nnz_small_blkncy[index_x_tmp]);
		}

	/*
  for(i=0; i<nnz; i++)
  {
    ii = face_cel_p[i][0];
    jj = face_cel_p[i][1];
    if(ii < n_rows)
    {
      blk_id = ii >> blk_y_size;
      x_id = jj >> blk_x_size;
      index_x_tmp = blk_id * n_blk_x + x_id;
      index_tmp = nnz_small_blkncy[index_x_tmp] + ind_small_blk[index_x_tmp]; // start + offset
      tmp_data[index_tmp] = data[2*i];
      ind_x[index_tmp] = jj;
      ind_y[index_tmp] = ii;
      ind_small_blk[index_x_tmp] ++;
    }
    if(jj < n_rows)
    {
      blk_id = jj >> blk_y_size;
      x_id = ii >> blk_x_size;
      index_x_tmp = blk_id * n_blk_x + x_id;
      index_tmp = nnz_small_blkncy[index_x_tmp] + ind_small_blk[index_x_tmp]; // start + offset
      tmp_data[index_tmp] = data[2*i+1];
      ind_x[index_tmp] = ii;
      ind_y[index_tmp] = jj;
      ind_small_blk[index_x_tmp] ++;
    }
  }
	*/
  int max_l_nnz_t = 1 << max_l_nnz;
  // set middle blocks
  int *n_mid_blk = (int*)malloc(n_blks*sizeof(int));
  int **nnz_mid_blk = (int**)malloc(n_blks*sizeof(int*));
  for(i=0; i<n_blks; i++)
    nnz_mid_blk[i] = (int*)malloc(n_blk_x*sizeof(int));
  for(i=0; i<n_blks; i++)
    for(j=0; j<n_blk_x; j++)
      nnz_mid_blk[i][j] = 0;
  /*
  int **mid_blk_x_bp = (int**)malloc(n_blks*sizeof(int));
  for(i=0; i<n_blks; i++)
    mid_blk_x_bp[i] = (int*)malloc((n_blk_x+1)*sizeof(int)); // x break point in middle blocks
  for(i=0; i<n_blks; i++)
    mid_blk_x_bp[i][0] = 0;
    */
  int ind_mid_blk = 0;
  int tmp_nnz = 0;

  //hexiang for(i=0; i<n_blks; i++)
  //hexiang {
  //hexiang   ind_mid_blk = 0;
  //hexiang   tmp_nnz = nnz_small_blk[i][0];
  //hexiang  // mid_blk_x_bp[i][ind_mid_blk] = 0;
  //hexiang   for(j=1; j<n_blk_x; j++)
  //hexiang   {
  //hexiang     if(tmp_nnz > max_l_nnz_t)
  //hexiang     {
  //hexiang       printf("Error, nnz of one small block is more than max_l_nnz_t, in blk_y %d blk_x %d\n", i, j);
  //hexiang       exit(0);
  //hexiang     }
  //hexiang     else
  //hexiang     {
  //hexiang       if(tmp_nnz + nnz_small_blk[i][j] > max_l_nnz_t)
  //hexiang       {
  //hexiang         nnz_mid_blk[i][ind_mid_blk] = tmp_nnz;
  //hexiang         ind_mid_blk ++;
  //hexiang   //      mid_blk_x_bp[i][ind_mid_blk] = j;
  //hexiang         tmp_nnz = nnz_small_blk[i][j];
  //hexiang       }
  //hexiang       else
  //hexiang         tmp_nnz += nnz_small_blk[i][j];
  //hexiang     }
  //hexiang   }
  //hexiang   // deal with j = n_blk_x
  //hexiang   nnz_mid_blk[i][ind_mid_blk] = tmp_nnz;
  //hexiang   ind_mid_blk ++;
  //hexiang   n_mid_blk[i] = ind_mid_blk; // number of middle blocks in every big block y
  //hexiang   //mid_blk_x_bp[i][ind_mid_blk] = j;
  //hexing }
  // check nnz_mid_blk in host
  /*
  for(i=0; i<n_blks; i++)
  {
    for(j=0; j<n_mid_blk[i]; j++)
      printf("%d ", nnz_mid_blk[i][j]);
    printf("\n");
  }
  printf("===================\n");
  printf("address: %p, %p\n", nnz_mid_blk, nnz_mid_blk[0]);
  */
  // end check
  // set locate
  long *locate = (long*)malloc(real_nnz*sizeof(long));
  for(i=0; i<real_nnz; i++)
  {
    blk_id = ind_y[i] >> blk_y_size;
    locate[i] = ((long)(ind_x[i])<<(long)blk_y_size) + (long)(ind_y[i] - (blk_id << blk_y_size));
    //printf("csr locate[%d]=%d|%d|%ld\n",i,ind_y[i],ind_x[i],locate[i]);
	}

  // debug
  int num_get_data = 0;
  /*
  for(i=0; i<n_blk_x; i++)
  {
    if(nnz_small_blk[0][i] != 0)
    {
      printf("%d ", nnz_small_blk[0][i]);
      num_get_data ++;
    }
  }
  printf("in host, num_get_data=%d\n", num_get_data);
  */
  /*
  for(i=0; i<n_blks; i++)
  {
    for(j=0; j<n_blk_x; j++)
      printf("%d ", nnz_small_blk[i][j]);
    printf("\n");
  }
  */
  // end debug
  // set blkncy
  int *blkncy = (int*)malloc((n_blks+1)*sizeof(int));
  blkncy[0] = 0;
  for(i=0; i<n_blks; i++)
  {
    tmp_nnz = 0;
    for(j=0; j<n_blk_x; j++)
    {
      tmp_nnz += nnz_small_blk[i][j];
    }
    blkncy[i+1] = blkncy[i] + tmp_nnz;
    //printf("csr blkncy[%d]=%d\n",i+1,blkncy[i+1]);

  }
  _data->data = tmp_data;
  _data->locate = locate;
  _data->blkncy = blkncy;
  _data->nnz_mid_blk = nnz_mid_blk;
  _data->n_mid_blk = n_mid_blk;
  //_data->mid_blk_x_bp = mid_blk_x_bp;
  // free
  for(i=0; i<n_blks; i++)
    free(nnz_small_blk[i]);
  free(nnz_small_blk);
  free(nnz_small_blkncy);
  free(ind_small_blk);
  //free(n_big_blk);
  free(ind_x);
  free(ind_y);
  /* // free in spmv_finish
  for(i=0; i<n_blks; i++)
    free(mid_blk_x_bp[i]);
  free(mid_blk_x_bp);
  */
}

/**
 * spmv in slave
 * _data : data used in spmv in slave
 * x : input vector   
 * y : input and output vector
 */

//h-------- x cols, y rows
void SWAF_spmv(spmv_data_t *_data, double *x, double *y)
{
  _data->x = x;
  _data->y = y;
  //athread_spawn(spmv_slv, _data);
  athread_spawn(spmv_slv_new, _data);
  athread_join();
}

/**
 * free memory
 * _data : data used in spmv in slave
 */
void SWAF_spmv_finish(spmv_data_t *_data)
{
  int i;
  free(_data->data);
  free(_data->locate);
  free(_data->blkncy);
  free(_data->n_mid_blk);
  for(i=0; i<_data->n_blks; i++)
    free(_data->nnz_mid_blk[i]);
  free(_data->nnz_mid_blk);
  //for(i=0; i<_data->n_blks; i++)
   // free(_data->mid_blk_x_bp[i]);
  //free(_data->mid_blk_x_bp);
  free(_data);
}

