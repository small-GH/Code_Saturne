/*
 * write by hexiang on 2020-9-22
 * read data file of sparse matrix  with coo data
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "SWAF_spmv_def.h"

int read_MTX(T_data **data_arg, T_idx **ROW_S_arg, T_idx **COL_S_arg, int *nnz_arg, int *n_rows_arg, int *n_cols_arg, char *file_name)
{
	/* ****** input args
	 *
	 * file_name : which file to be read ;
	*/

	/* ****** output args
	 *
	 *   data : value of none zero ;
	 *  ROW_S : row index of none zero ;
	 *  COL_S : col index of none zero ;
	 *    nnz : # of none zero ;
	 * n_rows : # of rows ;
	 * n_cols : # of cols ;
	*/

  FILE* fp;
	char isComment[MAX_BUFFER];
	char match[MAX_BUFFER] = "%./";
  unsigned long real_size;
	T_idx tmp_r0,tmp_c0;
	T_idx n_rows,n_cols,nnz;
	T_data *data;
	T_idx *COL_S,*ROW_S;

  // begin process input_file,comment char ...
	if( (fp = fopen(file_name,"r")) == NULL )
	{
		printf( "Error open file %s\n", file_name );
		return 0;
	}

	if( (fgets(isComment,MAX_BUFFER,fp)) == NULL)
	{
		printf( "%s is null!\n", file_name );
		return 0;
	}

  // read chars from file until no comment
	while( isComment[0]==match[0])
	{
		fgets(isComment,MAX_BUFFER,fp);
	}

  // read rows,cols,values 
	fseek(fp,-strlen(isComment),SEEK_CUR);
	fscanf(fp,"%d %d %d",&n_rows,&n_cols,&nnz);
	fscanf(fp,"%d %d %s",&tmp_r0,&tmp_c0,isComment);

	// matrix size is less than size of MPE
	real_size = (long)nnz*(long)(sizeof(T_data));
	real_size = real_size >> size_MPE ;
	if(real_size > max_size_MPE)
	{
		printf("%s is too large,please choose another file!!!\n",file_name);
		return 0;
	}

  // begin read input_file,coo, malloc Matrix rows,Matrix cols;
	data = (T_data*)malloc(nnz*sizeof(T_data));
	ROW_S = (T_idx*)malloc(nnz*sizeof(T_idx));
	COL_S = (T_idx*)malloc(nnz*sizeof(T_idx));
	fseek(fp,-strlen(isComment),SEEK_CUR);

  *n_rows_arg = n_rows;
	*n_cols_arg = n_cols;
	*nnz_arg = nnz;

  ROW_S[0] = tmp_r0;
  COL_S[0] = tmp_c0;
	fscanf(fp,"%lf",&data[0]);
  
  for(int i=1;i<nnz;i++)
	{
		//fscanf(fp,"%d %d %lf",&ROW_S[i],&COL_S[i],&data[i]);
		fscanf(fp,"%d %d %lf",&COL_S[i],&ROW_S[i],&data[i]);
	}
  fclose(fp);

#ifdef DEBUG
  for(int i=0; i<nnz; i++)
		if(COL_S[i] == 898)
			printf("In read, COL_S[%d]=%d\n", i, ROW_S[i]);
#endif
	*ROW_S_arg = ROW_S;
	*COL_S_arg = COL_S;
	*data_arg = data;

}
