/**
 * write by hexiang on 2020-9-15
 * test performance of spmv with MPE
 */
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "SWAF_spmv.h"

void SWAF_spmv_csr_master_i(int n, int *rows_off, int *cols, int *data, int *x, int *y)
{
	  int i,j,ii,jj;
		int n_rows = -1,n_cols = -1;
		int nnz = -1;

    //n_rows = n - 1;
    n_rows = n ;
    for(i=0; i<n_rows; i++)
    {
			for(j=rows_off[i];j<rows_off[i+1];j++)
			{
			  y[i] += x[cols[j]]* data[j];
				//ncols = (n_cols > cols[j]) ? cols[j] : n_cols ;
				//if(n_cols<cols[j]) n_cols = cols[j];
			}
		}
}

void SWAF_spmv_csr_master_f(int n, int *rows_off, int *cols, float *data, float *x, float *y)
{
	  int i,j,ii,jj;
		int n_rows = -1,n_cols = -1;
		int nnz = -1;

    n_rows = n ;
    for(i=0; i<n_rows; i++)
    {
			for(j=rows_off[i];j<rows_off[i+1];j++)
			{
			  y[i] += x[cols[j]]* data[j];

				//ncols = (n_cols > cols[j]) ? cols[j] : n_cols ;
				//if(n_cols<cols[j]) n_cols = cols[j];
			}
		}
}

void SWAF_spmv_csr_master_d(int n, int *rows_off, int *cols, double *data, double *x, double *y)
{
	  int i,j,ii,jj;
		int n_rows = -1,n_cols = -1;
		int nnz = -1;

    n_rows = n;

    for(i=0; i<n_rows; i++)
    {
			for(j=rows_off[i];j<rows_off[i+1];j++)
			{
			  y[i] += x[cols[j]]* data[j];
				/*
				if(i==33860)
				{
				  printf("j form %d to %d\n",rows_off[i],rows_off[i+1]);  
				  printf("col-j is %d,x-%lf,data-%lf\n",cols[j]-1,x[cols[j]-1],data[j]);  
				}
				*/

				//ncols = (n_cols > cols[j]) ? cols[j] : n_cols ;
				//if(n_cols<cols[j]) n_cols = cols[j];
			}

		}
}
