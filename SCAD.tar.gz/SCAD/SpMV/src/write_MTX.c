/*
 * write by hexiang on 2020-9-22
 * write data file of sparse matrix with coo data
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "SWAF_spmv.h"

//int write_MTX(T_data *data,T_idx *rows, T_idx *cols, int nnz, char *file_name,char file_name_wr[MAX_BUFFER],char **wr_name)
int write_MTX(T_data *data,T_idx *rows, T_idx *cols, int nnz, char *file_name,char file_name_wr[MAX_BUFFER])
{
	char *suf_name;
	char match[MAX_BUFFER] = "%./";
	FILE *fp;
	int i;

  suf_name = strtok(strrchr(file_name,match[2]),&match[2]);
  strcat(file_name_wr,suf_name);
	if((fp = fopen(file_name_wr,"w"))!=NULL)
	{
    for(i=0;i<nnz;i++)
	 	{
	 		fprintf(fp,"%d %d %.16lf \n",rows[i],cols[i],data[i]);
	 	}
  }
	else
	{
    printf("Error Open %s !\n",file_name_wr);
	}
	fclose(fp);

//	*wr_name = file_name_wr ;
}
