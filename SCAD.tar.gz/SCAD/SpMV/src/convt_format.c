/*
 * write by hexiang on 2020-9-23
 * coo convert to csr
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "SWAF_spmv.h"
/*
void SWAF_spmv_o2r_d_1idx(int nnz,int n_rows,T_idx *rows,T_idx **rows_off)
{

  int i,ii;
	int cnt = 0;
	*rows_off = (T_idx*)malloc((n_rows+1)*sizeof(T_idx));
	T_idx *rbegin_idx = (T_idx*)malloc((n_rows+1)*sizeof(T_idx));
  for(i=0;i<n_rows+1;i++)
     rbegin_idx[i] = 0;

  (*rows_off)[0] = 0;
  (*rows_off)[n_rows] = nnz;
	for(i=0;i<nnz;i++)
	{
		ii = rows[i];
		rbegin_idx[ii] ++ ;
	}

  for(i=1;i<n_rows;i++)
  {
		cnt += rbegin_idx[i];  
		(*rows_off)[i] = cnt;
	}  
//used for debug
//  for(i=0;i<n_rows+1;i++)
//  {
//		printf("in o2r:%d-%d\n",i,(*rows_off)[i]);
//	}  

}
*/

//void SWAF_spmv_o2r_d_0idx(int nnz,int n_rows,T_idx *rows,T_idx **rows_off)
void SWAF_spmv_o2r_d(int nnz,int n_rows,T_idx *rows,T_idx **rows_off)
{

  int i,ii;
	int cnt = 0;
	*rows_off = (T_idx*)malloc((n_rows+1)*sizeof(T_idx));
	T_idx *rbegin_idx = (T_idx*)malloc((n_rows+1)*sizeof(T_idx));
  for(i=0;i<n_rows+1;i++)
     rbegin_idx[i] = 0;

  (*rows_off)[0] = 0;
  (*rows_off)[n_rows] = nnz;
	for(i=0;i<nnz;i++)
	{
		ii = rows[i];
		rbegin_idx[ii+1] ++ ;
	}

  for(i=0;i<n_rows;i++)
  {
		cnt += rbegin_idx[i];  
		(*rows_off)[i] = cnt;
	}  

/* used for debug
  for(i=0;i<n_rows+1;i++)
  {
		printf("in o2r:%d-%d\n",i,(*rows_off)[i]);
	}  
*/
}

//void SWAF_spmv_r2o_d_0idx(int *nnz_arg,int n_rows,int *n_cols_arg,T_idx *rows_off,T_idx *cols,T_idx **rows)
void SWAF_spmv_r2o_d(int *nnz_arg,int n_rows,int *n_cols_arg,T_idx *rows_off,T_idx *cols,T_idx **rows)
{

  int i,ii;
	int n_cols,nnz;
	int ridx_start,ridx_end;

  nnz = rows_off[n_rows] ;

	*rows = (T_idx*)malloc((n_rows)*sizeof(T_idx));

  for(i=0;i<n_rows;i++)
	{
		ridx_start = rows_off[i];
		ridx_end = rows_off[i+1];
		for(ii=ridx_start;ii<ridx_end;ii++)
		{
      (*rows)[ii] = i ;  
		}
	}

	n_cols = 0 ;

	for(i=0;i<nnz;i++)
	{
		n_cols = (n_cols > cols[i]) ? n_cols : cols[i];
	}
  *nnz_arg = nnz ;
	*n_cols_arg = n_cols+1 ;
}
/*
void SWAF_spmv_r2o_d_1idx(int *nnz_arg,int n_rows,int *n_cols_arg,T_idx *rows_off,T_idx *cols,T_idx **rows)
{

  int i,ii;
	int n_cols,nnz;
	int ridx_start,ridx_end;

  nnz = rows_off[n_rows] ;

	*rows = (T_idx*)malloc((n_rows)*sizeof(T_idx));

  for(i=0;i<n_rows;i++)
	{
		ridx_start = rows_off[i];
		ridx_end = rows_off[i+1];
		for(ii=ridx_start;ii<ridx_end;ii++)
		{
      (*rows)[ii] = i+1 ;  
		}
	}

	n_cols = 0 ;

	for(i=0;i<nnz;i++)
	{
		n_cols = (n_cols > cols[i]) ? n_cols : cols[i];
	}
  *nnz_arg = nnz ;
	*n_cols_arg = n_cols ;
}
*/
