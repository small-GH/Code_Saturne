/**
 * write by hexiang on 2020-9-15
 * test performance of spmv with MPE
 */
#include <stdio.h>
#include <math.h>
#include <string.h>

#include "SWAF_spmv.h"

void SWAF_spmv_coo_master_i(int nnz, int *rows, int *cols, int *data, int *x, int *y)
{
	  int i,ii,jj;

    for(i=0; i<nnz; i++)
    {
      ii = rows[i]; 
      jj = cols[i];
      y[ii] += x[jj] * data[i];
    }
}

void SWAF_spmv_coo_master_f(int nnz, int *rows, int *cols, float *data, float *x, float *y)
{
	  int i,ii,jj;

    for(i=0; i<nnz; i++)
    {
      ii = rows[i]; 
      jj = cols[i];
      y[ii] += x[jj] * data[i];
    }
}

void SWAF_spmv_coo_master_d(int nnz, T_idx *rows, T_idx *cols, T_data *data, double *x, double *y)
{
	  int i,ii,jj;

    for(i=0; i<nnz; i++)
    {
      ii = rows[i]; 
      jj = cols[i];
      y[ii] += x[jj] * data[i];
    }
}

