/**
 * write by guoheng at 2019-12-20
 * used for saturne load balance
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

/**
 * function for load balance in saturne
 * nrangp : number of processes
 * nbpart : nbpart in every process
 * irangp : my rank id
 * inout : 1	data in
 *				 0	no data exchange
 *				 -1	data out
 * npexc : number of process for data exchange
 * opid : process id for data exchange
 * osexc : data size for data exchange
 */
void gh_load_balance_(int *nrangp,
										int *nbpart,
										int *irangp,
										int *inout,
										int *npexc,
										int *opid,
										int *osexc)
{
	int n = *nrangp; // number of process
	int myid = *irangp;
	int snbpart = 0; // sum of nbpart
	int i, j, k;
	for(i=0; i<n; i++)
		snbpart += nbpart[i];
	int avgnbpart = (snbpart+n-1) / n; // average nbpart
	double imbrate = 0.00001; // imbalance rate
	//printf("Before balance, sum of nbpart is %d, average of nbpart is %d\n", snbpart, avgnbpart);
	int *nbinout = (int*)malloc(n * sizeof(int));
	for(i=0; i<n; i++)
	{
		nbinout[i] = nbpart[i] - avgnbpart;
		if((1.0 * abs(nbinout[i]) / avgnbpart) < imbrate)
			nbinout[i] = 0;
	}
	// printf nbinout for debug
	/*
	for(i=0; i<n; i++)
		printf("nbinout[%d]=%d\n", i, nbinout[i]);
		*/
	//printf("myid=%d, nbpart=%d, nbinout=%d\n", myid, nbpart[myid], nbinout[myid]);
	int ind = 0; // index of process for data exchange
	i = 0;
	j = 0;
	k = 0;
	int io = 0;
	if(nbinout[myid] > 0) // data out
		io = -1;
	else if(nbinout[myid] < 0) // data in
		io = 1;
	else
		io = 0; // no data exchange
	if(io == 1)
	{
		while(1)
		{
			while(i<=myid && nbinout[i] >= 0)
				i ++;
			while(j<n && nbinout[j] <= 0)
				j ++;
			if(i > myid)
				break;
			if(j >= n)
				break;
			if(nbinout[i] + nbinout[j] < 0)
			{
				if(myid == i)
				{
					opid[ind] = j;
					osexc[ind] = nbinout[j];
					ind ++;
				}
				nbinout[i] += nbinout[j];
				nbinout[j] = 0;
			}
			else if(nbinout[i] + nbinout[j] > 0)
			{
				if(myid == i)
				{
					opid[ind] = j;
					osexc[ind] = abs(nbinout[i]);
					ind ++;
				}
				nbinout[j] += nbinout[i];
				nbinout[i] = 0;
			}
			else
			{
				if(myid == i)
				{
					opid[ind] = j;
					osexc[ind] = nbinout[j];
					ind ++;
				}
				nbinout[i] = 0;
				nbinout[j] = 0;
				i ++;
				j ++;
			}
		}
	}
	else if(io == -1)
	{
		while(1)
		{
			while(i<n && nbinout[i] >= 0)
				i ++;
			while(j<=myid && nbinout[j] <= 0)
				j ++;
			if(i >= n)
				break;
			if(j > myid)
				break;
			if(nbinout[i] + nbinout[j] < 0)
			{
				if(myid == j)
				{
					opid[ind] = i;
					osexc[ind] = nbinout[j];
					ind ++;
				}
				nbinout[i] += nbinout[j];
				nbinout[j] = 0;
			}
			else if(nbinout[i] + nbinout[j] > 0)
			{
				if(myid == j)
				{
					opid[ind] = i;
					osexc[ind] = abs(nbinout[i]);
					ind ++;
				}
				nbinout[j] += nbinout[i];
				nbinout[i] = 0;
			}
			else
			{
				if(myid == j)
				{
					opid[ind] = i;
					osexc[ind] = nbinout[j];
					ind ++;
				}
				nbinout[i] = 0;
				nbinout[j] = 0;
				i ++;
				j ++;
			}
		}
	}
	*inout = io;
	*npexc = ind;
	free(nbinout);
}

