/**
 * write by guoheng at 2020-12-1
 * used for flmint
 */
#include <stdlib.h>
#include <stdio.h>

void flmhst_gh_(double *alpha12_p,
							 double *beta12_p, 
							 double *chi2_p, 
							 double *prodC, 
							 double *temperature, 
							 double *component, 
							 double *af, 
							 double *bf,
							 double averC[101][101][101],
							 double averzfun[101][101][101][206])
{
	double alpha12 = *alpha12_p;
	double beta12 = *beta12_p;
	double chi2 = *chi2_p;
	int nna = 99; // nna=100 in flmhst.f90
	int nnb = 99; // nnb=100 in flmhst.f90
	if(alpha12 > af[nna]) alpha12 = af[nna]; // nna=nna+1 in flmhst.f90
	if(alpha12 < af[0]) alpha12 = af[0];
	if(beta12 > bf[nnb]) beta12 = bf[nnb];
	if(beta12 < bf[0]) beta12 = bf[0];

	int i0, i, j0, j;
	if(alpha12 == af[nna])
	{
		i0 = nna-1;
		i = nna;
	}
	else
	{
		i = 0;
		while(alpha12 >= af[i])
			i ++;
		i0 = i - 1;
	}

	if(beta12 == bf[nnb])
	{
		j0 = nnb - 1;
		j = nnb;
	}
	else
	{
		j = 0;
		while(beta12 >= bf[j])
			j ++;
		j0 = j - 1;
	}

	double tempaver[4];
	int ind1[4] = {j0, j0, j, j};
	int ind2[4] = {i0, i, i0, i};
	tempaver[0] = chi2;
	int n = 0;
	int k0[4];
	int k[4];
	int nchist = 64;
	double t[4][2];
	for(n = 0; n < 4; n ++)
	{
		tempaver[n] = chi2;
		if(tempaver[n] > averC[ind1[n]][ind2[n]][nchist]) // note the order
			tempaver[n] = averC[ind1[n]][ind2[n]][nchist];
		if(tempaver[n] < averC[ind1[n]][ind2[n]][0])
			tempaver[n] = averC[ind1[n]][ind2[n]][0];

		if(tempaver[n] == averC[ind1[n]][ind2[n]][nchist])
		{
			k0[n] = nchist - 1;
			k[n] = nchist;
		}
		else
		{
			k[n] = 0;
			while(tempaver[n] >= averC[ind1[n]][ind2[n]][k[n]])
				k[n] ++;
			k0[n] = k[n] - 1;
		}
		
		if(averC[ind1[n]][ind2[n]][k[n]] == averC[ind1[n]][ind2[n]][k0[n]])
		{
			t[n][0] = 0.0;
			t[n][1] = 1.0;
		}
		else
		{
			t[n][0] = (averC[ind1[n]][ind2[n]][k[n]] - tempaver[n]) / averC[ind1[n]][ind2[n]][k[n]] - averC[ind1[n]][ind2[n]][k0[n]];
			t[n][1] = (tempaver[n] - averC[ind1[n]][ind2[n]][k0[n]]) / averC[ind1[n]][ind2[n]][k[n]] - averC[ind1[n]][ind2[n]][k0[n]];
		}
	}

	double calpha1, calpha2, cbeta1, cbeta2;
	calpha1 = (af[i] - alpha12) / (af[i] - af[i0]);
	calpha2 = (alpha12 - af[i0]) / (af[i] - af[i0]);

	cbeta1 = (bf[j] - beta12) / (bf[j] - bf[j0]);
	cbeta2 = (beta12 - bf[j0]) / (bf[j] - bf[j0]);

	int nvars = 205;
	int m=0;
	double temp1, temp2, temp3, temp4;
	double temp21, temp22;
	double difun[205];
	for(m=0; m<nvars; m++)
	{
		temp1 = (t[0][0] * averzfun[ind1[0]][ind2[0]][k0[0]][m]) + (t[0][1] * averzfun[ind1[0]][ind2[0]][k[0]][m]);
		temp2 = (t[1][0] * averzfun[ind1[1]][ind2[1]][k0[1]][m]) + (t[1][1] * averzfun[ind1[1]][ind2[1]][k[1]][m]);
		temp3 = (t[2][0] * averzfun[ind1[2]][ind2[2]][k0[2]][m]) + (t[2][1] * averzfun[ind1[2]][ind2[2]][k[2]][m]);
		temp4 = (t[3][0] * averzfun[ind1[3]][ind2[3]][k0[3]][m]) + (t[3][1] * averzfun[ind1[3]][ind2[3]][k[3]][m]);

		temp21 = (calpha1 * temp1) + (calpha2 * temp2);
		temp22 = (calpha1 * temp3) + (calpha2 * temp4);

		difun[m] = (cbeta1 * temp21) + (cbeta2 * temp22);
	}

	for(m=0; m<nvars-2; m++)
		component[m] = difun[m+1];

	*temperature = difun[0];
	*prodC = difun[nvars-1];
	/* output result */
	/*
	printf("%lf\n", temperature);
	printf("%lf\n", prodC);
	for(m=0; m<nvars-2; m++)
		printf("%lf ", component[m]);
		*/
	/*
	printf("%e\n", temperature);
	printf("%e\n", prodC);
	for(m=0; m<nvars-2; m++)
		printf("%e ", component[m]);
	printf("end result output\n");
	*/
}
