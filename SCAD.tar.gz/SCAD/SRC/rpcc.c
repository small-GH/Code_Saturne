unsigned long rpcc_()
{
	unsigned long tmp_res;
	asm volatile("rtc %0\n\t"
							 : "=&r"(tmp_res)
							 :
							 : "memory");
	return tmp_res;
}
