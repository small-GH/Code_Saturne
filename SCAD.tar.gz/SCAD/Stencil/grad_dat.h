#ifndef _GRAD_DAT_H_
#define _GRAD_DAT_H_

#include <stdlib.h>
#include <stdio.h>

#define BSX 512 // block size of x direction
#define BSY 32 // block size of y direction

typedef double cs_real_3_t[3];

typedef struct PARA1
{
	int nbx;
	int *st_x;
	int *len_x;
	int *st_nnz;
	int *len_nnz;
	int *cell_ii;
	int *cell_jj;
	cs_real_3_t *cell_cen;
	cs_real_3_t *grad;
	double *var;
	double *denum;
	double *denom;
} para1;

#endif
