#bsub -I -b -p -q q_test_2jicang -share_size 10000 -host_stack 4096 -cgsp 64 -n 1 ./test | tee run.log
#bsub -I -b -p -q q_test_ss -share_size 10000 -host_stack 4096 -cgsp 64 -n 1 ./test | tee run.log
bsub -I -b -p -J test_gh -q q_test_ss -share_size 10000 -host_stack 4096 -cgsp 64 -n 1 ./test | tee run.log
#bsub -I -b -p -J test_gh -q q_test_big -share_size 10000 -host_stack 4096 -cgsp 64 -n 1 -cache_size 128 ./test | tee run.log
#bsub -I -b -p -J test_gh -q q_test_ss -share_size 10000 -host_stack 4096 -cgsp 64 -n 1 -cache_size 128 ./test | tee run.log
#bsub -I -b -p -q q_sw_expr -share_size 10000 -host_stack 4096 -cgsp 64 -n 1 -cache_size 128 ./test | tee run.log
