#include <stdlib.h>
#include <stdio.h>
#include <crts.h>
#include <math.h>
#include <string.h>
#include "grad_dat.h"

typedef struct PARA
{
	int n_cells;
	int n_cells_ext;
	int *cell_cells_idx;
	int *cell_cells_lst;
	cs_real_3_t *cell_cen;
	cs_real_3_t *grad;
	double *var;
	double *denum;
	double *denom;
} Para;
extern SLAVE_FUN(grad_slv)(Para *v);
extern SLAVE_FUN(grad_slv1)(para1 *pa);
extern SLAVE_FUN(clip1_slv)(para1 *pa);
typedef int cs_lnum_2_t[2];

#define max(a, b) (a>b)?(a):(b)
#define CS_ABS(a)     ((a) <  0  ? -(a) : (a))  /* Absolute value of a */
#define CS_MIN(a,b)   ((a) < (b) ?  (a) : (b))  /* Minimum of a et b */
#define CS_MAX(a,b)   ((a) > (b) ?  (a) : (b))  /* Maximum of a et b */

#ifdef DEBUG
void deal_sig11(int num)
{
	int var = 1;
	printf("In sig11\n");
	while(var == 1);
}
#endif

/* Preprocess for blocks in master
 * n_cells : number of cells
 * n_cells_ext : number of cells with ghost cells
 * cell_cells_idx : 
 * cell_cells_lst :
 * cell_ii : location ii for the cell
 * cell_jj : location jj for the cell
 */
void grad_pre(int n_cells,
							int n_cells_ext,
							int *cell_cells_idx,
							int *cell_cells_lst,
							int *cell_ii,
							int *cell_jj)
{
	int nbx = (n_cells+BSX-1)/BSX; // number of blocks in x direction
	int nby = (n_cells_ext+BSY-1)/BSY; // number of blocks in y direction
	int i, j;
	int bi, bj;
	/* Calculate nnz in every block */
	int nnz_blk[nbx][nby]; // nnz in block
	memset(nnz_blk, 0, nbx*nby*sizeof(int));
	for(i=0; i<n_cells; i++)
		for(j=cell_cells_idx[i]; j<cell_cells_idx[i+1]; j++)
		{
			bi = i/BSX;
			bj = cell_cells_lst[j]/BSY;
			nnz_blk[bi][bj] ++;
		}
	/* Calculate start location in every block */
	int st_blk[nbx][nby];
	int start = 0;
	for(i=0; i<nbx; i++)
		for(j=0; j<nby; j++)
		{
			st_blk[i][j] = start;
			start += nnz_blk[i][j];
		}
	/* Calculate cell_ii and cell_jj */
	int nfill_blk[nbx][nby]; // number of nnz filled in the block
	memset(nfill_blk, 0, nbx*nby*sizeof(int));
	int location; // location for the nnz
	for(i=0; i<n_cells; i++)
		for(j=cell_cells_idx[i]; j<cell_cells_idx[i+1]; j++)
		{
			bi = i/BSX;
			bj = cell_cells_lst[j]/BSY;
			location = st_blk[bi][bj] + nfill_blk[bi][bj];
			cell_ii[location] = i;
			cell_jj[location] = cell_cells_lst[j];
			nfill_blk[bi][bj] ++;
		}
}

/* Preprocess for blocks in master
 * n_cells : number of cells
 * n_cells_ext : number of cells with ghost cells
 * cell_cells_idx : 
 * cell_cells_lst :
 * cell_ii : location ii for the cell
 * cell_jj : location jj for the cell
 * pa : parameter for slave
 */
void grad_preforslave(int n_cells,
							int n_cells_ext,
							int *cell_cells_idx,
							int *cell_cells_lst,
							int *cell_ii,
							int *cell_jj,
							para1 *pa)
{
	int nbx = (n_cells+BSX-1)/BSX; // number of blocks in x direction
	int nby = (n_cells_ext+BSY-1)/BSY; // number of blocks in y direction
	/* Init pa */
	pa->nbx = nbx;
	pa->st_x = (int*)malloc(nbx*sizeof(int));
	pa->len_x = (int*)malloc(nbx*sizeof(int));
	pa->st_nnz = (int*)malloc(nbx*sizeof(int));
	pa->len_nnz = (int*)malloc(nbx*sizeof(int));
	int i, j;
	int bi, bj;
	/* Calculate nnz in every block */
	int nnz_blk[nbx][nby]; // nnz in block
	memset(nnz_blk, 0, nbx*nby*sizeof(int));
	for(i=0; i<n_cells; i++)
		for(j=cell_cells_idx[i]; j<cell_cells_idx[i+1]; j++)
		{
			bi = i/BSX;
			bj = cell_cells_lst[j]/BSY;
			nnz_blk[bi][bj] ++;
		}
	/* Calculate start location in every block */
	int st_blk[nbx][nby];
	int start = 0;
	for(i=0; i<nbx; i++)
		for(j=0; j<nby; j++)
		{
			st_blk[i][j] = start;
			start += nnz_blk[i][j];
		}
	/* Set pa */
	for(i=0; i<nbx; i++)
	{
		pa->st_x[i] = i*BSX;
		pa->len_x[i] = BSX;
		if(i==nbx-1)
			pa->len_x[i] = n_cells-(BSX*(nbx-1));
		pa->st_nnz[i] = st_blk[i][0];
		pa->len_nnz[i] = st_blk[i][nby-1]-st_blk[i][0]+nnz_blk[i][nby-1];
	}
	/* Calculate cell_ii and cell_jj */
	int nfill_blk[nbx][nby]; // number of nnz filled in the block
	memset(nfill_blk, 0, nbx*nby*sizeof(int));
	int location; // location for the nnz
	for(i=0; i<n_cells; i++)
		for(j=cell_cells_idx[i]; j<cell_cells_idx[i+1]; j++)
		{
			bi = i/BSX;
			bj = cell_cells_lst[j]/BSY;
			location = st_blk[bi][bj] + nfill_blk[bi][bj];
			cell_ii[location] = i;
			cell_jj[location] = cell_cells_lst[j];
			nfill_blk[bi][bj] ++;
		}
}

void grad_cal(int nnz,
						int *cell_ii,
						int *cell_jj,
						cs_real_3_t *cell_cen,
						cs_real_3_t *grad,
						double *var,
						double *denum,
						double *denom)
{
	int i=0;
	int ii, jj;
	int ll;
	cs_real_3_t dist;
	double dpdxf, dpdyf, dpdzf;
	double dist1, dvar;
	for(i=0; i<nnz; i++)
	{
		ii = cell_ii[i];
		jj = cell_jj[i];

		for (ll = 0; ll < 3; ll++)
			dist[ll] = cell_cen[ii][ll] - cell_cen[jj][ll];

		dpdxf = 0.5 * (grad[ii][0] + grad[jj][0]);
		dpdyf = 0.5 * (grad[ii][1] + grad[jj][1]);
		dpdzf = 0.5 * (grad[ii][2] + grad[jj][2]);

		dist1 = fabs(dist[0]*dpdxf + dist[1]*dpdyf + dist[2]*dpdzf);
		dvar = fabs(var[ii] - var[jj]);

		denum[ii] = max(denum[ii], dist1);
		denom[ii] = max(denom[ii], dvar);
	}
}

/**
 * Preprocess for slave of clip1
 * n_cells : number of cells
 * n_cells_ext : number of cells with ghost
 * nnz_clip1 : nnz in clip1
 * i_face_cells : connecty of face and cells
 * pa : parameter for slave
 */
void pre_clip1(int n_cells, 
								int n_cells_ext, 
								int nnz_clip1, 
								cs_lnum_2_t *i_face_cells, 
								para1 *pa)
{
	int nbx = (n_cells_ext+BSX-1)/BSX;
	int nby = (n_cells_ext+BSY-1)/BSY;
	/* Init pa */
	pa->nbx = nbx;
	pa->st_x = (int*)malloc(nbx*sizeof(int));
	pa->len_x = (int*)malloc(nbx*sizeof(int));
	pa->st_nnz = (int*)malloc(nbx*sizeof(int));
	pa->len_nnz = (int*)malloc(nbx*sizeof(int));
	int i, j;
	int ii, jj;
	int bi, bj;
	/* Calculate nnz in every block */
	int nnz_blk[nbx][nby]; // nnz in block
	memset(nnz_blk, 0, nbx*nby*sizeof(int));
	for(i=0; i<nnz_clip1; i++)
	{
		ii = i_face_cells[i][0];
		jj = i_face_cells[i][1];
		bi = ii/BSX;
		bj = jj/BSY;
		nnz_blk[bi][bj] ++;
		bi = jj/BSX;
		bj = ii/BSY;
		nnz_blk[bi][bj] ++;
	}
	/* Calculate start location in every block */
	int st_blk[nbx][nby];
	int start = 0;
	for(i=0; i<nbx; i++)
		for(j=0; j<nby; j++)
		{
			st_blk[i][j] = start;
			start += nnz_blk[i][j];
		}
	/* Set pa */
	for(i=0; i<nbx; i++)
	{
		pa->st_x[i] = i*BSX;
		pa->len_x[i] = BSX;
		if(i==nbx-1)
			pa->len_x[i] = n_cells_ext-(BSX*(nbx-1));
		pa->st_nnz[i] = st_blk[i][0];
		pa->len_nnz[i] = st_blk[i][nby-1]-st_blk[i][0]+nnz_blk[i][nby-1];
	}
	/* Calculate cell_ii and cell_jj */
	pa->cell_ii = (int*)malloc(nnz_clip1*2*sizeof(int));
	pa->cell_jj = (int*)malloc(nnz_clip1*2*sizeof(int));
	int nfill_blk[nbx][nby]; // number of nnz filled in the block
	memset(nfill_blk, 0, nbx*nby*sizeof(int));
	int location; // location for the nnz
	for(i=0; i<nnz_clip1; i++)
	{
		ii = i_face_cells[i][0];
		jj = i_face_cells[i][1];
		bi = ii/BSX;
		bj = jj/BSY;
		location = st_blk[bi][bj] + nfill_blk[bi][bj];
		pa->cell_ii[location] = ii;
		pa->cell_jj[location] = jj;
		nfill_blk[bi][bj] ++;
		bi = jj/BSX;
		bj = ii/BSY;
		location = st_blk[bi][bj] + nfill_blk[bi][bj];
		pa->cell_ii[location] = jj;
		pa->cell_jj[location] = ii;
		nfill_blk[bi][bj] ++;
	}
}

/**
 * Test clip1
 * n_cells : number of cells
 * n_cells_ext : number of cells with ghost
 * var : var
 */
void test_clip1(const int n_cells, const int n_cells_ext, double *var)
{
	int n_i_groups, n_i_threads;
	int nnz_clip1;
	cs_real_3_t *cell_cen;
	cs_real_3_t *grad;
	double *denum, *denom;
	cell_cen = (cs_real_3_t*)malloc(n_cells_ext*sizeof(cs_real_3_t));
	grad = (cs_real_3_t*)malloc(n_cells_ext*sizeof(cs_real_3_t));
	denum = (double*)malloc(n_cells_ext*sizeof(double));
	denom = (double*)malloc(n_cells_ext*sizeof(double));
	FILE *fp = fopen("clip1.dat", "rb");
	fread(&n_i_groups, sizeof(int), 1, fp);
	fread(&n_i_threads, sizeof(int), 1, fp);
	int size_index = n_i_groups*n_i_threads*2;
	int *i_group_index = (int*)malloc(size_index*sizeof(int));
	fread(i_group_index, sizeof(int), size_index, fp);
	nnz_clip1 = i_group_index[size_index-1];
	cs_lnum_2_t *i_face_cells = (cs_lnum_2_t*)malloc(nnz_clip1*sizeof(cs_lnum_2_t));
	fread(i_face_cells, sizeof(int), nnz_clip1*2, fp);
	fread(cell_cen, sizeof(cs_real_3_t), n_cells_ext, fp);
	fread(grad, sizeof(cs_real_3_t), n_cells_ext, fp);
	fread(denum, sizeof(double), n_cells_ext, fp);
	fread(denom, sizeof(double), n_cells_ext, fp);
	fclose(fp);
	/* Used in slave */
	double *denum_slv = (double*)malloc(n_cells_ext*sizeof(double));
	double *denom_slv = (double*)malloc(n_cells_ext*sizeof(double));
	memcpy(denum_slv, denum, n_cells_ext*sizeof(double));
	memcpy(denom_slv, denom, n_cells_ext*sizeof(double));
	/* Calculate clip1 */
	int g_id, t_id, face_id;
	int ii, jj, ll;
	cs_real_3_t dist;
	double dpdxf, dpdyf, dpdzf;
	double dist1, dvar;
#ifdef DEBUG
	printf("In clip1, n_i_groups=%d, n_i_threads=%d\n", n_i_groups, n_i_threads);
	printf("nnz_clip1=%d\n", nnz_clip1);
#endif
#ifdef TIME
	unsigned long t0, t1;
	t0 = CRTS_time_cycle();
#endif
	for (g_id = 0; g_id < n_i_groups; g_id++) {

		for (t_id = 0; t_id < n_i_threads; t_id++) {

			for (face_id = i_group_index[(t_id*n_i_groups + g_id)*2];
					 face_id < i_group_index[(t_id*n_i_groups + g_id)*2 + 1];
					 face_id++) {

				ii = i_face_cells[face_id][0];
				jj = i_face_cells[face_id][1];

				for (ll = 0; ll < 3; ll++)
					dist[ll] = cell_cen[ii][ll] - cell_cen[jj][ll];

				dpdxf = 0.5 * (grad[ii][0] + grad[jj][0]);
				dpdyf = 0.5 * (grad[ii][1] + grad[jj][1]);
				dpdzf = 0.5 * (grad[ii][2] + grad[jj][2]);

				dist1 = CS_ABS(dist[0]*dpdxf + dist[1]*dpdyf + dist[2]*dpdzf);
				dvar = CS_ABS(var[ii] - var[jj]);

				denum[ii] = CS_MAX(denum[ii], dist1);
				denum[jj] = CS_MAX(denum[jj], dist1);
				denom[ii] = CS_MAX(denom[ii], dvar);
				denom[jj] = CS_MAX(denom[jj], dvar);

			} /* End of loop on faces */

		} /* End of loop on threads */

	} /* End of loop on thread groups */
#ifdef TIME
	t1 = CRTS_time_cycle();
	printf("Clip1 time in host is %ld\n", t1 - t0);
#endif
	para1 *pa = (para1 *)malloc(sizeof(para1));
	pre_clip1(n_cells, n_cells_ext, nnz_clip1, i_face_cells, pa);
	pa->cell_cen = cell_cen;
	pa->grad = grad;
	pa->var = var;
	pa->denum = denum_slv;
	pa->denom = denom_slv;
#ifdef TIME
	t0 = CRTS_time_cycle();
#endif
	athread_spawn(clip1_slv, pa);
	athread_join();
#ifdef TIME
	t1 = CRTS_time_cycle();
	printf("Time of clip1_slv is %ld\n", t1 - t0);
	int ds = 0;
	ds += nnz_clip1*2*sizeof(int);
	ds += n_cells_ext*sizeof(cs_real_3_t);
	ds += n_cells_ext*sizeof(cs_real_3_t);
	ds += n_cells_ext*sizeof(double);
	ds += 2*2*n_cells_ext*sizeof(double);
	printf("Bandwidth of clip1_slv is %lf GB/s\n", ds * 2.2/(t1-t0));
#endif
#ifdef CHECK
	double *denum_sa = (double*)malloc(n_cells_ext*sizeof(double));
	double *denom_sa = (double*)malloc(n_cells_ext*sizeof(double));
	FILE *fp_sa = fopen("sa_cr.dat", "rb");
	fread(denum_sa, sizeof(double), n_cells_ext, fp_sa);
	fread(denom_sa, sizeof(double), n_cells_ext, fp_sa);
	/* Check clip1 result */
	int de_i;
	printf("Check clip1_host...\n");
	for(de_i=0; de_i<n_cells; de_i++)
	{
		if(denum[de_i] != denum_sa[de_i])
			printf("Error clip1! denum[%d]=%lf, denum_sa[%d]=%lf\n", de_i, denum[de_i],
							de_i, denum_sa[de_i]);
		if(denom[de_i] != denom_sa[de_i])
			printf("Error clip1! denom[%d]=%lf, denom_sa[%d]=%lf\n", de_i, denom[de_i],
							de_i, denom_sa[de_i]);
	}
	printf("Check clip1_slv...\n");
	for(de_i=0; de_i<n_cells; de_i++)
	{
		if(denum_slv[de_i] != denum_sa[de_i])
			printf("Error clip1! denum_slv[%d]=%lf, denum_sa[%d]=%lf\n", de_i, denum_slv[de_i],
							de_i, denum_sa[de_i]);
		if(denom_slv[de_i] != denom_sa[de_i])
			printf("Error clip1! denom_slv[%d]=%lf, denom_sa[%d]=%lf\n", de_i, denom_slv[de_i],
							de_i, denom_sa[de_i]);
	}
	free(denum_sa);
	free(denom_sa);
#endif
	free(i_group_index);
	free(i_face_cells);
	free(cell_cen);
	free(grad);
	free(denum);
	free(denom);
	free(denum_slv);
	free(denom_slv);
	free(pa->st_x);
	free(pa->len_x);
	free(pa->st_nnz);
	free(pa->len_nnz);
	free(pa->cell_ii);
	free(pa->cell_jj);
	free(pa);
}

int main()
{
#ifdef DEBUG
	signal(11, deal_sig11);
#endif
	FILE *fp;
	fp = fopen("grad_demo.dat", "rb");
	int n_cells;
	int n_cells_ext;
	fread(&n_cells, sizeof(int), 1, fp);
	fread(&n_cells_ext, sizeof(int), 1, fp);
	int *cell_cells_idx = (int*)malloc((n_cells+1)*sizeof(int));
	fread(cell_cells_idx, sizeof(int), n_cells+1, fp);
	int *cell_cells_lst = (int*)malloc(cell_cells_idx[n_cells]*sizeof(int));
	//double *cell_cen = (double*)malloc(n_cells_ext*3*sizeof(double));
	//double *grad = (double*)malloc(n_cells_ext*3*sizeof(double));
	cs_real_3_t *cell_cen = (cs_real_3_t*)malloc(n_cells_ext*sizeof(cs_real_3_t));
	cs_real_3_t *grad = (cs_real_3_t*)malloc(n_cells_ext*sizeof(cs_real_3_t));
	double *var = (double*)malloc(n_cells_ext*sizeof(double));
	double *denum = (double*)malloc(n_cells*sizeof(double));
	double *denom = (double*)malloc(n_cells*sizeof(double));

	/* Read file for init */
	fread(cell_cells_lst, sizeof(int), cell_cells_idx[n_cells], fp);
	//fread(cell_cen, sizeof(double), n_cells_ext*3, fp);
	//fread(grad, sizeof(double), n_cells_ext*3, fp);
	fread(cell_cen, sizeof(cs_real_3_t), n_cells_ext, fp);
	fread(grad, sizeof(cs_real_3_t), n_cells_ext, fp);
	fread(var, sizeof(double), n_cells_ext, fp);
	fread(denum, sizeof(double), n_cells, fp);
	fread(denom, sizeof(double), n_cells, fp);

	/* Slave work array */
	double *denum_slv = (double*)malloc(n_cells*sizeof(double)); // for slave
	double *denom_slv = (double*)malloc(n_cells*sizeof(double)); // for slave
	memcpy(denum_slv, denum, n_cells*sizeof(double));
	memcpy(denom_slv, denom, n_cells*sizeof(double));
	double *denum_3 = (double*)malloc(n_cells*sizeof(double)); // for test3
	double *denom_3 = (double*)malloc(n_cells*sizeof(double)); // for test3
	memcpy(denum_3, denum, n_cells*sizeof(double));
	memcpy(denom_3, denom, n_cells*sizeof(double));
	double *denum_p1 = (double*)malloc(n_cells*sizeof(double)); // for test3
	double *denom_p1 = (double*)malloc(n_cells*sizeof(double)); // for test3
	memcpy(denum_p1, denum, n_cells*sizeof(double));
	memcpy(denom_p1, denom, n_cells*sizeof(double));
#ifdef DEBUG
	int debug_i;
	printf("Debug info: n_cells=%d, n_cells_ext=%d\n", n_cells, n_cells_ext);
#endif
	int ii, jj, ll, cidx;
	double dpdxf, dpdyf, dpdzf;
	double dist1, dvar;
	double dist[3];
#ifdef TIME
	unsigned long t0, t1;
	t0 = CRTS_time_cycle();
#endif
	/* Calculation */
	for (ii = 0; ii < n_cells; ii++) {
		for (cidx = cell_cells_idx[ii];
				 cidx < cell_cells_idx[ii+1];
				 cidx++) {

			jj = cell_cells_lst[cidx];

			for (ll = 0; ll < 3; ll++)
				dist[ll] = cell_cen[ii][ll] - cell_cen[jj][ll];

			dpdxf = 0.5 * (grad[ii][0] + grad[jj][0]);
			dpdyf = 0.5 * (grad[ii][1] + grad[jj][1]);
			dpdzf = 0.5 * (grad[ii][2] + grad[jj][2]);

			dist1 = fabs(dist[0]*dpdxf + dist[1]*dpdyf + dist[2]*dpdzf);
			dvar = fabs(var[ii] - var[jj]);

			denum[ii] = max(denum[ii], dist1);
			denom[ii] = max(denom[ii], dvar);

		}
	}
#ifdef TIME
	t1 = CRTS_time_cycle();
	printf("Time used is %ld\n", t1 - t0);
#endif
	CRTS_init();

	Para v;
	v.n_cells = n_cells;
	v.n_cells_ext = n_cells_ext;
	v.cell_cells_idx = cell_cells_idx;
	v.cell_cells_lst = cell_cells_lst;
	v.cell_cen = cell_cen;
	v.grad = grad;
	v.var = var;
	v.denum = denum_slv;
	v.denom = denom_slv;
#ifdef TIME
	t0 = CRTS_time_cycle();
#endif
	athread_spawn(grad_slv, &v);
	athread_join();
#ifdef TIME
	t1 = CRTS_time_cycle();
	printf("Time of grad_slv is %ld\n", t1 - t0);
	int ds = 0;
	ds += (n_cells+1)*sizeof(int);
	ds += cell_cells_idx[n_cells]*sizeof(int);
	ds += n_cells * sizeof(cs_real_3_t);
	ds += n_cells * sizeof(cs_real_3_t);
	ds += n_cells * sizeof(double);
	ds += 2*2*n_cells * sizeof(double);
	printf("Bandwidth is %lf GB/s\n", ds*2.25/(t1-t0));
#endif
	int nnz = cell_cells_idx[n_cells];
	int *cell_ii = (int*)malloc(nnz*sizeof(int));
	int *cell_jj = (int*)malloc(nnz*sizeof(int));

	grad_pre(n_cells,
					n_cells_ext,
					cell_cells_idx,
					cell_cells_lst,
					cell_ii,
					cell_jj);
#ifdef TIME
	t0 = CRTS_time_cycle();
#endif
	grad_cal(nnz, 
					cell_ii, 
					cell_jj, 
					cell_cen, 
					grad, 
					var, 
					denum_3, 
					denom_3);
#ifdef TIME
	t1 = CRTS_time_cycle();
	printf("Time for test3 is %ld\n", t1 - t0);
#endif

	para1 *pa = (para1*)malloc(sizeof(para1));
	grad_preforslave(n_cells,
					n_cells_ext,
					cell_cells_idx,
					cell_cells_lst,
					cell_ii,
					cell_jj,
					pa);
	pa->cell_ii = cell_ii;
	pa->cell_jj = cell_jj;
	pa->cell_cen = cell_cen;
	pa->grad = grad;
	pa->var = var;
	pa->denum = denum_p1;
	pa->denom = denom_p1;
#ifdef TIME
	t0 = CRTS_time_cycle();
#endif
	athread_spawn(grad_slv1, pa);
	athread_join();
#ifdef TIME
	t1 = CRTS_time_cycle();
	printf("Time for slave1 is %ld\n", t1 - t0);
#endif
	test_clip1(n_cells, n_cells_ext, var);

#ifdef CHECK
	double *denum_sa = (double*)malloc(n_cells*sizeof(double));
	double *denom_sa = (double*)malloc(n_cells*sizeof(double));
	FILE *fp_res = fopen("res_sa.dat", "rb");
	fread(denum_sa, sizeof(double), n_cells, fp_res);
	fread(denom_sa, sizeof(double), n_cells, fp_res);
	fclose(fp_res);
	int de_i;
	for(de_i=0; de_i<n_cells; de_i++)
	{
		if(denum[de_i] != denum_sa[de_i])
			printf("Error! denum[%d]=%lf, denum_sa[%d]=%lf\n", de_i, denum[de_i],
							de_i, denum_sa[de_i]);
		if(denom[de_i] != denom_sa[de_i])
			printf("Error! denom[%d]=%lf, denom_sa[%d]=%lf\n", de_i, denom[de_i],
							de_i, denom_sa[de_i]);
	}
	/* Check slave result */
	printf("Check slave result...\n");
	for(de_i=0; de_i<n_cells; de_i++)
	{
		if(denum_slv[de_i] != denum_sa[de_i])
			printf("Error! denum_slv[%d]=%lf, denum_sa[%d]=%lf\n", 
										de_i, denum_slv[de_i], de_i, denum_sa[de_i]);
		if(denom_slv[de_i] != denom_sa[de_i])
			printf("Error! denom_slv[%d]=%lf, denom_sa[%d]=%lf\n", 
										de_i, denom_slv[de_i], de_i, denom_sa[de_i]);
	}
	/* Check test3 result */
	printf("Check test3 result...\n");
	for(de_i=0; de_i<n_cells; de_i++)
	{
		if(denum_3[de_i] != denum_sa[de_i])
			printf("Error! denum_3[%d]=%lf, denum_sa[%d]=%lf\n", 
										de_i, denum_3[de_i], de_i, denum_sa[de_i]);
		if(denom_3[de_i] != denom_sa[de_i])
			printf("Error! denom_3[%d]=%lf, denom_sa[%d]=%lf\n", 
										de_i, denom_3[de_i], de_i, denom_sa[de_i]);
	}
	/* Check test3 result */
	printf("Check slave1 result...\n");
	for(de_i=0; de_i<n_cells; de_i++)
	{
		if(denum_p1[de_i] != denum_sa[de_i])
			printf("Error! denum_p1[%d]=%lf, denum_sa[%d]=%lf\n", 
										de_i, denum_p1[de_i], de_i, denum_sa[de_i]);
		if(denom_p1[de_i] != denom_sa[de_i])
			printf("Error! denom_p1[%d]=%lf, denom_sa[%d]=%lf\n", 
										de_i, denom_p1[de_i], de_i, denom_sa[de_i]);
	}
#endif
	free(cell_cells_idx);
	free(cell_cells_lst);
	free(cell_cen);
	free(grad);
	free(var);
	free(denum);
	free(denom);
	free(denum_slv);
	free(denom_slv);
	free(cell_ii);
	free(cell_jj);
	free(denum_3);
	free(denom_3);
	free(pa->st_x);
	free(pa->len_x);
	free(pa->st_nnz);
	free(pa->len_nnz);
	free(denum_p1);
	free(denom_p1);
	free(pa);
#ifdef CEHCK
	free(denum_sa);
	free(denom_sa);
#endif
}
