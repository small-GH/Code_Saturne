#include <stdlib.h>
#include <stdio.h>
#include <crts.h>
#include <math.h>

#define max(a, b) (a>b)?(a):(b)
#define CS_ABS(a)     ((a) <  0  ? -(a) : (a))  /* Absolute value of a */
#define CS_MIN(a,b)   ((a) < (b) ?  (a) : (b))  /* Minimum of a et b */
#define CS_MAX(a,b)   ((a) > (b) ?  (a) : (b))  /* Maximum of a et b */
#define BSX 512
#define BSY 32

typedef double cs_real_3_t[3];
typedef double cs_real_4_t[4];
typedef double cs_real_33_t[3][3];

/* Add by guoheng at 1.29 */
typedef struct BLOCK
{
	int nbx;
	int *st_x;
	int *len_x;
	int *st_nnz;
	int *len_nnz;
	int *cell_ii;
	int *cell_jj;
} block;

/**
 * Parameter in slave for denum and denom update
 */
typedef struct PARA_D
{
	block blk;
	cs_real_3_t *cell_cen;
	cs_real_3_t *grad;
	double *var;
	double *denum;
	double *denom;
} para_d;

/**
 * Parameter in slave for factor update
 */
typedef struct PARA_F
{
	block blk;
	double *factor;
	double *clip_factor;
} para_f;
/* End change */

/* Add by guoheng at 2021.2.1 */
/**
 * Parameter in slave for pressure update
 * Used for function LSQ update in cs_gradient.c
 */
typedef struct PARA_P
{
	block blk;
	cs_real_3_t *cell_cen;
	cs_real_4_t *rhsv;
} para_p;
/* End change */

/* Add by guoheng at 2020.2.22 */
/**
 * Parameter in slave for gradient_vector update
 * Used in function _lsq_vector_gradient in cs_gradient.c
 */
typedef struct PARA_GVR
{
	block blk;
	cs_real_3_t *cell_cen;
	cs_real_3_t *pvar;
	cs_real_33_t *rhs;
} para_gvr;

/**
 * Parameter in slave for gradient_vector denum and denom
 * Used in function _lsq_vector_gradient
 */
typedef struct PARA_GVD
{
	block blk;
	cs_real_3_t *cell_cen;
	cs_real_33_t *gradv;
	cs_real_3_t *pvar;
	double *denum;
	double *denom;
} para_gvd;

/**
 * Parameter in slave for gradient_vector clip_factor
 * Used in function _lsq_vector_gradient
 */
typedef struct PARA_GVF
{
	block blk;
	double clipp_coef_sq;
	double *denum;
	double *denom;
	double *clip_factor;
} para_gvf;
/* End change */

typedef struct CLIP2_PARA
{ 
  int nbx;
  int *st_x;
  int *len_x;
  int *st_nnz;
  int *len_nnz;
  int *cell_ii;
  int *cell_jj;
  cs_real_3_t *cell_cen;
  cs_real_3_t *grad;
  double *var;
  double *denum;
  double *denom;
} clip2_para;

void clip2_slv(clip2_para *pa)
{
	clip2_para v;
	CRTS_dma_get(&v, pa, sizeof(clip2_para));
	int nbx = v.nbx;
	int *st_x = v.st_x;
	int *len_x = v.len_x;
	int *st_nnz = v.st_nnz;
	int *len_nnz = v.len_nnz;
	int *cell_ii = v.cell_ii;
	int *cell_jj = v.cell_jj;
	cs_real_3_t *cell_cen = v.cell_cen;
	cs_real_3_t *grad = v.grad;
	double *var = v.var;
	double *denum = v.denum;
	double *denom = v.denom;
	int i, j;
	int ii, jj, ll;
	cs_real_3_t dist;
	double dpdxf, dpdyf, dpdzf;
	double dist1, dvar;
	cs_real_3_t l_cell_cen[BSX];
	cs_real_3_t l_grad[BSX];
	double l_var[BSX];
	double l_denum[BSX];
	double l_denom[BSX];
	int start_x, length_x;
	int start_nnz, length_nnz;
	int l_ii;
	for(i=_MYID; i<nbx; i+=64)
	{
		start_x = st_x[i];
		length_x = len_x[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in core1, st_x=%d, len_x=%d\n", start_x, length_x);
#endif
		CRTS_dma_get(l_cell_cen, cell_cen+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_grad, grad+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_var, var+start_x, length_x*sizeof(double));
		CRTS_dma_get(l_denum, denum+start_x, length_x*sizeof(double));
		CRTS_dma_get(l_denom, denom+start_x, length_x*sizeof(double));
		/* Calculate */
		start_nnz = st_nnz[i];
		length_nnz = len_nnz[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in core1, st_nnz=%d, len_nnz=%d\n", start_nnz, length_nnz);
#endif
		for(j=start_nnz; j<start_nnz+length_nnz; j++)
		{
			ii = cell_ii[j];
			jj = cell_jj[j];
			l_ii = ii - start_x;
			for (ll = 0; ll < 3; ll++)
				dist[ll] = l_cell_cen[l_ii][ll] - cell_cen[jj][ll];

			dpdxf = 0.5 * (l_grad[l_ii][0] + grad[jj][0]);
			dpdyf = 0.5 * (l_grad[l_ii][1] + grad[jj][1]);
			dpdzf = 0.5 * (l_grad[l_ii][2] + grad[jj][2]);

			dist1 = fabs(dist[0]*dpdxf + dist[1]*dpdyf + dist[2]*dpdzf);
			dvar = fabs(l_var[l_ii] - var[jj]);

			l_denum[l_ii] = max(l_denum[l_ii], dist1);
			l_denom[l_ii] = max(l_denom[l_ii], dvar);
		}
		CRTS_dma_put(denum+start_x, l_denum, length_x*sizeof(double));
		CRTS_dma_put(denom+start_x, l_denom, length_x*sizeof(double));
	}
}

void clip1_slv(clip2_para *pa)
{
	clip2_para v;
	CRTS_dma_get(&v, pa, sizeof(clip2_para));
	int nbx = v.nbx;
	int *st_x = v.st_x;
	int *len_x = v.len_x;
	int *st_nnz = v.st_nnz;
	int *len_nnz = v.len_nnz;
	int *cell_ii = v.cell_ii;
	int *cell_jj = v.cell_jj;
	cs_real_3_t *cell_cen = v.cell_cen;
	cs_real_3_t *grad = v.grad;
	double *var = v.var;
	double *denum = v.denum;
	double *denom = v.denom;
	int i, j;
	int ii, jj, ll;
	cs_real_3_t dist;
	double dpdxf, dpdyf, dpdzf;
	double dist1, dvar;
	cs_real_3_t l_cell_cen[BSX];
	cs_real_3_t l_grad[BSX];
	double l_var[BSX];
	double l_denum[BSX];
	double l_denom[BSX];
	int start_x, length_x;
	int start_nnz, length_nnz;
	int l_ii;
	for(i=_MYID; i<nbx; i+=64)
	{
		start_x = st_x[i];
		length_x = len_x[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_x=%d, len_x=%d\n", start_x, length_x);
#endif
		CRTS_dma_get(l_cell_cen, cell_cen+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_grad, grad+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_var, var+start_x, length_x*sizeof(double));
		CRTS_dma_get(l_denum, denum+start_x, length_x*sizeof(double));
		CRTS_dma_get(l_denom, denom+start_x, length_x*sizeof(double));
		/* Calculate */
		start_nnz = st_nnz[i];
		length_nnz = len_nnz[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_nnz=%d, len_nnz=%d\n", start_nnz, length_nnz);
#endif
		for(j=start_nnz; j<start_nnz+length_nnz; j++)
		{
			ii = cell_ii[j];
			jj = cell_jj[j];
			l_ii = ii - start_x;
			for (ll = 0; ll < 3; ll++)
				dist[ll] = l_cell_cen[l_ii][ll] - cell_cen[jj][ll];

			dpdxf = 0.5 * (l_grad[l_ii][0] + grad[jj][0]);
			dpdyf = 0.5 * (l_grad[l_ii][1] + grad[jj][1]);
			dpdzf = 0.5 * (l_grad[l_ii][2] + grad[jj][2]);

			dist1 = fabs(dist[0]*dpdxf + dist[1]*dpdyf + dist[2]*dpdzf);
			dvar = fabs(l_var[l_ii] - var[jj]);

			l_denum[l_ii] = max(l_denum[l_ii], dist1);
			l_denom[l_ii] = max(l_denom[l_ii], dvar);
		}
		CRTS_dma_put(denum+start_x, l_denum, length_x*sizeof(double));
		CRTS_dma_put(denom+start_x, l_denom, length_x*sizeof(double));
	}
}

/**
 * Update denum and denom in clipping
 */
void clip_update_D(para_d *pa)
{
	para_d v;
	CRTS_dma_get(&v, pa, sizeof(para_d));
	block *blk = &(v.blk);
	int nbx = blk->nbx;
	int *st_x = blk->st_x;
	int *len_x = blk->len_x;
	int *st_nnz = blk->st_nnz;
	int *len_nnz = blk->len_nnz;
	int *cell_ii = blk->cell_ii;
	int *cell_jj = blk->cell_jj;
	cs_real_3_t *cell_cen = v.cell_cen;
	cs_real_3_t *grad = v.grad;
	double *var = v.var;
	double *denum = v.denum;
	double *denom = v.denom;
	int i, j;
	int ii, jj, ll;
	cs_real_3_t dist;
	double dpdxf, dpdyf, dpdzf;
	double dist1, dvar;
	cs_real_3_t l_cell_cen[BSX];
	cs_real_3_t l_grad[BSX];
	double l_var[BSX];
	double l_denum[BSX];
	double l_denom[BSX];
	int start_x, length_x;
	int start_nnz, length_nnz;
	int l_ii;
	for(i=_MYID; i<nbx; i+=64)
	{
		start_x = st_x[i];
		length_x = len_x[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_x=%d, len_x=%d\n", start_x, length_x);
#endif
		CRTS_dma_get(l_cell_cen, cell_cen+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_grad, grad+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_var, var+start_x, length_x*sizeof(double));
		CRTS_dma_get(l_denum, denum+start_x, length_x*sizeof(double));
		CRTS_dma_get(l_denom, denom+start_x, length_x*sizeof(double));
		/* Calculate */
		start_nnz = st_nnz[i];
		length_nnz = len_nnz[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_nnz=%d, len_nnz=%d\n", start_nnz, length_nnz);
#endif
		for(j=start_nnz; j<start_nnz+length_nnz; j++)
		{
			ii = cell_ii[j];
			jj = cell_jj[j];
			l_ii = ii - start_x;
			for (ll = 0; ll < 3; ll++)
				dist[ll] = l_cell_cen[l_ii][ll] - cell_cen[jj][ll];

			dpdxf = 0.5 * (l_grad[l_ii][0] + grad[jj][0]);
			dpdyf = 0.5 * (l_grad[l_ii][1] + grad[jj][1]);
			dpdzf = 0.5 * (l_grad[l_ii][2] + grad[jj][2]);

			dist1 = fabs(dist[0]*dpdxf + dist[1]*dpdyf + dist[2]*dpdzf);
			dvar = fabs(l_var[l_ii] - var[jj]);

			l_denum[l_ii] = max(l_denum[l_ii], dist1);
			l_denom[l_ii] = max(l_denom[l_ii], dvar);
		}
		CRTS_dma_put(denum+start_x, l_denum, length_x*sizeof(double));
		CRTS_dma_put(denom+start_x, l_denom, length_x*sizeof(double));
	}
}

/**
 * Update clip_factor in clipping
 */
void clip_update_F(para_f *pa)
{
	para_f v;
	CRTS_dma_get(&v, pa, sizeof(para_f));
	block *blk = &(v.blk);
	int nbx = blk->nbx;
	int *st_x = blk->st_x;
	int *len_x = blk->len_x;
	int *st_nnz = blk->st_nnz;
	int *len_nnz = blk->len_nnz;
	int *cell_ii = blk->cell_ii;
	int *cell_jj = blk->cell_jj;
	double *factor = v.factor;
	double *clip_factor = v.clip_factor;
	int i, j;
	int ii, jj, ll;
	double l_factor[BSX];
	int start_x, length_x;
	int start_nnz, length_nnz;
	int l_ii;
	for(i=_MYID; i<nbx; i+=64)
	{
		start_x = st_x[i];
		length_x = len_x[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_x=%d, len_x=%d\n", start_x, length_x);
#endif
		CRTS_dma_get(l_factor, clip_factor+start_x, length_x*sizeof(double));
		/* Calculate */
		start_nnz = st_nnz[i];
		length_nnz = len_nnz[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_nnz=%d, len_nnz=%d\n", start_nnz, length_nnz);
#endif
		for(j=start_nnz; j<start_nnz+length_nnz; j++)
		{
			ii = cell_ii[j];
			jj = cell_jj[j];
			l_ii = ii - start_x;
			l_factor[l_ii] = CS_MIN(l_factor[l_ii], factor[jj]);
		}
		CRTS_dma_put(clip_factor+start_x, l_factor, length_x*sizeof(double));
	}
}

/**
 * Update denum and denom in clipping
 */
void gradient_update_P(para_p *pa)
{
	para_p v;
	CRTS_dma_get(&v, pa, sizeof(para_p));
	block *blk = &(v.blk);
	int nbx = blk->nbx;
	int *st_x = blk->st_x;
	int *len_x = blk->len_x;
	int *st_nnz = blk->st_nnz;
	int *len_nnz = blk->len_nnz;
	int *cell_ii = blk->cell_ii;
	int *cell_jj = blk->cell_jj;
	cs_real_3_t *cell_cen = v.cell_cen;
	cs_real_4_t *rhsv = v.rhsv;
	int i, j;
	int ii, jj, ll;
	cs_real_3_t dc;
	cs_real_4_t fctb;
	double pfac;
	cs_real_3_t l_cell_cen[BSX];
	cs_real_4_t l_rhsv[BSX];
	int start_x, length_x;
	int start_nnz, length_nnz;
	int l_ii;
	for(i=_MYID; i<nbx; i+=64)
	{
		start_x = st_x[i];
		length_x = len_x[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_x=%d, len_x=%d\n", start_x, length_x);
#endif
		CRTS_dma_get(l_cell_cen, cell_cen+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_rhsv, rhsv+start_x, length_x*sizeof(cs_real_4_t));
		/* Calculate */
		start_nnz = st_nnz[i];
		length_nnz = len_nnz[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_nnz=%d, len_nnz=%d\n", start_nnz, length_nnz);
#endif
		for(j=start_nnz; j<start_nnz+length_nnz; j++)
		{
			ii = cell_ii[j];
			jj = cell_jj[j];
			l_ii = ii - start_x;

			for (ll = 0; ll < 3; ll++)
				dc[ll] = cell_cen[jj][ll] - l_cell_cen[l_ii][ll];

			pfac =   (rhsv[jj][3] - l_rhsv[l_ii][3])
						 / (dc[0]*dc[0] + dc[1]*dc[1] + dc[2]*dc[2]);

			for (ll = 0; ll < 3; ll++)
				fctb[ll] = dc[ll] * pfac;

			for (ll = 0; ll < 3; ll++)
				l_rhsv[l_ii][ll] += fctb[ll];

		}
		CRTS_dma_put(rhsv+start_x, l_rhsv, length_x*sizeof(cs_real_4_t));
	}
}

/**
 * Update gradient vector rhs
 */
void gradient_update_GVR(para_gvr *pa)
{
	para_gvr v;
	CRTS_dma_get(&v, pa, sizeof(para_gvr));
	block *blk = &(v.blk);
	int nbx = blk->nbx;
	int *st_x = blk->st_x;
	int *len_x = blk->len_x;
	int *st_nnz = blk->st_nnz;
	int *len_nnz = blk->len_nnz;
	int *cell_ii = blk->cell_ii;
	int *cell_jj = blk->cell_jj;
	cs_real_3_t *cell_cen = v.cell_cen;
	cs_real_3_t *pvar = v.pvar;
	cs_real_33_t *rhs = v.rhs;
	int i, j;
	int ii, jj, ll;
	cs_real_3_t dc;
	double ddc;
	double pfac;
	cs_real_3_t l_cell_cen[BSX];
	cs_real_3_t l_pvar[BSX];
	cs_real_33_t l_rhs[BSX];
	int start_x, length_x;
	int start_nnz, length_nnz;
	int l_ii;
	int m, n;
	for(i=_MYID; i<nbx; i+=64)
	{
		start_x = st_x[i];
		length_x = len_x[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_x=%d, len_x=%d\n", start_x, length_x);
#endif
		CRTS_dma_get(l_cell_cen, cell_cen+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_pvar, pvar+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_rhs, rhs+start_x, length_x*sizeof(cs_real_33_t));
		/* Calculate */
		start_nnz = st_nnz[i];
		length_nnz = len_nnz[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_nnz=%d, len_nnz=%d\n", start_nnz, length_nnz);
#endif
		for(j=start_nnz; j<start_nnz+length_nnz; j++)
		{
			ii = cell_ii[j];
			jj = cell_jj[j];
			l_ii = ii - start_x;

			for (m = 0; m < 3; m++)
				dc[m] = cell_cen[jj][m] - l_cell_cen[l_ii][m];

			ddc = 1./(dc[0]*dc[0] + dc[1]*dc[1] + dc[2]*dc[2]);

			for (m = 0; m < 3; m++) {

				pfac = (pvar[jj][m] - l_pvar[l_ii][m]) * ddc;

				for (n = 0; n < 3; n++) {
					l_rhs[l_ii][m][n] += dc[n] * pfac;
				}
			}
		}
		CRTS_dma_put(rhs+start_x, l_rhs, length_x*sizeof(cs_real_33_t));
	}
}

/**
 * Update gradient vector denum and denom
 */
void gradient_update_GVD(para_gvd *pa)
{
	para_gvd v;
	CRTS_dma_get(&v, pa, sizeof(para_gvd));
	block *blk = &(v.blk);
	int nbx = blk->nbx;
	int *st_x = blk->st_x;
	int *len_x = blk->len_x;
	int *st_nnz = blk->st_nnz;
	int *len_nnz = blk->len_nnz;
	int *cell_ii = blk->cell_ii;
	int *cell_jj = blk->cell_jj;
	cs_real_3_t *cell_cen = v.cell_cen;
	cs_real_33_t *gradv = v.gradv;
	cs_real_3_t *pvar = v.pvar;
	double *denum = v.denum;
	double *denom = v.denom;
	int i, j;
	int ii, jj, ll;
	cs_real_3_t dist;
	cs_real_3_t grad_dist1;
	double dist_sq1;
	double dvar_sq;
	cs_real_3_t l_cell_cen[BSX];
	cs_real_33_t l_gradv[BSX];
	cs_real_3_t l_pvar[BSX];
	double l_denum[BSX];
	double l_denom[BSX];
	int start_x, length_x;
	int start_nnz, length_nnz;
	int l_ii;
	int m, n;
	for(i=_MYID; i<nbx; i+=64)
	{
		start_x = st_x[i];
		length_x = len_x[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_x=%d, len_x=%d\n", start_x, length_x);
#endif
		CRTS_dma_get(l_cell_cen, cell_cen+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_gradv, gradv+start_x, length_x*sizeof(cs_real_33_t));
		CRTS_dma_get(l_pvar, pvar+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_denum, denum+start_x, length_x*sizeof(double));
		CRTS_dma_get(l_denom, denom+start_x, length_x*sizeof(double));
		/* Calculate */
		start_nnz = st_nnz[i];
		length_nnz = len_nnz[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_nnz=%d, len_nnz=%d\n", start_nnz, length_nnz);
#endif
		for(j=start_nnz; j<start_nnz+length_nnz; j++)
		{
			ii = cell_ii[j];
			jj = cell_jj[j];
			l_ii = ii - start_x;
			
			for (m = 0; m < 3; m++)
				dist[m] = l_cell_cen[l_ii][m] - cell_cen[jj][m];

			for (m = 0; m < 3; m++)
				grad_dist1[m]
					= 0.5 * (  (l_gradv[l_ii][m][0]+gradv[jj][m][0])*dist[0]
									 + (l_gradv[l_ii][m][1]+gradv[jj][m][1])*dist[1]
									 + (l_gradv[l_ii][m][2]+gradv[jj][m][2])*dist[2]);

			dist_sq1 =   grad_dist1[0]*grad_dist1[0]
								 + grad_dist1[1]*grad_dist1[1]
								 + grad_dist1[2]*grad_dist1[2];

			dvar_sq =     (l_pvar[l_ii][0]-pvar[jj][0])
									* (l_pvar[l_ii][0]-pvar[jj][0])
								+   (l_pvar[l_ii][1]-pvar[jj][1])
									* (l_pvar[l_ii][1]-pvar[jj][1])
								+   (l_pvar[l_ii][2]-pvar[jj][2])
									* (l_pvar[l_ii][2]-pvar[jj][2]);

			l_denum[l_ii] = CS_MAX(l_denum[l_ii], dist_sq1);
			l_denom[l_ii] = CS_MAX(l_denom[l_ii], dvar_sq);

		}
		CRTS_dma_put(denum+start_x, l_denum, length_x*sizeof(double));
		CRTS_dma_put(denom+start_x, l_denom, length_x*sizeof(double));
	}
}

/**
 * Update gradient vector clip_factor
 */
void gradient_update_GVF(para_gvf *pa)
{
	para_gvf v;
	CRTS_dma_get(&v, pa, sizeof(para_gvf));
	block *blk = &(v.blk);
	int nbx = blk->nbx;
	int *st_x = blk->st_x;
	int *len_x = blk->len_x;
	int *st_nnz = blk->st_nnz;
	int *len_nnz = blk->len_nnz;
	int *cell_ii = blk->cell_ii;
	int *cell_jj = blk->cell_jj;
	double clipp_coef_sq = v.clipp_coef_sq;
	double *denum = v.denum;
	double *denom = v.denom;
	double *clip_factor = v.clip_factor;
	int i, j;
	int ii, jj, ll;
	double factor2;
	double l_denum[BSX];
	double l_denom[BSX];
	double l_clip_factor[BSX];
	int start_x, length_x;
	int start_nnz, length_nnz;
	int l_ii;
	int m, n;
	for(i=_MYID; i<nbx; i+=64)
	{
		start_x = st_x[i];
		length_x = len_x[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_x=%d, len_x=%d\n", start_x, length_x);
#endif
		CRTS_dma_get(l_clip_factor, clip_factor+start_x, length_x*sizeof(double));
		/* Calculate */
		start_nnz = st_nnz[i];
		length_nnz = len_nnz[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in clip1 core1, st_nnz=%d, len_nnz=%d\n", start_nnz, length_nnz);
#endif
		for(j=start_nnz; j<start_nnz+length_nnz; j++)
		{
			ii = cell_ii[j];
			jj = cell_jj[j];
			l_ii = ii - start_x;

			factor2 = 1.0;

			if (denum[jj] > clipp_coef_sq * denom[jj])
				factor2 = sqrt(clipp_coef_sq * denom[jj]/denum[jj]);
			
			l_clip_factor[l_ii] = CS_MIN(l_clip_factor[l_ii], factor2);

		}
		CRTS_dma_put(clip_factor+start_x, l_clip_factor, length_x*sizeof(double));
	}
}
