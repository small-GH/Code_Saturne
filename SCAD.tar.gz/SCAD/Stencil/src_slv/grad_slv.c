#include <stdlib.h>
#include <stdio.h>
#include <crts.h>
#include <math.h>
#include "../grad_dat.h"

#define max(a, b) (a>b)?(a):(b)

typedef struct PARA
{
	int n_cells;
	int n_cells_ext;
	int *cell_cells_idx;
	int *cell_cells_lst;
	cs_real_3_t *cell_cen;
	cs_real_3_t *grad;
	double *var;
	double *denum;
	double *denom;
} para;

void grad_slv(para *v)
{
	para v_s;
	CRTS_dma_get(&v_s, v, sizeof(para));
#ifdef DEBUG
	if(_MYID == 0)
		printf("In slave, n_cells=%d, n_cells_ext=%d\n", 
											v_s.n_cells, v_s.n_cells_ext);
#endif
	int n_cells = v_s.n_cells;
	int n_cells_ext = v_s.n_cells_ext;
	int *cell_cells_idx = v_s.cell_cells_idx;
	int *cell_cells_lst = v_s.cell_cells_lst;
	cs_real_3_t *cell_cen = v_s.cell_cen;
	cs_real_3_t *grad = v_s.grad;
	double *var = v_s.var;
	double *denum = v_s.denum;
	double *denom = v_s.denom;
	/* Local variables */
	double dist[3];
	int ii, jj, ll, cidx;
	double dpdxf, dpdyf, dpdzf;
	double dist1, dvar;
	/* Calculation */
	int st, ed;
	int l_n_cells = n_cells / 64;
	int leave = n_cells - (l_n_cells * 64);
	st = l_n_cells * _MYID;
#ifdef DEBUG_SLV
	if(_MYID == 0)
		printf("In core0, l_n_cells=%d, leave=%d\n", 
											l_n_cells, leave);
#endif
	if(_MYID < leave)
	{
		l_n_cells ++;
		st += _MYID;
		ed = st + l_n_cells;
	}
	else
	{
		st += leave;
		ed = st + l_n_cells;
	}
#ifdef DEBUG_SLV
	if(_MYID == 0)
		printf("In core0, st=%d, ed=%d, l_n_cells=%d, leave=%d\n", 
											st, ed, l_n_cells, leave);
#endif
	//for (ii = _MYID; ii < n_cells; ii+=64) {
	for (ii = st; ii < ed; ii++) {
		for (cidx = cell_cells_idx[ii];
				 cidx < cell_cells_idx[ii+1];
				 cidx++) {

			jj = cell_cells_lst[cidx];

			for (ll = 0; ll < 3; ll++)
				dist[ll] = cell_cen[ii][ll] - cell_cen[jj][ll];

			dpdxf = 0.5 * (grad[ii][0] + grad[jj][0]);
			dpdyf = 0.5 * (grad[ii][1] + grad[jj][1]);
			dpdzf = 0.5 * (grad[ii][2] + grad[jj][2]);

			dist1 = fabs(dist[0]*dpdxf + dist[1]*dpdyf + dist[2]*dpdzf);
			dvar = fabs(var[ii] - var[jj]);

			denum[ii] = max(denum[ii], dist1);
			denom[ii] = max(denom[ii], dvar);

		}
	}
}

void grad_slv1(para1 *pa)
{
	para1 v;
	CRTS_dma_get(&v, pa, sizeof(para1));
	int nbx = v.nbx;
	int *st_x = v.st_x;
	int *len_x = v.len_x;
	int *st_nnz = v.st_nnz;
	int *len_nnz = v.len_nnz;
	int *cell_ii = v.cell_ii;
	int *cell_jj = v.cell_jj;
	cs_real_3_t *cell_cen = v.cell_cen;
	cs_real_3_t *grad = v.grad;
	double *var = v.var;
	double *denum = v.denum;
	double *denom = v.denom;
	int i, j;
	int ii, jj, ll;
	cs_real_3_t dist;
	double dpdxf, dpdyf, dpdzf;
	double dist1, dvar;
	cs_real_3_t l_cell_cen[BSX];
	cs_real_3_t l_grad[BSX];
	double l_var[BSX];
	double l_denum[BSX];
	double l_denom[BSX];
	int start_x, length_x;
	int start_nnz, length_nnz;
	int l_ii;
	for(i=_MYID; i<nbx; i+=64)
	{
		start_x = st_x[i];
		length_x = len_x[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in core1, st_x=%d, len_x=%d\n", start_x, length_x);
#endif
		CRTS_dma_get(l_cell_cen, cell_cen+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_grad, grad+start_x, length_x*sizeof(cs_real_3_t));
		CRTS_dma_get(l_var, var+start_x, length_x*sizeof(double));
		CRTS_dma_get(l_denum, denum+start_x, length_x*sizeof(double));
		CRTS_dma_get(l_denom, denom+start_x, length_x*sizeof(double));
		/* Calculate */
		start_nnz = st_nnz[i];
		length_nnz = len_nnz[i];
#ifdef DEBUG
		if(_MYID == 1)
			printf("in core1, st_nnz=%d, len_nnz=%d\n", start_nnz, length_nnz);
#endif
		for(j=start_nnz; j<start_nnz+length_nnz; j++)
		{
			ii = cell_ii[j];
			jj = cell_jj[j];
			l_ii = ii - start_x;
			for (ll = 0; ll < 3; ll++)
				dist[ll] = l_cell_cen[l_ii][ll] - cell_cen[jj][ll];

			dpdxf = 0.5 * (l_grad[l_ii][0] + grad[jj][0]);
			dpdyf = 0.5 * (l_grad[l_ii][1] + grad[jj][1]);
			dpdzf = 0.5 * (l_grad[l_ii][2] + grad[jj][2]);

			dist1 = fabs(dist[0]*dpdxf + dist[1]*dpdyf + dist[2]*dpdzf);
			dvar = fabs(l_var[l_ii] - var[jj]);

			l_denum[l_ii] = max(l_denum[l_ii], dist1);
			l_denom[l_ii] = max(l_denom[l_ii], dvar);
		}
		CRTS_dma_put(denum+start_x, l_denum, length_x*sizeof(double));
		CRTS_dma_put(denom+start_x, l_denom, length_x*sizeof(double));
	}
}
